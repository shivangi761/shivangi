import tkinter 
from tkinter import*
from tkinter import ttk
t=tkinter.Tk()
t.geometry('800x800')
t.title('my first screen')
a=Label(t,text='Name')
a.place(x=20,y=40)
b=Entry(t,width=40)
b.place(x=300,y=40)
c=Label(t,text='item')
c.place(x=20,y=100)
d=Entry(t,width=40)
d.place(x=300,y=100)
f=Label(t,text='Price')
f.place(x=20,y=160)
g=Entry(t,width=40)
g.place(x=300,y=160)
h=Label(t,text='Quantity')
h.place(x=20,y=220)
sp=Spinbox(t,from_=1,to=100)
sp.place(x=300,y=220)
b=Button(t,text='Bill')
b.place(x=20,y=280)
k=Entry(t,width=40)
k.place(x=300,y=280)


t.mainloop()