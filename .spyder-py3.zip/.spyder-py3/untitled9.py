import tkinter 
from tkinter import*
from tkinter import ttk
t=tkinter.Tk()
t.geometry('800x800')
t.title('my first screen')
def square():
    xp=int(c.get())
    xr=xp*xp
    d.delete(0,100)
    d.insert(0,str(xr))
def cube():
    xp=int(c.get())
    xr=xp*xp*xp
    g.delete(0,100)
    g.insert(0,str(xr))
def n():
    c.delete(0,100)
    d.delete(0,100)
    g.delete(0,100)
def ct():
    t.destroy()
    
a=Label(t,text='No.')
a.place(x=20,y=40)
c=Entry(t,width=40)
c.place(x=300,y=40)
b=Button(t,text='Square',command=square)
b.place(x=20,y=100)
d=Entry(t,width=40)
d.place(x=300,y=100)
b1=Button(t,text='Cube',command=cube)
b1.place(x=20,y=160)
g=Entry(t,width=40)
g.place(x=300,y=160)
b2=Button(t,text='New',command=n)
b2.place(x=20,y=220)


b3=Button(t,text='Close',command=ct)
b3.place(x=280,y=220)


t.mainloop()
