import tkinter
import pymysql
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
recd=''

def showinsert():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('page1db')
    #code for db connectivity button
    def savedata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        xa=int(e1.get())
        xb=e2.get()
        xc=e3.get()
        
        sql="insert into course values(%d,'%s','%s')"%(xa,xb,xc)
        cur.execute(sql)
        db.commit()
        messagebox.showinfo('Hi','Saved')
        db.close()
        e1.delete(0,100)
        e2.delete(0,100)
        e3.delete(0,100)
    l6=Label(t,text='Course Details',font=('arial',15))
    l6.place(x=200,y=7)
        


    l1=Label(t,text='Course Code')
    l1.place(x=60,y=70)

    e1=Entry(t,width=18)
    e1.place(x=200,y=70)

    l2=Label(t,text='Course Name')
    l2.place(x=60,y=100)

    e2=Entry(t,width=18)
    e2.place(x=200,y=100)

    l3=Label(t,text='Course Duration')
    l3.place(x=60,y=130)

    e3=Entry(t,width=18)
    e3.place(x=200,y=130)

    

    b1=Button(t,text='Save',bg='blue',command=savedata)
    b1.place(x=100,y=170)

    b2=Button(t,text='Close',bg='blue')
    b2.place(x=200,y=170)
    t.mainloop()
def showfind():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('page2db')
    lt=[]

    #combobox function
    def filldata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        sql="Select  Code from course"
        cur.execute(sql)
        data=cur.fetchall()
        for res in data:
            lt.append(res[0])
        db.close()

    #find data using billno as primary key
    def finddata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        xa=int(e1.get())
        #delete previous data find before
        e2.delete(0,100)
        e3.delete(0,100)
        
        
        sql="Select name,duration from course where code=%d"%(xa)
        cur.execute(sql)
        #fetchone to get data using index positions
        data=cur.fetchone()
        e2.insert(0,data[0])
        e3.insert(0,data[1])
        
        db.close()
    l1=Label(t,text='Course Code')
    l1.place(x=30,y=40)
    

    b1=Button(t,text='Find',bg='pink',command=finddata)
    b1.place(x=30,y=60)

    e1=ttk.Combobox(t)
    #call function filldata below
    filldata()
    e1['values']=lt
    e1.place(x=200,y=50)
    l6=Label(t,text='Course Details',font=('arial',15))
    l6.place(x=200,y=7)
        

    l2=Label(t,text='Course Name')
    l2.place(x=30,y=100)

    e2=Entry(t,width=25)
    e2.place(x=200,y=100)

    l3=Label(t,text='Course Duration')
    l3.place(x=30,y=160)

    e3=Entry(t,width=25)
    e3.place(x=200,y=160)

    
def showdelete():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('page3db')
    def deletedata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        xa=int(a1.get())
        sql="delete from course where code=%d"%(xa)
        cur.execute(sql)
        db.commit()
        messagebox.showinfo('hi','deleted')
        db.close()
        a1.delete(0,100)
    l6=Label(t,text='Course Details',font=('arial',15))
    l6.place(x=150,y=7) 
    
    a=Label(t,text='Course Code')
    a.place(x=60,y=70)
    a1=Entry(t,width=20)
    a1.place(x=150,y=70)
    b=Button(t,text='Delete',command=deletedata)
    b.place(x=100,y=110)
    
    
    
def showupdate():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('page4db')
    lt=[]
    def filldata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        sql="select code from course"
        cur.execute(sql)
        data=cur.fetchall()
        for res in data:
            lt.append(res[0])
        db.close()


    def updatedata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        xa=int(a1.get())
        xb=b1.get()
        xc=d1.get()
        
        sql="update course set name='%s',duration='%s' where code=%d"%(xb,xc,xa)
         
        cur.execute(sql)
        db.commit()
        messagebox.showinfo('hi','update done')
        a1.delete(0,100)
         
        b1.delete(0,data[0])
        d1.delete(0,data[1])
        
        
    l6=Label(t,text='Course Details',font=('arial',15))
    l6.place(x=150,y=7)            
    a=Label(t,text='Couse Code')
    a.place(x=30,y=60)
    a1=ttk.Combobox(t)
    filldata()
    a1['values']=lt
    a1.place(x=150,y=60)
    
    b=Label(t,text='Course Name')
    b.place(x=30,y=100)
    b1=Entry(t,width=30)
    b1.place(x=150,y=100)
    d=Label(t,text='Course Duration')
    d.place(x=30,y=130)
    d1=Entry(t,width=30)
    d1.place(x=150,y=130)
    
    p=Button(t,text='update',command=updatedata)
    p.place(x=150,y=200)
    t.mainloop()
def showdatashow():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('page5db')

    def showdata():
        global recd
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        sql="select*from course"
        cur.execute(sql)
        l6=Label(t,text='Course Details',font=('arial',20))
        l6.place(x=200,y=10)
        data=cur.fetchall()
        for res in data:
            recd=recd+'\t'+str(res[0])
            recd=recd+'\t'+(res[1])
            recd=recd+'\t'+(res[2])
            
            recd=recd+'\n'
        db.close()
    e=Text(t,width=150,height=50)
    showdata()
    e.insert(tkinter.END,recd)
    e.place(x=10,y=70)
    t.mainloop()
    
    



t=tkinter.Tk()
t.geometry('640x480')
t.title('database tkinter')
b1=Button(t,text='Insert',command=showinsert)
b1.place(x=50,y=50)
def showfind():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('page2db')
    lt=[]

    #combobox function
    def filldata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        sql="Select  Code from course"
        cur.execute(sql)
        data=cur.fetchall()
        for res in data:
            lt.append(res[0])
        db.close()

    #find data using billno as primary key
    def finddata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        xa=int(e1.get())
        #delete previous data find before
        e2.delete(0,100)
        e3.delete(0,100)
        
        
        sql="Select name,duration from course where code=%d"%(xa)
        cur.execute(sql)
        #fetchone to get data using index positions
        data=cur.fetchone()
        e2.insert(0,data[0])
        e3.insert(0,data[1])
        
        db.close()
    l1=Label(t,text='Course Code')
    l1.place(x=30,y=40)
    

    b1=Button(t,text='Find',bg='pink',command=finddata)
    b1.place(x=30,y=60)

    e1=ttk.Combobox(t)
    #call function filldata below
    filldata()
    e1['values']=lt
    e1.place(x=200,y=50)
    l6=Label(t,text='Course Details',font=('arial',15))
    l6.place(x=200,y=7)
        

    l2=Label(t,text='Course Name')
    l2.place(x=30,y=100)

    e2=Entry(t,width=25)
    e2.place(x=200,y=100)

    l3=Label(t,text='Course Duration')
    l3.place(x=30,y=160)

    e3=Entry(t,width=25)
    e3.place(x=200,y=160)
b1=Button(t,text='Insert',command=showinsert)
b1.place(x=50,y=50)
b2=Button(t,text='Find',command=showfind)
b2.place(x=100,y=50)
b3=Button(t,text='Delete',command=showdelete)
b3.place(x=150,y=50)
b4=Button(t,text='Update',command=showupdate)
b4.place(x=200,y=50)
b5=Button(t,text='Show',command=showdatashow)
b5.place(x=250,y=50)
t.mainloop()