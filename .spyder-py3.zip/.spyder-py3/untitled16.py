import threading
import time

def pathak():
    
t=threading.Thread(target=pathak)
t.start()