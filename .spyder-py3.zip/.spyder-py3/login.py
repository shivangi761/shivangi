from tkinter import messagebox
import tkinter
from tkinter import *
from tkinter import ttk

# create
t= tkinter.Tk()
#size
t.geometry('800x800')
t.title('my first screen')
def login():
    xa=d.get()
    xb=f.get()
    if xa=='test'and xb=='123':
        messagebox.showinfo('hii','success')
    else:
        messagebox.showinfo('hii','failed')
        
b=Label(t,text='Name')
b.place(x=50,y=60)
d=Entry(t,width=30)
d.place(x=500,y=60)
e=Label(t,text='Password')
e.place(x=50,y=100)
f=Entry(t,width=30,show='*')
f.place(x=500,y=100)
btn=Button(t,text='Login',command=login)
btn.place(x=300,y=200)
btn=Button(t,text='Cancel')
btn.place(x=500,y=200)
t.mainloop()