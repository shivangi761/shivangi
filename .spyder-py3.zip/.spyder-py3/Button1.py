import tkinter
from tkinter import *
from tkinter import ttk
t= tkinter.Tk()
#size
t.geometry('400x400')
t.title('my first screen')
a=Label(t,text='Python')
a.place(x=180,y=10)
sp=Spinbox(t,form_=1,to=100)
sp.place(x=150,y=50)
btn=Button(t,text='color')
btn.place(x=50,y=70)
t.mainloop()
