import tkinter 
from tkinter import*
from tkinter import ttk
t=tkinter.Tk()
t.geometry('800x800')
t.title('my first screen')
def first():
    at=Toplevel(t)
    at.geometry('600x600')
    am=Label(at,text='My First')
    am.place(x=200,y=50)
    at.config(bg='pink')
    at.mainloop()
a=Button(t,text='First',command=first)
a.place(x=40,y=60)
b=Button(t,text='Second')
b.place(x=200,y=60)
d=Button(t,text='Third')
d.place(x=40,y=100)
f=Button(t,text='Fourth')
f.place(x=200,y=100)
t.mainloop()