import sys
print(sys.executable)