import tkinter
import pymysql
from tkinter import *
from tkinter import ttk
from tkinter import messagebox 
recd=''
def showinsert():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('page1db')
        #code for db connectivity button
    def savedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            xa=int(e1.get())
            xb=e2.get()
            xc=e3.get()
            xd=e4.get()
            xe=int(e5.get())
            sql="insert into teacher values(%d,'%s','%s','%s',%d)"%(xa,xb,xc,xd,xe)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('Hi','Saved')
            db.close()
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
    l6=Label(t,text='Teacher Details',font=('arial',20))
    l6.place(x=200,y=10)
    l1=Label(t,text='Teacher_ID')
    l1.place(x=100,y=70)

    e1=Entry(t,width=25)
    e1.place(x=250,y=70)

    l2=Label(t,text='Teacher_Name')
    l2.place(x=100,y=110)

    e2=Entry(t,width=25)
    e2.place(x=250,y=110)

    l3=Label(t,text='Teacher_Department')
    l3.place(x=100,y=150)

    e3=Entry(t,width=25)
    e3.place(x=250,y=150)

    l4=Label(t,text='Teacher_Gender')
    l4.place(x=100,y=190)

    e4=Entry(t,width=25)
    e4.place(x=250,y=190)

    l5=Label(t,text='Teacher_Salary')
    l5.place(x=100,y=230)

    e5=Entry(t,width=25)
    e5.place(x=250,y=230)

    b1=Button(t,text='Save',bg='pink',command=savedata)
    b1.place(x=200,y=270)

    b2=Button(t,text='Close',bg='pink')
    b2.place(x=300,y=270)
    t.mainloop()
def showfind():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('page2db')
    lt=[]

    #combobox function
    def filldata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        sql="Select t_id from teacher"
        cur.execute(sql)
        data=cur.fetchall()
        for res in data:
            lt.append(res[0])
        db.close()

    #find data using billno as primary key
    def finddata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        xa=int(e1.get())
        #delete previous data find before
        e2.delete(0,100)
        e3.delete(0,100)
        e4.delete(0,100)
        e5.delete(0,100)
        
        sql="Select name,department,gender,salary from teacher where t_id=%d"%(xa)
        cur.execute(sql)
        #fetchone to get data using index positions
        data=cur.fetchone()
        e2.insert(0,data[0])
        e3.insert(0,data[1])
        e4.insert(0,data[2])
        e5.insert(0,data[3])
        db.close()
    l6=Label(t,text='Teacher Details',font=('arial',20))
    l6.place(x=200,y=7)
        

    l1=Label(t,text='Teacher_ID')
    l1.place(x=100,y=50)

    b1=Button(t,text='Find',bg='pink',command=finddata)
    b1.place(x=100,y=80)

    e1=ttk.Combobox(t)
    #call function filldata below
    filldata()
    e1['values']=lt
    e1.place(x=250,y=50)

    l2=Label(t,text='Teacher_Name')
    l2.place(x=100,y=120)

    e2=Entry(t,width=25)
    e2.place(x=250,y=120)

    l3=Label(t,text='Teacher_Department')
    l3.place(x=100,y=150)

    e3=Entry(t,width=25)
    e3.place(x=250,y=150)

    l4=Label(t,text='Teacher_Gender')
    l4.place(x=100,y=190)

    e4=Entry(t,width=25)
    e4.place(x=250,y=190)

    l5=Label(t,text='Teacher_Salary')
    l5.place(x=100,y=230)

    e5=Entry(t,width=25)
    e5.place(x=250,y=230)
    
def showdelete():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('page3db')
    def deletedata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        xa=int(a1.get())
        sql="delete from teacher where t_id=%d"%(xa)
        cur.execute(sql)
        db.commit()
        messagebox.showinfo('hi','deleted')
        db.close()
        a1.delete(0,100)
    l6=Label(t,text='Teacher Details',font=('arial',20))
    l6.place(x=200,y=30)
    
        
    a=Label(t,text='Teacher_ID')
    a.place(x=150,y=100)
    a1=Entry(t,width=20)
    a1.place(x=250,y=100)
    b=Button(t,text='Delete',bg='pink',command=deletedata)
    b.place(x=300,y=150)
def showupdate():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('page4db')
    lt=[]
    def filldata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        sql="select t_id from teacher"
        cur.execute(sql)
        data=cur.fetchall()
        for res in data:
            lt.append(res[0])
        db.close()


    def updatedata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        xa=int(a1.get())
        xb=b1.get()
        xc=d1.get()
        xd=f1.get()
        xe=int(h1.get())
        sql="update teacher set name='%s',department='%s',gender='%s',salary=%d where t_id=%d"%(xb,xc,xd,xe,xa)
         
        cur.execute(sql)
        db.commit()
        messagebox.showinfo('hi','update done')
        a1.delete(0,100)
         
        b1.delete(0,data[0])
        d1.delete(0,data[1])
        f1.delete(0,data[2])
        h1.delete(0,data[3])
        
    l6=Label(t,text='Teacher Details',font=('arial',20))
    l6.place(x=150,y=10)
               
    a=Label(t,text='Teacher_ID')
    a.place(x=100,y=50)
    a1=ttk.Combobox(t)
    filldata()
    a1['values']=lt
    a1.place(x=250,y=50)
    
    b=Label(t,text='Teacher_Name')
    b.place(x=100,y=80)
    b1=Entry(t,width=40)
    b1.place(x=250,y=80)
    d=Label(t,text='Teacher_Department')
    d.place(x=100,y=130)
    d1=Entry(t,width=40)
    d1.place(x=250,y=130)
    f=Label(t,text='Teacher_Gender')
    f.place(x=100,y=160)
    f1=Entry(t,width=40)
    f1.place(x=250,y=160)
    h=Label(t,text='Teacher_Salary')
    h.place(x=100,y=190)
    h1=Entry(t,width=40)
    h1.place(x=250,y=190)
    p=Button(t,text='update',bg='pink',command=updatedata)
    p.place(x=300,y=250)
    t.mainloop()
def showdatashow():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('page5db')
    def showdata():
        global recd
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        sql="select*from teacher"
        cur.execute(sql)
        l6=Label(t,text='Teacher Details',font=('arial',20))
        l6.place(x=200,y=10)
        data=cur.fetchall()
        for res in data:
            recd=recd+'\t'+str(res[0])
            recd=recd+'\t'+(res[1])
            recd=recd+'\t'+(res[2])
            recd=recd+'\t'+(res[3])
            recd=recd+'\t'+str(res[4])
            recd=recd+'\n'
        db.close()
    
    e=Text(t,width=150,height=100)
    showdata()
    e.insert(tkinter.END,recd)
    e.place(x=10,y=70)
    t.mainloop()
 
    


t=tkinter.Tk()
t.geometry('640x480')
t.title('database tkinter')
b1=Button(t,text='Insert',command=showinsert)
b1.place(x=50,y=50)
b2=Button(t,text='Find',command=showfind)
b2.place(x=100,y=50)
b3=Button(t,text='Delete',command=showdelete)
b3.place(x=150,y=50)
b4=Button(t,text='Update',command=showupdate)
b4.place(x=200,y=50)
b5=Button(t,text='Show',command=showdatashow)
b5.place(x=250,y=50)
t.mainloop()

    
       