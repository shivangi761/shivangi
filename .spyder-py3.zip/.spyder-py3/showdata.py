import tkinter 
from tkinter import*
from tkinter import ttk
from tkinter import messagebox
import pymysql

t=tkinter.Tk()
t.geometry('800x800')
t.title('my first screen')
recd=''
def showdata():
    global recd
    db=pymysql.connect(host='localhost',user='root',password='root',database='testdb')
    cur=db.cursor()
    sql="select*from billing"
    cur.execute(sql)
    data=cur.fetchall()
    for res in data:
        recd=recd+'\t'+str(res[0])
        recd=recd+'\t'+(res[1])
        recd=recd+'\t'+(res[2])
        recd=recd+'\t'+(res[3])
        recd=recd+'\t'+str(res[4])
        recd=recd+'\n'
    db.close()
e=Text(t,width=150,height=50)
showdata()
e.insert(tkinter.END,recd)
e.place(x=10,y=10)

t.mainloop()