import threading
import time

def show():
    n='Rajeev'
    for m in n:
        time.sleep(1)
        print(m)
    
        
t=threading.Thread(target=show)
t.start()