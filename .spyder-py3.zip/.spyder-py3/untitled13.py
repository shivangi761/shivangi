import threading
import time

def hello():
    print('wait for 5 sec')
    time.sleep(5)
    print('hi')
    print('wait for 3 sec')
    time.sleep(3)
    print('hello')
t=threading.Thread(target=hello)
t.start()