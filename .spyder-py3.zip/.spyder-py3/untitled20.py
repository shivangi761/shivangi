import pymysql
print(pymysql.__version__)