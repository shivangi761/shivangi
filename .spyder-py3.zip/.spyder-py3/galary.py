import cv2
img=cv2.imread('abc.jpg',50)
cv2.imshow('MyImage',img)
cv2.waitKey(0)