from tkinter import messagebox
import tkinter
from tkinter import *
from tkinter import ttk

# create
t= tkinter.Tk()
#size
t.geometry('200x200')
t.title('my first screen')
def hello():
    messagebox.showinfo('hi','welcome')
btn=Button(t,text='Hello',command=hello)
btn.place(x=80,y=80)
t.mainloop()