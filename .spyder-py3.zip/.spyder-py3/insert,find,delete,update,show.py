import tkinter
import pymysql
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
recd=''
def showinsert():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('bill1db')
    #code for db connectivity button
    def savedata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='testdb')
        cur=db.cursor()
        xa=int(e1.get())
        xb=e2.get()
        xc=e3.get()
        xd=e4.get()
        xe=int(e5.get())
        sql="insert into billing values(%d,'%s','%s','%s',%d)"%(xa,xb,xc,xd,xe)
        cur.execute(sql)
        db.commit()
        messagebox.showinfo('Hi','Saved')
        db.close()
        e1.delete(0,100)
        e2.delete(0,100)
        e3.delete(0,100)
        e4.delete(0,100)
        e5.delete(0,100)

    l6=Label(t,text='Bill Form',font=('arial',20))
    l6.place(x=300,y=10)
    l1=Label(t,text='Billno')
    l1.place(x=30,y=40)

    e1=Entry(t,width=18)
    e1.place(x=80,y=40)

    l2=Label(t,text='Cname')
    l2.place(x=30,y=80)

    e2=Entry(t,width=18)
    e2.place(x=80,y=80)

    l3=Label(t,text='City')
    l3.place(x=30,y=120)

    e3=Entry(t,width=18)
    e3.place(x=80,y=120)

    l4=Label(t,text='Item')
    l4.place(x=30,y=160)

    e4=Entry(t,width=18)
    e4.place(x=80,y=160)

    l5=Label(t,text='Amount')
    l5.place(x=30,y=200)

    e5=Entry(t,width=18)
    e5.place(x=80,y=200)

    b1=Button(t,text='Save',command=savedata)
    b1.place(x=30,y=240)

    b2=Button(t,text='Close')
    b2.place(x=80,y=240)
    t.mainloop()
def showfind():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('bill2db')
    lt=[]

    #combobox function
    def filldata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='testdb')
        cur=db.cursor()
        sql="Select billno from billing"
        cur.execute(sql)
        data=cur.fetchall()
        for res in data:
            lt.append(res[0])
        db.close()

    #find data using billno as primary key
    def finddata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='testdb')
        cur=db.cursor()
        xa=int(e1.get())
        #delete previous data find before
        e2.delete(0,100)
        e3.delete(0,100)
        e4.delete(0,100)
        e5.delete(0,100)
        
        sql="Select cname,city,item,amount from billing where billno=%d"%(xa)
        cur.execute(sql)
        #fetchone to get data using index positions
        data=cur.fetchone()
        e2.insert(0,data[0])
        e3.insert(0,data[1])
        e4.insert(0,data[2])
        e5.insert(0,data[3])
        db.close()
    l6=Label(t,text='Bill Form',font=('arial',20))
    l6.place(x=300,y=10)  

    l1=Label(t,text='Billno')
    l1.place(x=30,y=40)

    b1=Button(t,text='Find',command=finddata)
    b1.place(x=30,y=80)

    e1=ttk.Combobox(t)
    #call function filldata below
    filldata()
    e1['values']=lt
    e1.place(x=80,y=40)

    l2=Label(t,text='Cname')
    l2.place(x=30,y=120)

    e2=Entry(t,width=18)
    e2.place(x=80,y=120)

    l3=Label(t,text='City')
    l3.place(x=30,y=160)

    e3=Entry(t,width=18)
    e3.place(x=80,y=160)

    l4=Label(t,text='Item')
    l4.place(x=30,y=200)

    e4=Entry(t,width=18)
    e4.place(x=80,y=200)

    l5=Label(t,text='Amount')
    l5.place(x=30,y=240)

    e5=Entry(t,width=18)
    e5.place(x=80,y=240)
def showdelete():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('bill3db')
    def deletedata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='testdb')
        cur=db.cursor()
        xa=int(a1.get())
        sql="delete from billing where billno=%d"%(xa)
        cur.execute(sql)
        db.commit()
        messagebox.showinfo('hi','deleted')
        db.close()
        a1.delete(0,100)
    l6=Label(t,text='Bill Form',font=('arial',20))
    l6.place(x=300,y=10)    
    a=Label(t,text='BillNo')
    a.place(x=60,y=30)
    a1=Entry(t,width=20)
    a1.place(x=150,y=30)
    b=Button(t,text='Delete',command=deletedata)
    b.place(x=100,y=90)
def showupdate():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('bill4db')
    lt=[]
    def filldata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='testdb')
        cur=db.cursor()
        sql="select billno from billing"
        cur.execute(sql)
        data=cur.fetchall()
        for res in data:
            lt.append(res[0])
        db.close()


    def updatedata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='testdb')
        cur=db.cursor()
        xa=int(a1.get())
        xb=b1.get()
        xc=d1.get()
        xd=f1.get()
        xe=int(h1.get())
        sql="update billing set cname='%s',city='%s',item='%s',amount=%d where billno=%d"%(xb,xc,xd,xe,xa)
         
        cur.execute(sql)
        db.commit()
        messagebox.showinfo('hi','update done')
        a1.delete(0,100)
         
        b1.delete(0,data[0])
        d1.delete(0,data[1])
        f1.delete(0,data[2])
        h1.delete(0,data[3])
        
    l6=Label(t,text='Bill Form',font=('arial',20))
    l6.place(x=300,y=10)           
    a=Label(t,text='billno')
    a.place(x=30,y=40)
    a1=ttk.Combobox(t)
    filldata()
    a1['values']=lt
    a1.place(x=100,y=40)
    
    b=Label(t,text='C Name')
    b.place(x=30,y=100)
    b1=Entry(t,width=40)
    b1.place(x=100,y=100)
    d=Label(t,text='City')
    d.place(x=30,y=130)
    d1=Entry(t,width=40)
    d1.place(x=100,y=130)
    f=Label(t,text='Item')
    f.place(x=30,y=160)
    f1=Entry(t,width=40)
    f1.place(x=100,y=160)
    h=Label(t,text='Ammount')
    h.place(x=30,y=190)
    h1=Entry(t,width=40)
    h1.place(x=100,y=190)
    p=Button(t,text='update',command=updatedata)
    p.place(x=150,y=250)
    t.mainloop()
def showdatashow():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('bill5db')
    def showdata():
        global recd
        db=pymysql.connect(host='localhost',user='root',password='root',database='testdb')
        cur=db.cursor()
        sql="select * from billing"
        cur.execute(sql)
        l6=Label(t,text='Bill Form',font=('arial',20))
        l6.place(x=200,y=10)
        data=cur.fetchall()
        for res in data:
            recd=recd+'\t'+str(res[0])
            recd=recd+'\t'+(res[1])
            recd=recd+'\t'+(res[2])
            recd=recd+'\t'+(res[3])
            recd=recd+'\t'+str(res[4])
            recd=recd+'\n'
        db.close()
    
    
    e=Text(t,width=150,height=50)
    showdata()
    e.insert(tkinter.END,recd)
    e.place(x=10,y=70)
    t.mainloop()
    



t=tkinter.Tk()
t.geometry('640x480')
t.title('database tkinter')
b1=Button(t,text='Insert',command=showinsert)
b1.place(x=50,y=50)
b2=Button(t,text='Find',command=showfind)
b2.place(x=100,y=50)
b3=Button(t,text='Delete',command=showdelete)
b3.place(x=150,y=50)
b4=Button(t,text='Update',command=showupdate)
b4.place(x=200,y=50)
b5=Button(t,text='Show',command=showdatashow)
b5.place(x=250,y=50)
t.mainloop()