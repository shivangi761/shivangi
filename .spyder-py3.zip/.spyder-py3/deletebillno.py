from tkinter import messagebox
import pymysql
import tkinter 
from tkinter import*
from tkinter import ttk
t=tkinter.Tk()
t.geometry('400x400')
t.title('my first screen')
def deletedata():
    if len(a1.get())==0 or  len(b1.get())==0 or len(d1.get())==0 or len(f1.get())==0 or len(h1.get())==0:
        messagebox.showerror('hii','please check all')
    else:
        db=pymysql.connect(host='localhost',user='root',password='root',database='testdb')
        cur=db.cursor()
        xa=int(a1.get())
        sql="delete from billing where billno=%d"%(xa)
        cur.execute(sql)
        db.commit()
        messagebox.showinfo('hi','deleted')
        db.close()
        a1.delete(0,100)
    
a=Label(t,text='BillNo')
a.place(x=60,y=30)
a1=Entry(t,width=20)

a1.place(x=150,y=30)
b=Button(t,text='Delete',command=deletedata)
b.place(x=100,y=90)
t.mainloop()
