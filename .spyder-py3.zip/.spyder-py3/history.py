# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

## ---(Sat Jun 29 13:41:25 2024)---
runfile('C:/Users/GOD/.spyder-py3/temp.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled0.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Mon Jul  1 07:01:31 2024)---
runfile('C:/Users/GOD/.spyder-py3/temp.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Mon Jul  1 16:01:57 2024)---
runfile('C:/Users/GOD/.spyder-py3/temp.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Mon Jul  1 21:08:51 2024)---
runfile('C:/Users/GOD/.spyder-py3/temp.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Tue Jul 23 15:54:43 2024)---
runfile('C:/Users/GOD/.spyder-py3/temp.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Jul 24 15:40:16 2024)---
runfile('C:/Users/GOD/.spyder-py3/shivangi.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/temp.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Jul 24 22:35:56 2024)---
runfile('C:/Users/GOD/.spyder-py3/shivangi.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/temp.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled0.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/temp1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Jul 25 06:19:39 2024)---
runfile('C:/Users/GOD/.spyder-py3/Hello.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/temp1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/Button1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/shivangi.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/Button1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/shivangi.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/shivangi.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled3.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Jul 25 13:50:58 2024)---
runfile('C:/Users/GOD/.spyder-py3/Button1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Jul 25 15:33:56 2024)---
runfile('C:/Users/GOD/.spyder-py3/shivangi.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Jul 25 15:51:54 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled0.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/Hello.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled3.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/login.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Jul 25 19:34:47 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Jul 25 21:01:43 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled3.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Jul 25 21:26:48 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/temp1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled2.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Jul 26 14:35:45 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled2.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Jul 26 15:42:47 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled4.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled5.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/cal.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Jul 26 20:56:15 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled6.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/shivangi.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled6.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled7.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sat Jul 27 15:41:04 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled9.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled8.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled9.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled7.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled6.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled8.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sat Jul 27 21:19:34 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled6.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled10.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled9.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled10.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/cal.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled10.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled9.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled10.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sun Jul 28 08:03:59 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled10.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/cal.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled10.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled11.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled10.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled11.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled10.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sun Jul 28 17:22:57 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled11.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled10.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sun Jul 28 19:52:18 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled11.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled9.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled11.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled9.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled11.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled9.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled11.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Mon Jul 29 15:28:10 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled8.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled12.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled13.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled14.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled15.py', wdir='C:/Users/GOD/.spyder-py3')
pathak
runfile('C:/Users/GOD/.spyder-py3/untitled15.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Tue Jul 30 13:50:06 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled16.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Mon Aug  5 21:35:32 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled18.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/bill save.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled19.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled20.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Tue Aug  6 15:39:53 2024)---
runfile('C:/Users/GOD/.spyder-py3/bill save.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/deletebillno.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/find.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Aug  7 13:49:13 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled3.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled4.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled5.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled6.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Aug  7 15:41:46 2024)---
runfile('C:/Users/GOD/.spyder-py3/find.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/update.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/find.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/update.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/find.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/update.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/find.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/update.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/find.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Aug  7 20:54:30 2024)---
runfile('C:/Users/GOD/.spyder-py3/find.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/update.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/find.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled8.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled10.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Aug  8 08:55:38 2024)---
runfile('C:/Users/GOD/.spyder-py3/find.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/find.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/bill save.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/update.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Aug  8 14:52:13 2024)---
runfile('C:/Users/GOD/.spyder-py3/registration.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Aug  8 15:03:36 2024)---
runfile('C:/Users/GOD/.spyder-py3/registration.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled10.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled12.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/shivangi.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Aug  8 21:24:12 2024)---
runfile('C:/Users/GOD/.spyder-py3/showdata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Aug  9 07:30:30 2024)---
runfile('C:/Users/GOD/.spyder-py3/insert,find,delete,update,show.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Aug  9 14:50:05 2024)---
runfile('C:/Users/GOD/.spyder-py3/insert,find,delete,update,show.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/registration.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/insert,find,delete,update,show.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/showdata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/insert,find,delete,update,show.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/teachertbl.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Aug  9 18:20:33 2024)---
runfile('C:/Users/GOD/.spyder-py3/teachertbl.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Aug  9 21:18:41 2024)---
runfile('C:/Users/GOD/.spyder-py3/student.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/teachertbl.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/insert,find,delete,update,show.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/teachertbl.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/student.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sat Aug 10 12:13:48 2024)---
runfile('C:/Users/GOD/.spyder-py3/registration.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/teachertbl.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/registration.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sat Aug 10 14:40:26 2024)---
runfile('C:/Users/GOD/.spyder-py3/registration.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/abc shop.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled5.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/registration.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled5.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/registration.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/insert,find,delete,update,show.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/teachertbl.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sat Aug 10 16:30:52 2024)---
runcell(0, 'C:/Users/GOD/.spyder-py3/insert,find,delete,update,show.py')
runfile('C:/Users/GOD/.spyder-py3/insert,find,delete,update,show.py', wdir='C:/Users/GOD/.spyder-py3')
runcell(0, 'C:/Users/GOD/.spyder-py3/insert,find,delete,update,show.py')

## ---(Sat Aug 10 20:51:42 2024)---
runfile('C:/Users/GOD/.spyder-py3/insert,find,delete,update,show.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/teachertbl.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/student.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/teachertbl.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sun Aug 11 09:02:02 2024)---
runfile('C:/Users/GOD/.spyder-py3/insert,find,delete,update,show.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/teachertbl.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/student.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/student.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/student.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sun Aug 11 15:12:58 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled18.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/student.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled18.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/Exam.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/teachertbl.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sun Aug 11 16:44:20 2024)---
runfile('C:/Users/GOD/.spyder-py3/Exam.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/teachertbl.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/Exam.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/teachertbl.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/student.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/course.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/Exam.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sun Aug 11 19:49:49 2024)---
runfile('C:/Users/GOD/.spyder-py3/dashboard.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Mon Aug 12 11:42:11 2024)---
runfile('C:/Users/GOD/.spyder-py3/dashboard.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/course.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Mon Aug 12 15:05:47 2024)---
runfile('C:/Users/GOD/.spyder-py3/dashboard.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/bill save.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/deletebillno.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/bill save.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Mon Aug 12 21:15:57 2024)---
runfile('C:/Users/GOD/.spyder-py3/dashboard.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Tue Aug 13 09:42:51 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/login dashboard.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled18.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Tue Aug 13 15:23:19 2024)---
runfile('C:/Users/GOD/.spyder-py3/bill save.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/login dashboard.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Tue Aug 13 16:34:40 2024)---
runfile('C:/Users/GOD/.spyder-py3/dashboard.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/login dashboard.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Tue Aug 13 17:16:54 2024)---
runfile('C:/Users/GOD/.spyder-py3/Exam.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/course.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/Exam.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/login dashboard.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Tue Aug 13 22:21:44 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/service_center.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Aug 14 10:37:50 2024)---
runfile('C:/Users/GOD/.spyder-py3/service_center.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Aug 14 15:25:07 2024)---
runfile('C:/Users/GOD/.spyder-py3/service_center.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Aug 15 12:08:03 2024)---
runfile('C:/Users/GOD/.spyder-py3/productcategory.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/service_center.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/productcategory.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/service type.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/productcategory.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/service type.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/engineer.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Aug 16 09:13:48 2024)---
runfile('C:/Users/GOD/.spyder-py3/customer.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/engineer.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/customer.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/staff.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled19.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled20.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/callassignment.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/staff.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/service_center.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/service type.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/callclose.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Aug 16 19:50:30 2024)---
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/productcategory.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Tue Aug 20 12:41:56 2024)---
runfile('C:/Users/GOD/.spyder-py3/login dashboard.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Aug 21 15:05:42 2024)---
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/service_center.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/insert,find,delete,update,show.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/showdata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/update.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Aug 21 15:35:56 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled18.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Aug 21 20:24:45 2024)---
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/service_center.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/service_center.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Aug 22 07:59:46 2024)---
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Aug 22 09:10:40 2024)---
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Aug 22 14:05:32 2024)---
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Aug 22 14:37:21 2024)---
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Aug 22 15:37:49 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Aug 22 21:06:56 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindashboard1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Aug 23 15:44:35 2024)---
runfile('C:/Users/GOD/.spyder-py3/mailutil.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Aug 23 20:02:24 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/Button1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled4.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled5.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/temp1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/Button1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/Hello.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sat Aug 24 07:18:44 2024)---
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sun Aug 25 09:49:36 2024)---
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sun Aug 25 21:18:01 2024)---
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/login dashboard.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Mon Aug 26 15:29:29 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Mon Aug 26 17:16:27 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Mon Aug 26 19:52:16 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/insert,find,delete,update,show.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/bill save.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/teachertbl.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/login.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled6.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/abc shop.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/registration.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Tue Aug 27 08:34:32 2024)---
runfile('C:/Users/GOD/.spyder-py3/bill save.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/bill save.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/bill save.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/bill save.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Tue Aug 27 18:31:04 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Aug 28 11:13:31 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Aug 28 12:11:36 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Aug 28 15:44:26 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Aug 28 20:10:01 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Aug 28 22:25:19 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Aug 29 10:47:58 2024)---
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runcell(0, 'C:/Users/GOD/.spyder-py3/logindata.py')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Aug 29 15:23:25 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Aug 29 20:23:42 2024)---
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Aug 30 10:57:36 2024)---
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Aug 30 12:27:55 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runcell(0, 'C:/Users/GOD/.spyder-py3/dashboard1.py')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Aug 30 13:25:43 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')
runcell(0, 'C:/Users/GOD/.spyder-py3/canvas.py')
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')
runcell(0, 'C:/Users/GOD/.spyder-py3/canvas.py')
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Aug 30 22:09:34 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sun Sep  1 08:56:48 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/service_center.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled17.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Mon Sep  2 08:36:46 2024)---
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Mon Sep  2 11:59:00 2024)---
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard2.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/registration.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Mon Sep  2 15:33:20 2024)---
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Tue Sep  3 11:55:25 2024)---
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Tue Sep  3 20:22:15 2024)---
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Sep  4 07:46:44 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled0.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Sep  4 08:26:03 2024)---
runfile('C:/Users/GOD/.spyder-py3/canvaspathak.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled18.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Sep  4 12:13:37 2024)---
runfile('C:/Users/GOD/.spyder-py3/canvaslabel.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Sep  4 14:28:41 2024)---
runfile('C:/Users/GOD/.spyder-py3/canvaslabel.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Sep  4 15:12:29 2024)---
runfile('C:/Users/GOD/.spyder-py3/canvaslabel.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Wed Sep  4 16:37:52 2024)---
runfile('C:/Users/GOD/.spyder-py3/canvaslabel.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Sep  5 12:10:19 2024)---
runfile('C:/Users/GOD/.spyder-py3/canvaslabel.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Sep  5 15:39:44 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvaslabel.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Sep  5 20:12:23 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvaslabel1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Sep  6 08:38:32 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Sep  6 13:19:16 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvaslabel1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvaslabel1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Sep  6 22:33:14 2024)---
runfile('C:/Users/GOD/.spyder-py3/canvaslabel1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sun Sep  8 19:18:54 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Tue Sep 10 13:51:46 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Tue Sep 10 14:12:32 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvaslabel1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Sep 13 09:44:05 2024)---
runfile('C:/Users/GOD/.spyder-py3/canvaslabel1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sun Sep 15 09:50:16 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sat Sep 21 21:06:09 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Sep 27 16:39:30 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled0.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled18.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Sep 27 16:58:33 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled18.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Mon Sep 30 11:56:39 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled18.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled19.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/untitled19.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/untitled20.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/untitled19.py', wdir='C:/Users/GOD')

## ---(Mon Sep 30 12:35:47 2024)---
runfile('C:/Users/GOD/.spyder-py3/untitled18.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/untitled19.py', wdir='C:/Users/GOD')

## ---(Thu Oct  3 22:30:00 2024)---
runfile('C:/Users/GOD/image.py', wdir='C:/Users/GOD')

## ---(Fri Oct  4 00:11:41 2024)---
runfile('C:/Users/GOD/image.py', wdir='C:/Users/GOD')

## ---(Fri Oct  4 07:33:29 2024)---
runfile('C:/Users/GOD/image.py', wdir='C:/Users/GOD')

## ---(Fri Oct  4 22:58:09 2024)---
runfile('C:/Users/GOD/imageshi.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/image.py', wdir='C:/Users/GOD')

## ---(Sat Oct  5 09:05:08 2024)---
runfile('C:/Users/GOD/image.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/imageshi.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/image.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/untitled0.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/image.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/pie.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/bar.py', wdir='C:/Users/GOD')

## ---(Sat Oct  5 11:39:53 2024)---
runfile('C:/Users/GOD/bar.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/pie.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/hist.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/mbar.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/untitled2.py', wdir='C:/Users/GOD')

## ---(Mon Oct  7 09:37:50 2024)---
runfile('C:/Users/GOD/untitled19.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/untitled20.py', wdir='C:/Users/GOD')

## ---(Mon Oct  7 11:14:25 2024)---
runfile('C:/Users/GOD/imagechart.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/imagebar.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/imagechart.py', wdir='C:/Users/GOD')

## ---(Mon Oct  7 11:31:32 2024)---
runfile('C:/Users/GOD/imagechart.py', wdir='C:/Users/GOD')

## ---(Mon Oct 21 20:58:55 2024)---
runfile('C:/Users/GOD/.spyder-py3/callassignment.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled19.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/untitled20.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Oct 31 21:32:14 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Thu Oct 31 21:50:05 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sat Nov  2 14:17:07 2024)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvaslabel1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindashboard1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Tue Jan  7 12:08:16 2025)---
runfile('C:/Users/GOD/imagechart.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/pie.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/.spyder-py3/logindashboard1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Tue Jan  7 12:20:07 2025)---
runfile('C:/Users/GOD/.spyder-py3/logindashboard1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Tue Jan  7 12:29:35 2025)---
runfile('C:/Users/GOD/.spyder-py3/logindashboard1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Mon Jan 20 14:09:13 2025)---
runfile('C:/Users/GOD/.spyder-py3/logindashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runcell(0, 'C:/Users/GOD/.spyder-py3/logindashboard1.py')
pip install pymysql
runcell(0, 'C:/Users/GOD/.spyder-py3/logindashboard1.py')

## ---(Mon Jan 20 21:42:52 2025)---
runfile('C:/Users/GOD/.spyder-py3/logindashboard1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Fri Jan 24 20:50:50 2025)---
runfile('C:/Users/GOD/.spyder-py3/logindashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvaslabel1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Mon Feb  3 21:24:18 2025)---
runfile('C:/Users/GOD/.spyder-py3/logindashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/callassignment.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/galary.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/abc shop.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/imagebar.py', wdir='C:/Users/GOD')
pip install pillow
runfile('C:/Users/GOD/imagebar.py', wdir='C:/Users/GOD')

## ---(Thu Feb  6 20:56:21 2025)---
runfile('C:/Users/GOD/imagebar.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/camera.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/imageshi.py', wdir='C:/Users/GOD')
runfile('C:/Users/GOD/.spyder-py3/canvaslabel1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Mon Feb 24 20:20:33 2025)---
runfile('C:/Users/GOD/.spyder-py3/canvaslabel1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindashboard1.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sat Mar  1 13:12:08 2025)---
runfile('C:/Users/GOD/.spyder-py3/canvaslabel1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/abc shop.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sun Mar 23 09:05:19 2025)---
runfile('C:/Users/GOD/.spyder-py3/mailutil.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Mon Mar 24 20:46:51 2025)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')

## ---(Sun Apr 13 13:51:20 2025)---
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindashboard1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/login dashboard.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvaslabel1.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvaspathak.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvas.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/canvaslabel.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/dashboard.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/mailutil.py', wdir='C:/Users/GOD/.spyder-py3')
import pymysql
print(pymysql._version_)
import pymysql
print("pymysql is installed.")
runfile('C:/Users/GOD/.spyder-py3/logindata.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/mailutil.py', wdir='C:/Users/GOD/.spyder-py3')
runfile('C:/Users/GOD/.spyder-py3/abc shop.py', wdir='C:/Users/GOD/.spyder-py3')