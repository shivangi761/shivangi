import tkinter
from tkinter import *
from tkinter import ttk

# create
t= tkinter.Tk()
#size
t.geometry('400x400')
t.title('my first screen')
a=Menu()
b=Menu()
d=Menu()
b.add_command(label='New')
b.add_separator()
b.add_command(label='open')
b.add_separator()
b.add_command(label='save')
b.add_separator()
b.add_command(label='Exit')
b.add_separator()
a.add_cascade(menu=b,label='File')
d.add_separator()
d.add_command(label='Cut')
d.add_separator()
d.add_command(label='Copy')
d.add_separator()
d.add_command(label='Paste')
d.add_command()
a.add_cascade(label='Edit',menu=d)
t.config(menu=a)
t.mainloop()