import threading
import time

def hello():
    for i in range(1,11):
        time.sleep(1)
        print(i)
t=threading.Thread(target=hello)
t.start()