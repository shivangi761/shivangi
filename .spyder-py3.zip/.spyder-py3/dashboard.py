import tkinter 
from tkinter import*
from tkinter import ttk
from tkinter import messagebox
import pymysql
def showdeshboard():
    recd=''
    
    t=tkinter.Tk()
    t.geometry('800x800')
    t.title('my first screen')
    a=Label(t,text='Course',font=('arial',30))
    a.place(x=10,y=40)
    
    
    def showinsert():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page1db')
        #code for db connectivity button
        def savedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            xa=int(e1.get())
            xb=e2.get()
            xc=e3.get()
            
            sql="insert into course values(%d,'%s','%s')"%(xa,xb,xc)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('Hi','Saved')
            db.close()
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
        l6=Label(t,text='Course Details',font=('arial',15))
        l6.place(x=200,y=7)
            
    
    
        l1=Label(t,text='Course Code')
        l1.place(x=60,y=70)
    
        e1=Entry(t,width=18)
        e1.place(x=200,y=70)
    
        l2=Label(t,text='Course Name')
        l2.place(x=60,y=100)
    
        e2=Entry(t,width=18)
        e2.place(x=200,y=100)
    
        l3=Label(t,text='Course Duration')
        l3.place(x=60,y=130)
    
        e3=Entry(t,width=18)
        e3.place(x=200,y=130)
    
        
    
        b1=Button(t,text='Save',bg='blue',command=savedata)
        b1.place(x=100,y=170)
    
        b2=Button(t,text='Close',bg='blue')
        b2.place(x=200,y=170)
        
    b1=Button(t,text='Insert',bg='pink',font=('arial',20),command=showinsert)
    b1.place(x=200,y=40)
    
    
    def showfind():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page2db')
        lt=[]
    
        #combobox function
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            sql="Select  Code from course"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()
    
        #find data using billno as primary key
        def finddata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            xa=int(e1.get())
            #delete previous data find before
            e2.delete(0,100)
            e3.delete(0,100)
            
            
            sql="Select name,duration from course where code=%d"%(xa)
            cur.execute(sql)
            #fetchone to get data using index positions
            data=cur.fetchone()
            e2.insert(0,data[0])
            e3.insert(0,data[1])
            
            db.close()
        l1=Label(t,text='Course Code')
        l1.place(x=30,y=40)
        
    
        b1=Button(t,text='Find',bg='pink',command=finddata)
        b1.place(x=30,y=60)
    
        e1=ttk.Combobox(t)
        #call function filldata below
        filldata()
        e1['values']=lt
        e1.place(x=200,y=50)
        l6=Label(t,text='Course Details',font=('arial',15))
        l6.place(x=200,y=7)
            
    
        l2=Label(t,text='Course Name')
        l2.place(x=30,y=100)
    
        e2=Entry(t,width=25)
        e2.place(x=200,y=100)
    
        l3=Label(t,text='Course Duration')
        l3.place(x=30,y=160)
    
        e3=Entry(t,width=25)
        e3.place(x=200,y=160)
        
        
    b2=Button(t,text='Find',bg='pink',font=('arial',20),command=showfind)
    b2.place(x=320,y=40)
    
    
    
    def showdelete():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page3db')
        def deletedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            xa=int(a1.get())
            sql="delete from course where code=%d"%(xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi','deleted')
            db.close()
            a1.delete(0,100)
        l6=Label(t,text='Course Details',font=('arial',15))
        l6.place(x=150,y=7) 
        
        a=Label(t,text='Course Code')
        a.place(x=60,y=70)
        a1=Entry(t,width=20)
        a1.place(x=150,y=70)
        b=Button(t,text='Delete',bg='blue',command=deletedata)
        b.place(x=100,y=110)
    
    b3=Button(t,text='Delete',bg='pink',font=('arial',20),command=showdelete)
    b3.place(x=420,y=40)
    
    def showupdate():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page4db')
        lt=[]
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            sql="select code from course"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()
             
    
        def updatedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            xa=int(a1.get())
            xb=b1.get()
            xc=d1.get()
            
            sql="update course set name='%s',duration='%s' where code=%d"%(xb,xc,xa)
             
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi','update done')
            a1.delete(0,100)
             
            b1.delete(0,data[0])
            d1.delete(0,data[1])
            
            
        l6=Label(t,text='Course Details',font=('arial',15))
        l6.place(x=150,y=7)            
        a=Label(t,text='Couse Code')
        a.place(x=30,y=60)
        a1=ttk.Combobox(t)
        filldata()
        a1['values']=lt
        a1.place(x=150,y=60)
        
        b=Label(t,text='Course Name')
        b.place(x=30,y=100)
        b1=Entry(t,width=30)
        b1.place(x=150,y=100)
        d=Label(t,text='Course Duration')
        d.place(x=30,y=130)
        d1=Entry(t,width=30)
        d1.place(x=150,y=130)
        
        p=Button(t,text='update',bg='blue',command=updatedata)
        p.place(x=150,y=200)
        
    b4=Button(t,text='Update',bg='pink',font=('arial',20),command=showupdate)
    b4.place(x=540,y=40)
    def showdatashow():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page5db')
    
        def showdata():
            global recd
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            sql="select*from course"
            cur.execute(sql)
            l6=Label(t,text='Course Details',font=('arial',20))
            l6.place(x=200,y=10)
            data=cur.fetchall()
            for res in data:
                recd=recd+'\t'+str(res[0])
                recd=recd+'\t'+(res[1])
                recd=recd+'\t'+(res[2])
                
                recd=recd+'\n'
            db.close()
        e=Text(t,width=150,height=50)
        showdata()
        e.insert(tkinter.END,recd)
        e.place(x=10,y=70)
    b5=Button(t,text='Show',bg='pink',font=('arial',20),command=showdatashow)
    b5.place(x=660,y=40)
    
    
    
    a1=Label(t,text='Teacher',font=('arial',30))
    a1.place(x=10,y=150)
    
    def showinsert():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page1db')
        #code for db connectivity button
        def savedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            xa=int(e1.get())
            xb=e2.get()
            xc=e3.get()
            xd=e4.get()
            xe=int(e5.get())
            sql="insert into teacher values(%d,'%s','%s','%s',%d)"%(xa,xb,xc,xd,xe)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('Hi','Saved')
            db.close()
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
        l6=Label(t,text='Teacher Details',font=('arial',20))
        l6.place(x=200,y=10)
        l1=Label(t,text='Teacher_ID')
        l1.place(x=100,y=70)
    
        e1=Entry(t,width=25)
        e1.place(x=250,y=70)
    
        l2=Label(t,text='Teacher_Name')
        l2.place(x=100,y=110)
    
        e2=Entry(t,width=25)
        e2.place(x=250,y=110)
    
        l3=Label(t,text='Teacher_Department')
        l3.place(x=100,y=150)
    
        e3=Entry(t,width=25)
        e3.place(x=250,y=150)
    
        l4=Label(t,text='Teacher_Gender')
        l4.place(x=100,y=190)
    
        e4=Entry(t,width=25)
        e4.place(x=250,y=190)
    
        l5=Label(t,text='Teacher_Salary')
        l5.place(x=100,y=230)
    
        e5=Entry(t,width=25)
        e5.place(x=250,y=230)
    
        b1=Button(t,text='Save',bg='blue',command=savedata)
        b1.place(x=200,y=270)
    
        b2=Button(t,text='Close',bg='blue')
        b2.place(x=300,y=270)
        
        
    b1=Button(t,text='Insert',bg='pink',font=('arial',20),command=showinsert)
    b1.place(x=200,y=140)
    def showfind():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page2db')
        lt=[]
    
        #combobox function
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            sql="Select t_id from teacher"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()
    
        #find data using billno as primary key
        def finddata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            xa=int(e1.get())
            #delete previous data find before
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
            
            sql="Select name,department,gender,salary from teacher where t_id=%d"%(xa)
            cur.execute(sql)
            #fetchone to get data using index positions
            data=cur.fetchone()
            e2.insert(0,data[0])
            e3.insert(0,data[1])
            e4.insert(0,data[2])
            e5.insert(0,data[3])
            db.close()
        l6=Label(t,text='Teacher Details',font=('arial',20))
        l6.place(x=200,y=7)
            
    
        l1=Label(t,text='Teacher_ID')
        l1.place(x=100,y=50)
    
        b1=Button(t,text='Find',bg='blue',command=finddata)
        b1.place(x=100,y=80)
    
        e1=ttk.Combobox(t)
        #call function filldata below
        filldata()
        e1['values']=lt
        e1.place(x=250,y=50)
    
        l2=Label(t,text='Teacher_Name')
        l2.place(x=100,y=120)
    
        e2=Entry(t,width=25)
        e2.place(x=250,y=120)
    
        l3=Label(t,text='Teacher_Department')
        l3.place(x=100,y=150)
    
        e3=Entry(t,width=25)
        e3.place(x=250,y=150)
    
        l4=Label(t,text='Teacher_Gender')
        l4.place(x=100,y=190)
    
        e4=Entry(t,width=25)
        e4.place(x=250,y=190)
    
        l5=Label(t,text='Teacher_Salary')
        l5.place(x=100,y=230)
    
        e5=Entry(t,width=25)
        e5.place(x=250,y=230)
        
    b2=Button(t,text='Find',bg='pink',font=('arial',20),command=showfind)
    b2.place(x=320,y=140)
    def showdelete():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page3db')
        def deletedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            xa=int(a1.get())
            sql="delete from teacher where t_id=%d"%(xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi','deleted')
            db.close()
            a1.delete(0,100)
        l6=Label(t,text='Teacher Details',font=('arial',20))
        l6.place(x=200,y=30)
        
            
        a=Label(t,text='Teacher_ID')
        a.place(x=150,y=100)
        a1=Entry(t,width=20)
        a1.place(x=250,y=100)
        b=Button(t,text='Delete',bg='blue',command=deletedata)
        b.place(x=300,y=150)
        
    b3=Button(t,text='Delete',bg='pink',font=('arial',20),command=showdelete)
    b3.place(x=420,y=140)
    def showupdate():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page4db')
        lt=[]
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            sql="select t_id from teacher"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()
    
    
        def updatedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            xa=int(a1.get())
            xb=b1.get()
            xc=d1.get()
            xd=f1.get()
            xe=int(h1.get())
            sql="update teacher set name='%s',department='%s',gender='%s',salary=%d where t_id=%d"%(xb,xc,xd,xe,xa)
             
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi','update done')
            a1.delete(0,100)
             
            b1.delete(0,data[0])
            d1.delete(0,data[1])
            f1.delete(0,data[2])
            h1.delete(0,data[3])
            
        l6=Label(t,text='Teacher Details',font=('arial',20))
        l6.place(x=150,y=10)
                   
        a=Label(t,text='Teacher_ID')
        a.place(x=100,y=50)
        a1=ttk.Combobox(t)
        filldata()
        a1['values']=lt
        a1.place(x=250,y=50)
        
        b=Label(t,text='Teacher_Name')
        b.place(x=100,y=80)
        b1=Entry(t,width=40)
        b1.place(x=250,y=80)
        d=Label(t,text='Teacher_Department')
        d.place(x=100,y=130)
        d1=Entry(t,width=40)
        d1.place(x=250,y=130)
        f=Label(t,text='Teacher_Gender')
        f.place(x=100,y=160)
        f1=Entry(t,width=40)
        f1.place(x=250,y=160)
        h=Label(t,text='Teacher_Salary')
        h.place(x=100,y=190)
        h1=Entry(t,width=40)
        h1.place(x=250,y=190)
        p=Button(t,text='update',bg='blue',command=updatedata)
        p.place(x=300,y=250)
        
    b4=Button(t,text='Update',bg='pink',font=('arial',20),command=showupdate)
    b4.place(x=540,y=140)
    def showdatashow():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page5db')
        def showdata():
            global recd
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            sql="select*from teacher"
            cur.execute(sql)
            l6=Label(t,text='Teacher Details',font=('arial',20))
            l6.place(x=200,y=10)
            data=cur.fetchall()
            for res in data:
                recd=recd+'\t'+str(res[0])
                recd=recd+'\t'+(res[1])
                recd=recd+'\t'+(res[2])
                recd=recd+'\t'+(res[3])
                recd=recd+'\t'+str(res[4])
                recd=recd+'\n'
            db.close()
        
        e=Text(t,width=150,height=100)
        showdata()
        e.insert(tkinter.END,recd)
        e.place(x=10,y=70)
        
    b5=Button(t,text='Show',bg='pink',font=('arial',20),command=showdatashow)
    b5.place(x=660,y=140)
       
    a3=Label(t,text='Student',font=('arial',30))
    a3.place(x=10,y=240)
    
    def showinsert():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page1db')
        #code for db connectivity button
        def savedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            xa=int(e1.get())
            xb=e2.get()
            xc=e3.get()
            xd=e4.get()
            xe=int(e5.get())
            sql="insert into student values(%d,'%s','%s','%s',%d)"%(xa,xb,xc,xd,xe)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('Hi','Saved')
            db.close()
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
        l6=Label(t,text='Student Details',font=('arial',15))
        l6.place(x=200,y=7)   
    
    
        l1=Label(t,text='rollno')
        l1.place(x=30,y=40)
    
        e1=Entry(t,width=18)
        e1.place(x=80,y=40)
    
        l2=Label(t,text='Name')
        l2.place(x=30,y=80)
    
        e2=Entry(t,width=18)
        e2.place(x=80,y=80)
    
        l3=Label(t,text='address')
        l3.place(x=30,y=120)
    
        e3=Entry(t,width=18)
        e3.place(x=80,y=120)
    
        l4=Label(t,text='subject')
        l4.place(x=30,y=160)
    
        e4=Entry(t,width=18)
        e4.place(x=80,y=160)
    
        l5=Label(t,text='marks')
        l5.place(x=30,y=200)
    
        e5=Entry(t,width=18)
        e5.place(x=80,y=200)
    
        b1=Button(t,text='Save',bg='blue',command=savedata)
        b1.place(x=30,y=240)
    
        b2=Button(t,text='Close',bg='blue')
        b2.place(x=80,y=240)
        
    b1=Button(t,text='Insert',bg='pink',font=('arial',20),command=showinsert)
    b1.place(x=200,y=230)
    def showfind():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page2db')
        lt=[]
    
        #combobox function
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            sql="Select rollno from student"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()
    
        #find data using billno as primary key
        def finddata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            xa=int(e1.get())
            #delete previous data find before
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
            
            sql="Select name,address,subject,marks from student where rollno=%d"%(xa)
            cur.execute(sql)
            #fetchone to get data using index positions
            data=cur.fetchone()
            e2.insert(0,data[0])
            e3.insert(0,data[1])
            e4.insert(0,data[2])
            e5.insert(0,data[3])
            db.close()
            
        l6=Label(t,text='Student Details',font=('arial',15))
        l6.place(x=200,y=7)
        l1=Label(t,text='rollno')
        l1.place(x=30,y=40)
    
        b1=Button(t,text='Find',bg='blue',command=finddata)
        b1.place(x=30,y=80)
    
        e1=ttk.Combobox(t)
        #call function filldata below
        filldata()
        e1['values']=lt
        e1.place(x=80,y=40)
    
        l2=Label(t,text='Name')
        l2.place(x=30,y=120)
    
        e2=Entry(t,width=18)
        e2.place(x=80,y=120)
    
        l3=Label(t,text='address')
        l3.place(x=30,y=160)
    
        e3=Entry(t,width=18)
        e3.place(x=80,y=160)
    
        l4=Label(t,text='subject')
        l4.place(x=30,y=200)
    
        e4=Entry(t,width=18)
        e4.place(x=80,y=200)
    
        l5=Label(t,text='marks')
        l5.place(x=30,y=240)
    
        e5=Entry(t,width=18)
        e5.place(x=80,y=240)
        
    b2=Button(t,text='Find',bg='pink',font=('arial',20),command=showfind)
    b2.place(x=320,y=230)
    def showdelete():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page3db')
        def deletedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            xa=int(a1.get())
            sql="delete from student where rollno=%d"%(xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi','deleted')
            db.close()
            a1.delete(0,100)
        l6=Label(t,text='Student Details',font=('arial',15))
        l6.place(x=200,y=7)    
        a=Label(t,text='rollno')
        a.place(x=60,y=30)
        a1=Entry(t,width=20)
        a1.place(x=150,y=30)
        b=Button(t,text='Delete',bg='blue',command=deletedata)
        b.place(x=100,y=90)
        t.mainloop()
    b3=Button(t,text='Delete',bg='pink',font=('arial',20),command=showdelete)
    b3.place(x=420,y=230)
    def showupdate():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page4db')
        lt=[]
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            sql="select rollno from student"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()
    
    
        def updatedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            xa=int(a1.get())
            xb=b1.get()
            xc=d1.get()
            xd=f1.get()
            xe=int(h1.get())
            sql="update student set name='%s',address='%s',subject='%s',marks=%d where rollno=%d"%(xb,xc,xd,xe,xa)
             
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi','update done')
            a1.delete(0,100)
             
            b1.delete(0,data[0])
            d1.delete(0,data[1])
            f1.delete(0,data[2])
            h1.delete(0,data[3])
            
        l6=Label(t,text='Student Details',font=('arial',15))
        l6.place(x=200,y=7)          
        a=Label(t,text='rollno')
        a.place(x=30,y=40)
        a1=ttk.Combobox(t)
        filldata()
        a1['values']=lt
        a1.place(x=100,y=40)
        
        b=Label(t,text='Name')
        b.place(x=30,y=100)
        b1=Entry(t,width=40)
        b1.place(x=100,y=100)
        d=Label(t,text='address')
        d.place(x=30,y=130)
        d1=Entry(t,width=40)
        d1.place(x=100,y=130)
        f=Label(t,text='subject')
        f.place(x=30,y=160)
        f1=Entry(t,width=40)
        f1.place(x=100,y=160)
        h=Label(t,text='marks')
        h.place(x=30,y=190)
        h1=Entry(t,width=40)
        h1.place(x=100,y=190)
        p=Button(t,text='update',bg='blue',command=updatedata)
        p.place(x=150,y=250)
    b4=Button(t,text='Update',bg='pink',font=('arial',20),command=showupdate)
    b4.place(x=540,y=230)
    
    def showdatashow():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page5db')
    
        def showdata():
            global recd
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            sql="select*from student"
            cur.execute(sql)
            l6=Label(t,text='Student Details',font=('arial',20))
            l6.place(x=200,y=10)
            data=cur.fetchall()
            for res in data:
                recd=recd+'\t'+str(res[0])
                recd=recd+'\t'+(res[1])
                recd=recd+'\t'+(res[2])
                recd=recd+'\t'+(res[3])
                recd=recd+'\t'+str(res[4])
                recd=recd+'\n'
            db.close()
        e=Text(t,width=150,height=50)
        showdata()
        e.insert(tkinter.END,recd)
        e.place(x=10,y=70)
    b4=Button(t,text='Show',bg='pink',font=('arial',20),command=showdatashow)
    b4.place(x=660,y=230)
    
    a3=Label(t,text='Exams',font=('arial',30))
    a3.place(x=10,y=330)
    def showinsert():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page1db')
        #code for db connectivity button
        def savedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            xa=int(e1.get())
            xb=e2.get()
            xc=e3.get()
            
            xd=int(e4.get())
            sql="insert into exam values(%d,'%s','%s',%d)"%(xa,xb,xc,xd)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('Hi','Saved')
            db.close()
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            
        l6=Label(t,text='Exam Details',font=('arial',15))
        l6.place(x=200,y=7)   
    
    
        l1=Label(t,text='rollno')
        l1.place(x=30,y=40)
    
        e1=Entry(t,width=18)
        e1.place(x=80,y=40)
    
        l2=Label(t,text='course')
        l2.place(x=30,y=80)
    
        e2=Entry(t,width=18)
        e2.place(x=80,y=80)
    
        l3=Label(t,text='duration')
        l3.place(x=30,y=120)
    
        e3=Entry(t,width=18)
        e3.place(x=80,y=120)
    
        l4=Label(t,text='fees')
        l4.place(x=30,y=160)
    
        e4=Entry(t,width=18)
        e4.place(x=80,y=160)
    
    
        b1=Button(t,text='Save',bg='blue',command=savedata)
        b1.place(x=30,y=240)
    
        b2=Button(t,text='Close')
        b2.place(x=80,y=240)
    b1=Button(t,text='Insert',bg='pink',font=('arial',20),command=showinsert)
    b1.place(x=200,y=320)
    def showfind():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page2db')
        lt=[]
    
        #combobox function
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            sql="Select rollno from exam"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()
    
        #find data using billno as primary key
        def finddata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            xa=int(e1.get())
            #delete previous data find before
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            
            
            sql="Select course,duration,fees from student where rollno=%d"%(xa)
            cur.execute(sql)
            #fetchone to get data using index positions
            data=cur.fetchone()
            e2.insert(0,data[0])
            e3.insert(0,data[1])
            e4.insert(0,data[2])
            
            db.close()
            
        l6=Label(t,text='Exam Details',font=('arial',15))
        l6.place(x=200,y=7)
        l1=Label(t,text='rollno')
        l1.place(x=30,y=40)
    
        b1=Button(t,text='Find',bg='blue',command=finddata)
        b1.place(x=30,y=80)
    
        e1=ttk.Combobox(t)
        #call function filldata below
        filldata()
        e1['values']=lt
        e1.place(x=80,y=40)
    
        l2=Label(t,text='course')
        l2.place(x=30,y=120)
    
        e2=Entry(t,width=18)
        e2.place(x=80,y=120)
    
        l3=Label(t,text='duration')
        l3.place(x=30,y=160)
    
        e3=Entry(t,width=18)
        e3.place(x=80,y=160)
    
        l4=Label(t,text='fees')
        l4.place(x=30,y=200)
    
        e4=Entry(t,width=18)
        e4.place(x=80,y=200)
    b2=Button(t,text='Find',bg='pink',font=('arial',20),command=showfind)
    b2.place(x=320,y=320)
    def showdelete():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page3db')
        def deletedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            xa=int(a1.get())
            sql="delete from exam where rollno=%d"%(xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi','deleted')
            db.close()
            a1.delete(0,100)
        l6=Label(t,text='Student Details',font=('arial',15))
        l6.place(x=200,y=7)    
        a=Label(t,text='rollno')
        a.place(x=60,y=30)
        a1=Entry(t,width=20)
        a1.place(x=150,y=30)
        b=Button(t,text='Delete',bg='blue',command=deletedata)
        b.place(x=100,y=90)
    b3=Button(t,text='Delete',bg='pink',font=('arial',20),command=showdelete)
    b3.place(x=420,y=320)
    def showupdate():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page4db')
        lt=[]
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            sql="select rollno from exam"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()
    
    
        def updatedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            xa=int(a1.get())
            xb=b1.get()
            xc=d1.get()
            xd=int(f1.get())
            
            sql="update exam set course='%s',duration='%s',fees=%d where rollno=%d"%(xb,xc,xd,xa)
             
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi','update done')
            a1.delete(0,100)
             
            b1.delete(0,data[0])
            d1.delete(0,data[1])
            f1.delete(0,data[2])
            
            
        l6=Label(t,text='Exam Details',font=('arial',15))
        l6.place(x=200,y=7)          
        a=Label(t,text='rollno')
        a.place(x=30,y=40)
        a1=ttk.Combobox(t)
        filldata()
        a1['values']=lt
        a1.place(x=100,y=40)
        
        b=Label(t,text='course')
        b.place(x=30,y=100)
        b1=Entry(t,width=40)
        b1.place(x=100,y=100)
        d=Label(t,text='duration')
        d.place(x=30,y=130)
        d1=Entry(t,width=40)
        d1.place(x=100,y=130)
        f=Label(t,text='fees')
        f.place(x=30,y=160)
        f1=Entry(t,width=40)
        f1.place(x=100,y=160)
    
        p=Button(t,text='update',bg='blue',command=updatedata)
        p.place(x=150,y=250)
    b4=Button(t,text='Update',bg='pink',font=('arial',20),command=showupdate)
    b4.place(x=540,y=320)
    
    def showdatashow():
        t=tkinter.Tk()
        t.geometry('640x480')
        t.title('page5db')
    
        def showdata():
            global recd
            db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
            cur=db.cursor()
            sql="select*from exam"
            cur.execute(sql)
            l6=Label(t,text='exam Details',font=('arial',20))
            l6.place(x=200,y=10)
            data=cur.fetchall()
            for res in data:
                recd=recd+'\t'+str(res[0])
                recd=recd+'\t'+(res[1])
                recd=recd+'\t'+(res[2])
                
                recd=recd+'\t'+str(res[3])
                recd=recd+'\n'
            db.close()
        e=Text(t,width=150,height=50)
        showdata()
        e.insert(tkinter.END,recd)
        e.place(x=10,y=70)
    b5=Button(t,text='Show',bg='pink',font=('arial',20),command=showdatashow)
    b5.place(x=660,y=320)
    
    t.mainloop()
