import tkinter
from tkinter import*
from tkinter import ttk 
t=tkinter.Tk()
t.geometry('800x800')
t.title('my first screen')
d=Canvas(t,height=650,width=650,bg='white')
d.place(x=10,y=10)
d.create_rectangle(30,50,450,200)
d.create_rectangle(30,100,450,250)

t.mainloop()