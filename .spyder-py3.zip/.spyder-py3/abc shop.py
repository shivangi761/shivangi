import tkinter
from tkinter import *
from tkinter import ttk

# create
t= tkinter.Tk()
#size
t.geometry('800x800')
t.title('my first screen')
def pro():
    xa=int(a1.get())
    xb=int(sp.get())
    r=xa*xb
    x6.delete(0,100)
    x6.insert(0,str(r))
def pro1():
    xc=int(a2.get())
    xd=int(sp1.get())
    r1=xc*xd
    x7.delete(0,100)
    x7.insert(0,str(r1))
def pro2():
    xf=int(a3.get())
    xg=int(sp2.get())
    r2=xf*xg
    
    x8.delete(0,100)
    x8.insert(0,str(r2))
def pro3():
    xh=int(a4.get())
    xp=int(sp3.get())
    r3=xh*xp
    x9.delete(0,100)
    x9.insert(0,str(r3))
def pro4():
    xm=int(a5.get())
    xn=int(sp4.get())
    r4=xm*xn
    x10.delete(0,100)
    x10.insert(0,str(r4))
def total():
    x1=int(a1.get())
    x2=int(a2.get())
    x3=int(a3.get())
    x4=int(a4.get())
    x5=int(a5.get())
    r=x1+x2+x3+x4+x5
    x11.delete(0,100)
    x11.insert(0,str(r))
def gst():
    x1=int(a1.get())
    x2=int(a2.get())
    x3=int(a3.get())
    x4=int(a4.get())
    x5=int(a5.get())
    x1sum=x1+x2+x3+x4+x5
    x2sum=((x1+x2+x3+x4+x5)*18)/100
    gtq=x1sum+x2sum
    x12.delete(0,100)
    x12.insert(0,str(gtq))
def final():
    x1=int(a1.get())
    x2=int(a2.get())
    x3=int(a3.get())
    x4=int(a4.get())
    x5=int(a5.get())
    x1sum=x1+x2+x3+x4+x5
    x2sum=((x1+x2+x3+x4+x5)+18)/100
    gtq=x1sum+x2sum
    x13.delete(0,100)
    x13.insert(0,str(gtq))
def ct():
    t.destroy()
    
  
    
    
    
a=Label(t,text='ABC Shop',font=('arial',15))
a.place(x=400,y=20)
b=Label(t,text='Name',font=('arial',15))
b.place(x=50,y=60)
d=Entry(t,width=30,font=('arial',15))
d.place(x=300,y=60)
f=Label(t,text='Email',font=('arial',15))
f.place(x=50,y=100)
g=Entry(t,width=30,font=('arial',15))
g.place(x=300,y=100)
x=Label(t,text=' Total',font=('arial',15))
x.place(x=540,y=150)
x1=Button(t,text='total',command=pro,bg='green',font=('arial',10))
x1.place(x=540,y=180)
x2=Button(t,text='total',command=pro1,bg='green',font=('arial',10))
x2.place(x=540,y=210)
x3=Button(t,text='total',command=pro2,bg='green',font=('arial',10))
x3.place(x=540,y=240)
x4=Button(t,text='total',command=pro3,bg='green',font=('arial',10))
x4.place(x=540,y=270)
x5=Button(t,text='total',command=pro4,bg='green',font=('arial',10))
x5.place(x=540,y=300)
st=Label(t,text='Grand Total')
st.place(x=650,y=150)
x6=Entry(t,width='20')
x6.place(x=640,y=180)
x7=Entry(t,width='20')
x7.place(x=640,y=210)
x8=Entry(t,width='20')
x8.place(x=640,y=240)
x9=Entry(t,width='20')
x9.place(x=640,y=270)
x10=Entry(t,width='20')
x10.place(x=640,y=300)
sa=Button(t,text='Total',command=total,bg='green',font=('arial',10))
sa.place(x=550,y=360)
x11=Entry(t,width=20)
x11.place(x=640,y=360)
sb=Button(t,text='GST 18%',command=gst,bg='green',font=('arial',10))
sb.place(x=550,y=400)
x12=Entry(t,width='20')
x12.place(x=640,y=400)

sd=Button(t,text='Final',command=final,bg='green',font=('arial',10))
sd.place(x=550,y=440)
x13=Entry(t,width='20')
x13.place(x=640,y=440)



    

i=Label(t,text='Price')
i.place(x=200,y=150)
a1=Entry(t,width=10)
a1.insert(0,'200')
a1.place(x=200,y=180)
a2=Entry(t,width=10)
a2.insert(0,'250')
a2.place(x=200,y=210)
a3=Entry(t,width=10)
a3.insert(0,'250')
a3.place(x=200,y=240)
a4=Entry(t,width=10)
a4.insert(0,10000)
a4.place(x=200,y=270)
a5=Entry(t,width=10)
a5.insert(0,'50')
a5.place(x=200,y=300)
u=Label(t,text='Quantity')
u.place(x=400,y=150)
sp=Spinbox(t,from_=1,to=100)
sp.place(x=350,y=180)
sp1=Spinbox(t,from_=1,to=100)
sp1.place(x=350,y=210)
sp2=Spinbox(t,from_=1,to=100)
sp2.place(x=350,y=240)
sp3=Spinbox(t,from_=1,to=100)
sp3.place(x=350,y=270)
sp4=Spinbox(t,from_=1,to=100)
sp4.place(x=350,y=300)

h=Label(t,text='Product')
h.place(x=10,y=150)

k=Label(t,text='Cloth')
k.place(x=10,y=180)




n=Label(t,text='Book')
n.place(x=10,y=210)


p=Label(t,text='Car')
p.place(x=10,y=240)

r=Label(t,text='Furniture')
r.place(x=10,y=270)

s=Label(t,text='Toothpaste')
s.place(x=10,y=300)
pt=Button(t,text='Close',command=ct,bg='green',font=('arial',15))
pt.place(x=50,y=400)

t.mainloop()