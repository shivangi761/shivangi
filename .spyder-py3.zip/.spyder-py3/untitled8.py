import tkinter 
from tkinter import*
from tkinter import ttk
t=tkinter.Tk()
t.geometry('800x800')
t.title('my first screen')
a=Label(t,text='Name')
a.place(x=20,y=40)
b=Entry(t,width=40)
b.place(x=300,y=40)
c=Label(t,text='Sem 1')
c.place(x=20,y=100)
d=Entry(t,width=40)
d.place(x=300,y=100)
f=Label(t,text='Sem 2')
f.place(x=20,y=160)
j=Entry(t,width=40)
j.place(x=300,y=160)
k=Label(t,text='Sem 3')
k.place(x=20,y=220)
m=Entry(t,width=40)
m.place(x=300,y=220)
b1=Button(t,text='Score')
b1.place(x=20,y=280)
g=Entry(t,width=40)
g.place(x=300,y=280)
b2=Button(t,text='Division')
b2.place(x=20,y=340)


k=Entry(t,width=40)
k.place(x=300,y=340)


t.mainloop()