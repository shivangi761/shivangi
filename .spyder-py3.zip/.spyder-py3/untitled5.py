from tkinter import colorchooser
from tkinter import messagebox
import tkinter
from tkinter import*
from tkinter import ttk
t=tkinter.Tk()
t.geometry('800x800')
t.title('my first screen')
def ch():
    xp=colorchooser.askcolor()
    a.config(fg=xp[1])
def chone():
    xp=colorchooser.askcolor()
    t.config(bg=xp[1])
def chsize():
    xt=int(sp.get())
    a.config(font=('arial',xt))

  

a=Label(t,text='python',font=('arial',30))
a.place(x=200,y=20)
b=Button(t,text='Color',command=ch)
b.place(x=200,y=200)
b1=Button(t,text='ScreenColor',command=chone)
b1.place(x=300,y=200)
sp=Spinbox(t,from_=1,to=100,command=chsize)
sp.place(x=200,y=350)
t.mainloop()