from tkinter import messagebox
import tkinter
from tkinter import *
from tkinter import ttk

# create
t= tkinter.Tk()
#size
t.geometry('500x500')
t.title('my first screen')
def add():
    xa=int(d.get())
    xb=int(f.get())
    r=xa+xb
    messagebox.showinfo('sum',str(r))
def sub():
    xa=int(d.get())
    xb=int(f.get())
    r=xa-xb
    messagebox.showinfo('sub',str(r))
def mul():
    xa=int(d.get())
    xb=int(f.get())
    r=xa*xb
    messagebox.showinfo('mul',str(r))
def div():
    xa=int(d.get())
    xb=int(f.get())
    r=xa/xb
    messagebox.showinfo('div',str(r))
b=Label(t,text='No1.')
b.place(x=50,y=60)
d=Entry(t,width=30)
d.place(x=200,y=60)

e=Label(t,text='No2.')
e.place(x=50,y=100)
f=Entry(t,width=30)
f.place(x=200,y=100)
b1=Button(t,text='+',command=add)
b1.place(x=100,y=200)
b2=Button(t,text='-',command=sub)
b2.place(x=150,y=200)
b3=Button(t,text='*',command=mul)
b3.place(x=200,y=200)
b4=Button(t,text='/',command=div)
b4.place(x=250,y=200)
t.mainloop()