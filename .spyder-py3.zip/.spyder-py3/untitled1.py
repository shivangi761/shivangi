import tkinter
from tkinter import*
from tkinter import ttk
t=tkinter.Tk()
t.geometry('800x800')
t.title('my first screen')
def chone():
    t.config(bg='red')
def chtwo():
    t.config(bg='blue')
def chthree():
    t.config(bg='green')

a=Button(t,text='red',command=chone)

a.place(x=380,y=360)
b=Button(t,text='blue',command=chtwo)
b.place(x=280,y=400)
c=Button(t,text='green',command=chthree)
c.place(x=380,y=440)
t.mainloop()