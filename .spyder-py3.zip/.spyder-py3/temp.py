import tkinter
from tkinter import *
from tkinter import ttk
# create
t= tkinter.Tk()
#size
t.geometry('800x800')
t.title('my first screen')
d=Canvas(t,height=650,width=650,bg='pink')
d.place(x=10,y=10)
d.create_line(100,50,300,150)
d.create_line(100,50,300,50)
d.create_line(100,50,100,120)
d.create_rectangle(200,100,400,300,fill='red')
d.create_oval(200,400,300,400,fill='orange')
t.mainloop()