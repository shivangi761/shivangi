from tkinter import messagebox
import tkinter
from tkinter import*
from tkinter import ttk
t=tkinter.Tk()
t.geometry('800x800')
t.title('my first screen')
def change():
    xt=int(sp.get())
    pr['value']=xt
sp=Spinbox(t,from_=1,to=100,command=change)
sp.place(x=50,y=100)
pr=ttk.Progressbar(t)
pr['value']=0
pr.place(x=50,y=200)
t.mainloop()