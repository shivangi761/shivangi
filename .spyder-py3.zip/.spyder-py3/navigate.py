import tkinter
import pymysql
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
t=tkinter.Tk()
t.geometry('640x480')
t.title('page1db')
xa=[]
xb=[]
xc=[]
xd=[]
xe=[]
i=0
def filldata():
    db=pymysql.connect(host='localhost',user='root',password='root',database='testdb')
    cur=db.cursor()
    sql="select*from billing"
    cur.execute(sql)
    data=cur.fetchall()
    for res in data:
        xa.append(res[0])
        xb.append(res[1])
        xc.append(res[2])
        xd.append(res[3])
        xe.append(res[4])
    db.close()
    
def first():
    global i
    i=0
    e1.delete(0,100)
    e2.delete(0,100)
    e3.delete(0,100)
    e4.delete(0,100)
    e5.delete(0,100)
    e1.insert(0,str(xa[i]))
    e2.insert(0,xb[i])
    e3.insert(0,xc[i])
    e4.insert(0,xd[i])
    e5.insert(0,str(xe[i]))
    
def next():
    global i
    i=i+1
    e1.delete(0,100)
    e2.delete(0,100)
    e3.delete(0,100)
    e4.delete(0,100)
    e5.delete(0,100)
    e1.insert(0,str(xa[i]))
    e2.insert(0,xb[i])
    e3.insert(0,xc[i])
    e4.insert(0,xd[i])
    e5.insert(0,str(xe[i]))
    
def previous():
    global i
    i=i-1
    e1.delete(0,100)
    e2.delete(0,100)
    e3.delete(0,100)
    e4.delete(0,100)
    e5.delete(0,100)
    e1.insert(0,str(xa[i]))
    e2.insert(0,xb[i])
    e3.insert(0,xc[i])
    e4.insert(0,xd[i])
    e5.insert(0,str(xe[i]))
    
def last():
    global i
    i=len(xa)-1
    e1.delete(0,100)
    e2.delete(0,100)
    e3.delete(0,100)
    e4.delete(0,100)
    e5.delete(0,100)
    e1.insert(0,str(xa[i]))
    e2.insert(0,xb[i])
    e3.insert(0,xc[i])
    e4.insert(0,xd[i])
    e5.insert(0,str(xe[i]))
        

l1=Label(t,text='Billno')
l1.place(x=30,y=40)

e1=Entry(t,width=18)
e1.place(x=100,y=40)

l2=Label(t,text='Cname')
l2.place(x=30,y=80)

e2=Entry(t,width=18)
e2.place(x=100,y=80)

l3=Label(t,text='City')
l3.place(x=30,y=120)

e3=Entry(t,width=18)
e3.place(x=100,y=120)

l4=Label(t,text='Item')
l4.place(x=30,y=160)

e4=Entry(t,width=18)
e4.place(x=100,y=160)

l5=Label(t,text='Amount')
l5.place(x=30,y=200)

e5=Entry(t,width=18)
e5.place(x=100,y=200)

b1=Button(t,text='first',command=first)
b1.place(x=30,y=240)

b2=Button(t,text='next',command=next)
b2.place(x=80,y=240)
b3=Button(t,text='previous',command=previous)
b3.place(x=130,y=240)
b4=Button(t,text='last',command=last)
b4.place(x=200,y=240)
filldata()


t.mainloop()
  
 