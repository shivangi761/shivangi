import tkinter
import pymysql
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
recd=''
def showdeshboard():
    
    
    t = tkinter.Tk()
    t.geometry('1100x1100')
    t.title('my first screen')
    t.config(bg='pink')
    a1 = Label(t, text='Service Call Management',bg='pink', font=('arial', 30,'bold'))
    a1.place(x=300, y=7)
    a = Label(t, text='Service Center',bg='pink', font=('arial', 25,'bold'))
    a.place(x=10, y=90)
    
   


    def showinsert():
        t = tkinter.Tk()
        t.geometry('800x800')
        t.title('page1db')
        t.config(bg='lightblue')
        def dest():
            t.destroy()
        
        
            
            
        
        
        
        def savedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            xa=e1.get()
            sql="select * from service_center where id='%s'"%(xa)
            cur.execute(sql)
            data=cur.fetchall()
            
            if data: 
                messagebox.showerror("Error","Data already exist")
            elif len(e1.get())==0 or  len(e2.get())==0 or len(e3.get())==0 or len(e4.get())==0 or len(e5.get())==0 or len(e6.get())==0:
                
                messagebox.showerror('Invalid','Invalid details')
            else:
                db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
                cur=db.cursor()
                xa=e1.get()
                xb=e2.get()
                xc=e3.get()
                xd=e4.get()
                xe=e5.get()
                xf=e6.get()
                
                sql="insert into service_center values('%s','%s','%s','%s','%s','%s')"%(xa,xb,xc,xd,xe,xf)
                cur.execute(sql)
                db.commit()
                messagebox.showinfo('hi','saved')
                db.close()
                e1.delete(0,100)
                e2.delete(0,100)
                e3.delete(0,100)
                e4.delete(0,100)
                e5.delete(0,100)
                e6.delete(0,100)
                db.close()
        
            
        # code for db connectivity button

       

        l6 = Label(t, text='service center details',bg='lightblue', font=('arial', 30,'bold'))
        l6.place(x=250, y=20)
        l1 = Label(t, text='Id',bg='lightblue',font=('arial',20,'bold'))
        l1.place(x=200, y=100)

        e1 = Entry(t, width=30,font=('arial',15,'bold'))
        e1.place(x=400, y=100)

        l2 = Label(t, text='C Name',bg='lightblue',font=('arial',20,'bold'))
        l2.place(x=200, y=150)

        e2 = Entry(t, width=30,font=('arial',15))
        e2.place(x=400, y=150)

        l3 = Label(t, text='Address',bg='lightblue',font=('arial',20,'bold'))
        l3.place(x=200, y=200)

        e3 = Entry(t, width=30,font=('arial',15))
        e3.place(x=400, y=200)

        l4 = Label(t, text='Email',bg='lightblue',font=('arial',20,'bold'))
        l4.place(x=200, y=250)

        e4 = Entry(t, width=30,font=('arial',15))
        e4.place(x=400, y=250)

        l5 = Label(t, text='Phone',bg='lightblue',font=('arial',20,'bold'))
        l5.place(x=200, y=300)

        e5 = Entry(t, width=30,font=('arial',15))
        e5.place(x=400, y=300)

        l6 = Label(t, text='Reg No',bg='lightblue',font=('arial',20,'bold'))
        l6.place(x=200, y=350)

        e6 = Entry(t, width=30,font=('arial',15))
        e6.place(x=400, y=350)

        b1 = Button(t, text='Save',font=('arial',15,'bold'), bg='blue', command=savedata)
        b1.place(x=250, y=450)

        b2 = Button(t, text='Close',font=('arial',15,'bold'), bg='blue',command=dest)
        b2.place(x=350, y=450)
        


    b1 = Button(t, text='Insert', bg='blue', font=('arial', 20), command=showinsert)
    b1.place(x=310, y=80)

    def showfind():
        t = tkinter.Tk()
        t.geometry('840x480')
        t.title('page2db')
        t.config(bg='lightblue')
        lt = []
        def dest():
            t.destroy()

        # combobox function
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "Select id from service_center"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        # find data using billno as primary key
        def finddata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = int(e1.get())
            # delete previous data find before
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)

            sql = "Select cname,address,email,phone,regno from service_center where id=%d" % (xa)
            cur.execute(sql)
            # fetchone to get data using index positions
            data = cur.fetchone()
            e2.insert(0, data[0])
            e3.insert(0, data[1])
            e4.insert(0, data[2])
            e5.insert(0, data[3])
            e6.insert(0, data[4])
            db.close()
        l6 = Label(t, text='service center details',bg='lightblue', font=('arial',30,'bold'))
        l6.place(x=200, y=7)

        l1 = Label(t, text='Id',bg='lightblue',font=('arial',20,'bold'))
        l1.place(x=100, y=70)
        
        

        b1 = Button(t, text='Find',font=('arial',15,'bold'), bg='blue', command=finddata)
        b1.place(x=200, y=110)

        e1 = ttk.Combobox(t,font=('arial',13))
        # call function filldata below
        filldata()
        e1['values'] = lt
        e1.place(x=300, y=70)

        l2 = Label(t, text='C Name',bg='lightblue',font=('arial',20,'bold'))
        l2.place(x=100, y=150)

        e2 = Entry(t, width=30,font=('arial',15))
        e2.place(x=300, y=150)

        l3 = Label(t, text='Address',bg='lightblue',font=('arial',20,'bold'))
        l3.place(x=100, y=200)

        e3 = Entry(t, width=30,font=('arial',15))
        e3.place(x=300, y=210)

        l4 = Label(t, text='Email',font=('arial',20,'bold'),bg='lightblue')
        l4.place(x=100, y=250)

        e4 = Entry(t, width=30,font=('arial',15))
        e4.place(x=300, y=260)

        l5 = Label(t, text='Phone',font=('arial',20,'bold'))
        l5.place(x=100, y=300)

        e5 = Entry(t, width=30,font=('arial',15))
        e5.place(x=300, y=310)

        l6 = Label(t, text='Reg No',font=('arial',20,'bold'))
        l6.place(x=100, y=350)

        e6 = Entry(t, width=30,font=('arial',15))
        e6.place(x=300, y=360)
        b3=Button(t,text='close',bg='blue',command=dest,font=('arial',15))
        b3.place(x=150,y=420)


    b2 = Button(t, text='Find', bg='blue', font=('arial', 20), command=showfind)
    b2.place(x=420, y=80)


    def showdelete():
        t = tkinter.Tk()
        t.geometry('640x480')
        t.title('page3db')
        t.config(bg='lightblue')
        cdi=[]
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select id from service_center"
            cur.execute(sql)           
            data=cur.fetchall()
            for res in data:
                cdi.append(res[0])
            
       

        def deletedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = int(a1.get())
            sql = "delete from service_center where id=%d" % (xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'deleted')
            db.close()
            a1.delete(0, 100)
        l6 = Label(t, text='service center details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=10)
        a = Label(t, text='Id',font=('arial',15,'bold'),bg='lightblue')
        a.place(x=150, y=100)
        
        #a1 = Entry(t, width=20,font=('arial',10))
       # a1.place(x=300, y=100)
        a1 = ttk.Combobox(t)
        filldata()
        a1['values'] = cdi
        a1.place(x=300, y=100)
       
        b = Button(t, text='Delete', bg='blue',font=('arial',15), command=deletedata)
        b.place(x=200, y=200)


    b3 = Button(t, text='Delete', bg='blue', font=('arial', 20), command=showdelete)
    b3.place(x=510, y=80)
    
   

    def showupdate():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page4db')
        t.config(bg='lightblue')
        lt = []
        def dest():
            t.destroy()

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select id from service_center"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        def updatedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = int(a1.get())
            xb = b1.get()
            xc = d1.get()
            xd = f1.get()
            xe = h1.get()
            xf = s1.get()
            sql = "update service_center set cname='%s',address='%s',email='%s',phone='%s',reg='%s' where id=%d" % (xb, xc, xd, xe, xf, xa)

            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'update done')
            a1.delete(0, 100)

            b1.delete(0, data[0])
            d1.delete(0, data[1])
            f1.delete(0, data[2])
            h1.delete(0, data[3])
            s1.delete(0, data[4])

        l6 = Label(t, text='service center details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=7)
        a = Label(t, text='Id',font=('arial',20,'bold'),bg='lightblue')
        a.place(x=100, y=60)
        a1 = ttk.Combobox(t)
        filldata()
        a1['values'] = lt
        a1.place(x=300, y=60)

        b = Label(t, text='C Name',font=('arial',20,'bold'),bg='lightblue')
        b.place(x=100, y=100)
        b1 = Entry(t, width=30,font=('arial',15))
        b1.place(x=300, y=100)
        d = Label(t, text='Address',font=('arial',20,'bold'),bg='lightblue')
        d.place(x=100, y=140)
        d1 = Entry(t, width=30,font=('arial',15))
        d1.place(x=300, y=140)
        f = Label(t, text='Email',font=('arial',20,'bold'),bg='lightblue')
        f.place(x=100, y=180)
        f1 = Entry(t, width=30,font=('arial',15))
        f1.place(x=300, y=180)
        h = Label(t, text='Phone',font=('arial',20,'bold'),bg='lightblue')
        h.place(x=100, y=220)
        h1 = Entry(t, width=30,font=('arial',15))
        h1.place(x=300, y=220)
        s = Label(t, text='Reg No',font=('arial',20,'bold'),bg='lightblue')
        s.place(x=100, y=260)
        s1 = Entry(t, width=30,font=('arial',15))
        s1.place(x=300, y=260)
        p = Button(t, text='update',font=('arial',15), bg='blue', command=updatedata)
        p.place(x=400, y=310)
        p = Button(t, text='close',font=('arial',15), bg='blue', command=dest)
        p.place(x=500, y=310)


    b4 = Button(t, text='Update', bg='blue', font=('arial', 20), command=showupdate)
    b4.place(x=630, y=80)
    
    def showdatashow():
        t = tkinter.Tk()
        t.geometry('800x800')
        t.title('page5db')
        t.config(bg='lightblue')

        def showdata():
            global recd
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select * from service_center"
            cur.execute(sql)
            l6 = Label(t, text='service center details', font=('arial', 20,'bold'),bg='lightblue')
            l6.place(x=200, y=10)
            data = cur.fetchall()
            for res in data:
                
                recd = recd+'\t'+str(res[0])
                recd = recd+'\t'+(res[1])
                recd = recd+'\t'+(res[2])
                recd = recd+'\t'+(res[3])
                recd = recd+'\t'+str(res[4])
                recd = recd+'\t'+str(res[5])
                recd = recd+'\n'
            db.close()

        e = Text(t, width=150, height=50,bg='lightgreen',font=('arial',15))
        showdata()
        e.insert(tkinter.END, recd)
        e.place(x=10, y=70)


    b5 = Button(t, text='Show', bg='blue', font=('arial', 20,), command=showdatashow)
    b5.place(x=750, y=80)


    


    def shownavigate():
        t = tkinter.Tk()
        t.geometry('640x480')
        t.title('page6db')
        t.config(bg='lightblue')
        def dest():
            t.destroy()
        xa = []
        xb = []
        xc = []
        xd = []
        xe = []
        xf = []
        i = 0

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select*from service_center"
            cur.execute(sql)
            l6 = Label(t, text='service center details', font=('arial', 20,'bold'),bg='lightblue')
            l6.place(x=150, y=3)
            data = cur.fetchall()
            for res in data:
                xa.append(res[0])
                xb.append(res[1])
                xc.append(res[2])
                xd.append(res[3])
                xe.append(res[4])
                xf.append(res[5])
            db.close()

        def first():
            global i
            i = 0
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e1.insert(0, str(xa[i]))
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xf[i])

        def next():
            global i
            i = i+1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e1.insert(0, str(xa[i]))
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xe[i])

        def previous():
            global i
            i = i-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e1.insert(0, str(xa[i]))
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xf[i])

        def last():
            global i
            i = len(xa)-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e1.insert(0, str(xa[i]))
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xf[i])

        l1 = Label(t, text='Id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=60)

        e1 = Entry(t, width=40,font=('arial',10))
        e1.place(x=300, y=60)
        l2 = Label(t, text='C Name',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=100)

        e2 = Entry(t, width=40,font=('arial',10))
        e2.place(x=300, y=100)

        l3 = Label(t, text='Address',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=140)
        e3 = Entry(t, width=40,font=('arial',10))
        e3.place(x=300, y=140)

        l4 = Label(t, text='Email',font=('arial',15,'bold'),bg='lightblue')
        l4.place(x=100, y=180)

        e4 = Entry(t, width=40,font=('arial',10))
        e4.place(x=300, y=180)

        l5 = Label(t, text='Phone',font=('arial',15,'bold'),bg='lightblue')
        l5.place(x=100, y=220)

        e5 = Entry(t, width=40,font=('arial',10))
        e5.place(x=300, y=220)

        l6 = Label(t, text='Reg No',font=('arial',15,'bold'),bg='lightblue')
        l6.place(x=100, y=260)

        e6 = Entry(t, width=40,font=('arial',10))
        e6.place(x=300, y=260)

        b1 = Button(t, text='First',font=('arial',15), bg='blue', command=first)
        b1.place(x=100, y=350)

        b2 = Button(t, text='Next',font=('arial',15), bg='blue', command=next)
        b2.place(x=200, y=350)
        b3 = Button(t, text='Previous',font=('arial',15), bg='blue', command=previous)
        b3.place(x=300, y=350)
        b4 = Button(t, text='Last',font=('arial',15), bg='blue', command=last)
        b4.place(x=400, y=350)
        b4 = Button(t, text='Close',font=('arial',15), bg='blue', command=dest)
        b4.place(x=500, y=350)
        filldata()


    b6 = Button(t, text='Navigate', bg='blue', font=('arial', 20), command=shownavigate)
    b6.place(x=860, y=80)


    a = Label(t, text='Product Category', font=('arial', 25,'bold'),bg='pink')
    a.place(x=10, y=160)


    def showinsert():
        t = tkinter.Tk()
        t.geometry('640x480')
        t.title('page1db')
        t.config(bg='lightblue')
        def dest():
            t.destroy()
            
        def savedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            xa=e1.get()
            xb=e2.get()
            xc=e3.get()
            sql="select*from product_category where prodcatid='%s'"%(xa)
            cur.execute(sql)
            data=cur.fetchall()
            if data:
                messagebox.showerror("error","data already exist")
            elif  len(e1.get())==0 or  len(e2.get())==0 or len(e3.get())==0:
                messagebox.showerror('Invalid','invalid details')
            
           
                
            else:
                    db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
                    cur=db.cursor()
                    xa=e1.get()
                    xb=e2.get()
                    xc=e3.get()
                    
            
                    
                    sql="insert into product_category values('%s','%s','%s')"%(xa,xb,xc)
                    cur.execute(sql)
                    db.commit()
                    messagebox.showinfo('hi','saved')
                    db.close()
                    e1.delete(0,100)
                    e2.delete(0,100)
                    e3.delete(0,100)
            
        
            db.close()
        
       
            
           
        # code for db connectivity button

       

        l6 = Label(t, text='product category details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=7)
        l1 = Label(t, text='Prodcat Id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=60)

        e1 = Entry(t, width=30,font=('arial',10)
                   )
        e1.place(x=300, y=60)
        
        l2 = Label(t, text='Cat Name',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=100)

        e2 = Entry(t, width=30,font=('arial',10))
        e2.place(x=300, y=100)

        l3 = Label(t, text='Description',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=140)

        e3 = Entry(t, width=30,font=('arial',10))
        e3.place(x=300, y=140)

        b1 = Button(t, text='Save',font=('arial',15,'bold'), bg='blue', command=savedata)
        b1.place(x=100, y=200)

        b2 = Button(t, text='Close',font=('arial',15,'bold'), bg='blue',command=dest)
        b2.place(x=200, y=200)
        
        #b3 = Button(t, text='check',font=('arial',15,'bold'), bg='blue',command=checkdata)
        #b3.place(x=300, y=200)
        
       


    b1 = Button(t, text='Insert', bg='blue', font=('arial', 20), command=showinsert)
    b1.place(x=310, y=150)


    def showfind():
        t = tkinter.Tk()
        t.geometry('640x480')
        t.title('page2db')
        t.config(bg='lightblue')
        def dest():
            t.destroy()
        lt = []

        # combobox function
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "Select prodcatid from product_category"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        
        def finddata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = e1.get()
            # delete previous data find before
            e2.delete(0, 100)
            e3.delete(0, 100)

            sql = "Select catname,description from product_category where prodcatid='%s'" % (xa)
            cur.execute(sql)
            # fetchone to get data using index positions
            data = cur.fetchone()
            e2.insert(0, data[0])
            e3.insert(0, data[1])

            db.close()
        l6 = Label(t, text='product category details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=7)

        l1 = Label(t, text='Prodcat Id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=60)

        b1 = Button(t, text='Find',font=('arial',15,), bg='blue', command=finddata)
        b1.place(x=200, y=90)

        e1 = ttk.Combobox(t,font=('arial',10),width=28)
        # call function filldata below
        filldata()
        e1['values'] = lt
        e1.place(x=300, y=60)

        l2 = Label(t, text='Cat Name',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=140)

        e2 = Entry(t, width=30,font=('arial',10))
        e2.place(x=300, y=140)

        l3 = Label(t, text='Description',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=190)

        e3 = Entry(t, width=30,font=('arial',10))
        e3.place(x=300, y=190)
        
        b6 = Button(t, text='close',font=('arial',15,), bg='blue', command=dest)
        b6.place(x=200, y=230)


    b2 = Button(t, text='Find', bg='blue', font=('arial', 20), command=showfind)
    b2.place(x=420, y=150)


    def showdelete():
        t = tkinter.Tk()
        t.geometry('640x480')
        t.title('page3db')
        t.config(bg='lightblue')
        cdi=[]
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select prodcatid from product_category"
        
            
            cur.execute(sql)           
            data=cur.fetchall()
            for res in data:
                cdi.append(res[0])
       

        def deletedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()
            sql = "delete from product_category where prodcatid='%s'" % (xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'deleted')
            db.close()
            a1.delete(0, 100)
        l6 = Label(t, text='product category details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=15)
        a = Label(t, text='Prodcat Id',font=('arial',15,'bold'),bg='lightblue')
        a.place(x=150, y=100)
        #a1 = Entry(t, width=20,font=('arial',10))
        #a1.place(x=300, y=100)
        a1 = ttk.Combobox(t)
        filldata()
        a1['values'] = cdi
        a1.place(x=300, y=100)
        b = Button(t, text='Delete',font=('arial',15), bg='blue', command=deletedata)
        b.place(x=170, y=170)


    b3 = Button(t, text='Delete', bg='blue', font=('arial', 20), command=showdelete)
    b3.place(x=510, y=150)
    
   


    def showupdate():
        t = tkinter.Tk()
        t.geometry('640x480')
        t.title('page4db')
        t.config(bg='lightblue')
        def dest():
            t.destroy()
        lt = []

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select prodcatid from product_category"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        def updatedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()
            xb = b1.get()
            xc = d1.get()

            sql = "update product_category set catname='%s',description='%s' where prodcatid='%s'" % (xb, xc, xa)

            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'update done')
            a1.delete(0, 100)

            b1.delete(0, data[0])
            d1.delete(0, data[1])

        l6 = Label(t, text='product category details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=7)
        a = Label(t, text='Prodcat Id',font=('arial',15,'bold'),bg='lightblue')
        a.place(x=100, y=60)
        a1 = ttk.Combobox(t,font('arial',13),width=34)
        filldata()
        a1['values'] = lt
        a1.place(x=300, y=60)

        b = Label(t, text='Cat Name',font=('arial',15,'bold'),bg='lightblue')
        b.place(x=100, y=100)
        b1 = Entry(t, width=30,font=('arial',10))
        b1.place(x=300, y=100)
        d = Label(t, text='Description',font=('arial',15,'bold'),bg='lightblue')
        d.place(x=100, y=140)
        d1 = Entry(t, width=30,font=('arial',10))
        d1.place(x=300, y=140)

        p = Button(t, text='update',font=('arial',15), bg='blue', command=updatedata)
        p.place(x=150, y=200)
        
        p1 = Button(t, text='close',font=('arial',15), bg='blue', command=dest)
        p1.place(x=250, y=200)


    b4 = Button(t, text='Update', bg='blue', font=('arial', 20), command=showupdate)
    b4.place(x=630, y=150)


    def showdatashow():
        t = tkinter.Tk()
        t.geometry('800x800')
        t.title('page5db')
        t.config(bg='lightblue')

        def showdata():
            global recd
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select * from product_category"
            cur.execute(sql)
            l6 = Label(t, text='product category details', font=('arial', 20,'bold'),bg='lightblue')
            l6.place(x=200, y=10)
            data = cur.fetchall()
            for res in data:
                recd = recd+'\t'+(res[0])
                recd = recd+'\t'+(res[1])
                recd = recd+'\t'+(res[2])

                recd = recd+'\n'
            db.close()

        e = Text(t, width=150, height=50,font=('arial',15))
        showdata()
        e.insert(tkinter.END, recd)
        e.place(x=10, y=70)


    b5 = Button(t, text='Show', bg='blue', font=('arial', 20), command=showdatashow)
    b5.place(x=750, y=150)


    def shownavigate():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page6db')
        t.config(bg='lightblue')
        def dest():
            t.destroy()
        xa = []
        xb = []
        xc = []
        i = 0

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select*from product_category"
            cur.execute(sql)
            l6 = Label(t, text='product category Details', font=('arial', 20,'bold'),bg='lightblue')
            l6.place(x=150, y=20)
            data = cur.fetchall()
            for res in data:
                xa.append(res[0])
                xb.append(res[1])
                xc.append(res[2])

            db.close()

        def first():
            global i
            i = 0
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)

            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])

        def next():
            global i
            i = i+1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)

            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])

        def previous():
            global i
            i = i-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)

            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])

        def last():
            global i
            i = len(xa)-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)

            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])

        l1 = Label(t, text='Prodcat Id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=100)

        e1 = Entry(t, width=30,font=('arial',10))
        e1.place(x=300, y=100)

        l2 = Label(t, text='Cat Name',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=150)

        e2 = Entry(t, width=30,font=('arial',10))
        e2.place(x=300, y=150)

        l3 = Label(t, text='Description',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=200)

        e3 = Entry(t, width=30,font=('arial',10))
        e3.place(x=300, y=200)

        b1 = Button(t, text='First',font=('arial',15), bg='blue', command=first)
        b1.place(x=100, y=300)

        b2 = Button(t, text='Next',font=('arial',15), bg='blue', command=next)
        b2.place(x=200, y=300)
        b3 = Button(t, text='Previous',font=('arial',15), bg='blue', command=previous)
        b3.place(x=300, y=300)
        b4 = Button(t, text='Last',font=('arial',15), bg='blue', command=last)
        b4.place(x=450, y=300)
        b5 = Button(t, text='Close',font=('arial',15), bg='blue', command=dest)
        b5.place(x=550, y=300)
        filldata()


    b6 = Button(t, text='Navigate', bg='blue', font=('arial', 20), command=shownavigate)
    b6.place(x=860, y=150)


    a = Label(t, text='Services Type', font=('arial', 25,'bold'),bg='pink')
    a.place(x=10, y=240)
    
    def showinsert():
        
        t=tkinter.Tk()
        t.geometry('740x440')
        t.configure(bg='lightblue')
        t.title('page1')
        def dest():
            t.destroy()
        
        cdi=[]
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select * from product_category"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                cdi.append(res[0])
            #messagebox.showinfo('hi','inserted')
            
        def savedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            xa=e1.get()
            xb=e2.get()
            xc=e3.get()
            xd=int(e4.get())
            xe=e5.get()
            sql="select * from servicetypes where prodcatid='%s'"%(xb)
            cur.execute(sql)
            data=cur.fetchone()
            if data:
                messagebox.showerror('Invalid','Data Already Exist   ')
            
            else:
                if xa=='' or xb== ''or xc=='' or xe=='':
                    messagebox.showerror('Invalid','Invalid detail')
                
                else:
                    if xd<100:
                        messagebox.showerror("Invalid Entry","Charge can't less 100")
                    else:    
                        sql="insert into servicetype values('%s','%s','%s','%d','%s')" %(xa,xb,xc,xd,xe)
                        cur.execute(sql)
                        db.commit()
                        db.close()
                        messagebox.showinfo('save','Data successfully save')
                        e1.delete(0,100)
                        e2.delete(0,100)
                        e3.delete(0,100)
                        e4.delete(0,100)
                        e5.delete(0,100)
        l6 = Label(t, text='service type details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=7)
        l1 = Label(t, text='Service Id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=60)

        e1 = Entry(t, width=30,font=('arial',15))
        e1.place(x=300, y=60)
        

        l2 = Label(t, text='Prodcat Id',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=100)
       

        #e2 = Entry(t, width=30,bg='lightgreen',font=('arial',15))
        #e2.place(x=300, y=100)
        e2=ttk.Combobox(t,font=('arial',13),width=34)
        filldata()
        e2['values']=cdi
        e2.place(x=300,y=100)

        l3 = Label(t, text='Service Name',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=140)

        e3 = Entry(t, width=30,font=('arial',15))
        e3.place(x=300, y=140)

        l4 = Label(t, text='Charges',font=('arial',15,'bold'),bg='lightblue')
        l4.place(x=100, y=180)

        e4 = Entry(t, width=30,font=('arial',15))
        e4.place(x=300, y=180)

        l5 = Label(t, text='Time to solve',font=('arial',15,'bold'),bg='lightblue')
        l5.place(x=100, y=220)

        e5 = Entry(t, width=30,font=('arial',15))
        e5.place(x=300, y=220)

        b1 = Button(t, text='Save',font=('arial',15,'bold'), bg='blue', command=savedata)
        b1.place(x=100, y=300)

        b2 = Button(t, text='Close',font=('arial',15,'bold'), bg='blue',command=dest)
        b2.place(x=300, y=300)
        
       # b4 = Button(t, text='check',font=('arial',15,'bold'), bg='blue',command=checkdata)
       # b4.place(x=400, y=300)


    b1 = Button(t, text='Insert', bg='blue', font=('arial', 20), command=showinsert)
    b1.place(x=310, y=230)
                    
            
        
        
   
    def showfind():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page2db')
        t.config(bg='lightblue')
        def dest():
            t.destroy()
        lt = []

        # combobox function
        def filldata():
            db = pymysql.connect(host='localhost', user='root', password='root', database='scm')
            cur = db.cursor()
            sql = "Select serviceid from servicetypes"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        
        def finddata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = e1.get()
            # delete previous data find before
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            sql = "Select prodcatid,sname,charges,timetosolve from servicetypes where serviceid='%s'" % (xa)
            cur.execute(sql)
            # fetchone to get data using index positions
            data = cur.fetchone()
            e2.insert(0, data[0])
            e3.insert(0, data[1])
            e4.insert(0, data[2])
            e5.insert(0, data[3])

            db.close()
        l6 = Label(t, text='service type details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=250, y=7)

        l1 = Label(t, text='Service Id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=60)

        b1 = Button(t, text='Find',font=('arial',15,'bold'), bg='blue', command=finddata)
        b1.place(x=230, y=90)

        e1 = ttk.Combobox(t,font=('arial',13),width=34)
        # call function filldata below
        filldata()
        e1['values'] = lt
        e1.place(x=300, y=60)

        l2 = Label(t, text='Prodcat Id',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=120)

        e2 = Entry(t, width=30,font=('arial',15))
        e2.place(x=300, y=120)

        l3 = Label(t, text='Service Name',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=180)

        e3 = Entry(t, width=30,font=('arial',15))
        e3.place(x=300, y=180)

        l4 = Label(t, text='Charges',font=('arial',15,'bold'),bg='lightblue')
        l4.place(x=100, y=240)

        e4 = Entry(t, width=30,font=('arial',15))
        e4.place(x=300, y=240)

        l5 = Label(t, text='Time to solve',font=('arial',15,'bold'),bg='lightblue')
        l5.place(x=100, y=300)

        e5 = Entry(t, width=30,font=('arial',15))
        e5.place(x=300, y=300)
        
        b2 = Button(t, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b2.place(x=230, y=360)


    b2 = Button(t, text='Find', bg='blue', font=('arial', 20), command=showfind)
    b2.place(x=420, y=230)


    def showdelete():
        t = tkinter.Tk()
        t.geometry('640x480')
        t.title('page3db')
        t.config(bg='lightblue')
        cdi=[]
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select serviceid from servicetypes"
        
            
            cur.execute(sql)           
            data=cur.fetchall()
            for res in data:
                cdi.append(res[0])
       

        def deletedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()

            sql = "delete from servicetypes where serviceid='%s'" % (xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'deleted')
            db.close()
            a1.delete(0, 100)
        l6 = Label(t, text='service type details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=10)
        a = Label(t, text='Service Id',font=('arial',15,'bold'),bg='lightblue')
        a.place(x=150, y=60)
        #a1 = Entry(t, width=20,font=('arial',15))
        #a1.place(x=300, y=60)
        a1 = ttk.Combobox(t)
        filldata()
        a1['values'] = cdi
        a1.place(x=300, y=60)
        b = Button(t, text='Delete',font=('arial',15,'bold'), bg='blue', command=deletedata)
        b.place(x=250, y=100)


    b3 = Button(t, text='Delete', bg='blue', font=('arial', 20), command=showdelete)
    b3.place(x=510, y=230)


    def showupdate():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page4db')
        t.config(bg='lightblue')
        def dest():
            t.destroy()
        lt = []

        def filldata():
            db = pymysql.connect(host='localhost', user='root', password='root', database='scm')
            cur = db.cursor()
            sql = "select serviceid from servicetypes"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        def updatedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = (a1.get())
            xb = b1.get()
            xc = d1.get()
            xd = int(f1.get())
            xe = h1.get()

            sql = "update servicetypes set prodcatid='%s',sname='%s',charges=%d,timetosolve='%s' where serviceid='%s'" % (xb, xc, xd, xe, xa)

            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'update done')
            a1.delete(0, 100)

            b1.delete(0, data[0])
            d1.delete(0, data[1])
            f1.delete(0, data[2])
            h1.delete(0, data[3])

        l6 = Label(t, text='service type details', font=('arial', 20),bg='lightblue')
        l6.place(x=200, y=7)
        a = Label(t, text='Service Id',font=('arial',15,'bold'),bg='lightblue')
        a.place(x=100, y=60)
        a1 = ttk.Combobox(t,font=('arial',13),widh=34)
        filldata()
        a1['values'] = lt
        a1.place(x=300, y=60)

        b = Label(t, text='Prodcat Id',font=('arial',15,'bold'),bg='lightblue')
        b.place(x=100, y=100)
        b1 = Entry(t, width=30,font=('arial',15))
        b1.place(x=300, y=100)
        d = Label(t, text='Service Name',font=('arial',15,'bold'),bg='lightblue')
        d.place(x=100, y=140)
        d1 = Entry(t, width=30,font=('arial',15))
        d1.place(x=300, y=140)
        f = Label(t, text='Charges',font=('arial',15,'bold'),bg='lightblue')
        f.place(x=100, y=180)
        f1 = Entry(t, width=30,font=('arial',15))
        f1.place(x=300, y=180)
        h = Label(t, text='Time to solve',font=('arial',15,'bold'),bg='lightblue')
        h.place(x=100, y=220)
        h1 = Entry(t, width=30,font=('arial',15))
        h1.place(x=300, y=220)

        p = Button(t, text='update',font=('arial',15,'bold'), bg='blue', command=updatedata)
        p.place(x=150, y=300)
        
        p1 = Button(t, text='close',font=('arial',15,'bold'), bg='blue', command=dest)
        p1.place(x=250, y=300)


    b4 = Button(t, text='Update', bg='blue', font=('arial', 20), command=showupdate)
    b4.place(x=630, y=230)


    def showdatashow():
        t = tkinter.Tk()
        t.geometry('800x800')
        t.title('page5db')
        t.config(bg='lightblue')

        def showdata():
            global recd
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select * from servicetypes"
            cur.execute(sql)
            l6 = Label(t, text='service type details', font=('arial', 20,'bold'),bg='lightblue')
            l6.place(x=200, y=10)
            data = cur.fetchall()
            for res in data:
                recd = recd+'\t'+(res[0])
                recd = recd+'\t'+(res[1])
                recd = recd+'\t'+(res[2])
                recd = recd+'\t'+str(res[3])
                recd = recd+'\t'+(res[4])

                recd = recd+'\n'
            db.close()

        e = Text(t, width=150, height=50,font=('arial',15))
        showdata()
        e.insert(tkinter.END, recd)
        e.place(x=10, y=70)


    b5 = Button(t, text='Show', bg='blue', font=('arial', 20), command=showdatashow)
    b5.place(x=750, y=230)


    def shownavigate():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page6db')
        t.config(bg='lightblue')
        def dest():
            t.destroy()
        xa = []
        xb = []
        xc = []
        xd = []
        xe = []

        i = 0

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select*from servicetypes"
            cur.execute(sql)
            l6 = Label(t, text='service type details', font=('arial', 20,'bold'),bg='lightblue')
            l6.place(x=150, y=4)
            data = cur.fetchall()
            for res in data:
                xa.append(res[0])
                xb.append(res[1])
                xc.append(res[2])
                xd.append(res[3])
                xe.append(res[4])

            db.close()

        def first():
            global i
            i = 0
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, str(xd[i]))
            e5.insert(0, xe[i])

        def next():
            global i
            i = i+1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, str(xd[i]))
            e5.insert(0, xe[i])

        def previous():
            global i
            i = i-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, str(xd[i]))
            e5.insert(0, xe[i])

        def last():
            global i
            i = len(xa)-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, str(xd[i]))
            e5.insert(0, xe[i])

        l1 = Label(t, text='Service Id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=60)

        e1 = Entry(t, width=30,font=('arial',15))
        e1.place(x=300, y=60)
        l2 = Label(t, text='Prodcat Id',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=100)

        e2 = Entry(t, width=30,font=('arial',15))
        e2.place(x=300, y=100)

        l3 = Label(t, text='Service Name',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=140)
        e3 = Entry(t, width=30,font=('arial',15))
        e3.place(x=300, y=140)

        l4 = Label(t, text='Charges',font=('arial',15,'bold'),bg='lightblue')
        l4.place(x=100, y=180)

        e4 = Entry(t, width=30,font=('arial',15))
        e4.place(x=300, y=180)

        l5 = Label(t, text='Time to solve',font=('arial',15,'bold'),bg='lightblue')
        l5.place(x=100, y=220)

        e5 = Entry(t, width=30,font=('arial',15))
        e5.place(x=300, y=220)

        b1 = Button(t, text='First',font=('arial',15,'bold'), bg='blue', command=first)
        b1.place(x=100, y=300)

        b2 = Button(t, text='Next',font=('arial',15,'bold'), bg='blue', command=next)
        b2.place(x=200, y=300)
        b3 = Button(t, text='Previous',font=('arial',15,'bold'), bg='blue', command=previous)
        b3.place(x=300, y=300)
        b4 = Button(t, text='Last',font=('arial',15,'bold'), bg='blue', command=last)
        b4.place(x=450, y=300)
        b5 = Button(t, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b5.place(x=550, y=300)
        filldata()


    b6 = Button(t, text='Navigate', bg='blue', font=('arial', 20), command=shownavigate)
    b6.place(x=860, y=230)


    a = Label(t, text='Engineers', font=('arial', 25,'bold'),bg='pink')
    a.place(x=10, y=320)


    def showinsert():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page1db')
        t.config(bg='lightblue')
       
        cdi=[] 
        def dest():
            cdi.clear()
            t.destroy()
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select prodcatid from product_category"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
                cur=db.cursor()
                xa=e1.get()
                sql="select count(*)from engineers where engid='%s'"%(xa)
                cur.execute(sql)
                dta=cur.fetchall()
                if data[0]==0:
                    messagebox.showinfo('hii','ok go')
                else:
                
                 cdi.append(res[0])
            db.close()
        def savedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            xa=e1.get()
            sql="select count(*) from engineers where engid='%s'"%(xa)
            cur.execute(sql)
            data=cur.fetchall()
            if (e1.get())==0 or  (e2.get())==0 or (e3.get())==0 or (e4.get())==0 or (e5.get())==0  or (e7.get())==0:
                messagebox.showerror('Error','Invalid')
            elif data:
                    messagebox.showerror('Invalid','Invalid  details')
            else:
                db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
                cur=db.cursor()
                xa=e1.get()
                xb=e2.get()
                xc=e3.get()
                xd=e4.get()
                xe=e5.get()
                xf=e6.get()
                xg=e7.get()
        
                
                sql="insert into engineers values('%s','%s','%s','%s','%s','%s','%s')"%(xa,xb,xc,xd,xe,xf,xg)
                cur.execute(sql)
                db.commit()
                messagebox.showinfo('hi','saved')
                db.close()
                e1.delete(0,100)
                e2.delete(0,100)
                e3.delete(0,100)
                e4.delete(0,100)
                e5.delete(0,100)
                e6.delete(0,100)
                e7.delete(0,100)
        
        
       
        

        l6 = Label(t, text='engineer Details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=7)
        l1 = Label(t, text='Engineer id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=60)

        e1 = Entry(t, width=30,font=('arial',15))
        e1.place(x=300, y=60)
        

        l2 = Label(t, text='Engineer Name',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=100)

        e2 = Entry(t, width=30,font=('arial',15))
        e2.place(x=300, y=100)

        l3 = Label(t, text='Address',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=140)

        e3 = Entry(t, width=30,font=('arial',15))
        e3.place(x=300, y=140)

        l4 = Label(t, text='Phone',font=('arial',15,'bold'),bg='lightblue')
        l4.place(x=100, y=180)

        e4 = Entry(t, width=30,font=('arial',15))
        e4.place(x=300, y=180)

        l5 = Label(t, text='Email',font=('arial',15,'bold'),bg='lightblue')
        l5.place(x=100, y=220)

        e5 = Entry(t, width=30,font=('arial',15))
        e5.place(x=300, y=220)

        l6 = Label(t, text='Prodcat id',font=('arial',15,'bold'),bg='lightblue')
        l6.place(x=100, y=260)

        #e6 = Entry(t, width=30,bg='lightgreen',font=('arial',15))
        #e6.place(x=300, y=260)
        e6=ttk.Combobox(t,font=('arial',13),width=34)
        filldata()
        e6['values']=cdi
        e6.place(x=300,y=260)

        l7 = Label(t, text='Status',font=('arial',15,'bold'),bg='lightblue')
        l7.place(x=100, y=300)

        e7 = Entry(t, width=30,font=('arial',15))
        e7.place(x=300, y=300)

        b1 = Button(t, text='Save',font=('arial',15,'bold'), bg='blue', command=savedata)
        b1.place(x=100, y=350)

        b2 = Button(t, text='Close',font=('arial',15,'bold'), bg='blue',command=dest)
        b2.place(x=200, y=350)
        
        #b3 = Button(t,text='Check',font=('arial',15,'bold'), bg='blue',command=checkdata)
        #b3.place(x=300, y=350)


    b1 = Button(t, text='Insert', bg='blue', font=('arial', 20), command=showinsert)
    b1.place(x=310, y=310)


    def showfind():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page2db')
        t.config(bg='lightblue')
        def dest():
            t.destroy()
        
        lt = []

        # combobox function
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "Select engid from engineers"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()
        def finddata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = e1.get()
            # delete previous data find before
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e7.delete(0, 100)

            sql = "Select ename,address,phone,email,prodcatid,status from engineers where engid='%s'" % (xa)
            cur.execute(sql)
            # fetchone to get data using index positions
            data = cur.fetchone()
            e2.insert(0, data[0])
            e3.insert(0, data[1])
            e4.insert(0, data[2])
            e5.insert(0, data[3])
            e6.insert(0, data[4])
            e7.insert(0, data[5])

            db.close()
        l6 = Label(t, text='engineer details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=7)

        l1 = Label(t, text='Engineer id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=60)

        b1 = Button(t, text='Find',font=('arial',15,'bold'), bg='blue', command=finddata)
        b1.place(x=200, y=90)

        e1 = ttk.Combobox(t,font=('arial',13),width=34)
        # call function filldata below
        filldata()
        e1['values'] = lt
        e1.place(x=300, y=60)

        l2 = Label(t, text='Engineer Name',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=140)

        e2 = Entry(t, width=30,font=('arial',15))
        e2.place(x=300, y=140)

        l3 = Label(t, text='Address',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=180)

        e3 = Entry(t, width=30,font=('arial',15))
        e3.place(x=300, y=180)

        l4 = Label(t, text='Phone',font=('arial',15,'bold'),bg='lightblue')
        l4.place(x=100, y=220)

        e4 = Entry(t, width=30,font=('arial',15))
        e4.place(x=300, y=220)

        l5 = Label(t, text='Email',font=('arial',15,'bold'),bg='lightblue')
        l5.place(x=100, y=260)

        e5 = Entry(t, width=30,font=('arial',15))
        e5.place(x=300, y=260)

        l6 = Label(t, text='Prodcat id',font=('arial',15,'bold'),bg='lightblue')
        l6.place(x=100, y=300)

        e6 = Entry(t, width=30,font=('arial',15))
        e6.place(x=300, y=300)

        l7 = Label(t, text='Status',font=('arial',15,'bold'),bg='lightblue')
        l7.place(x=100, y=340)

        e7 = Entry(t, width=30,font=('arial',15))
        e7.place(x=300, y=340)
        
        b3 = Button(t, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b3.place(x=200, y=380)


    b2 = Button(t, text='Find', bg='blue', font=('arial', 20), command=showfind)
    b2.place(x=420, y=310)


    def showdelete():
        t = tkinter.Tk()
        t.geometry('640x480')
        t.title('page3db')
        t.config(bg='lightblue')
        cdi=[]
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select engid from engineers"
        
            
            cur.execute(sql)           
            data=cur.fetchall()
            for res in data:
                cdi.append(res[0])
       

        def deletedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()

            sql = "delete from engineers where engid='%s'" % (xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'deleted')
            db.close()
            a1.delete(0, 100)
        l6 = Label(t, text='engineer details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=10)
        a = Label(t, text='Engineer id',font=('arial',15,'bold'),bg='lightblue')
        a.place(x=150, y=60)
        #a1 = Entry(t, width=20,font=('arial',15))
        #a1.place(x=300, y=60)
        a1 = ttk.Combobox(t)
        filldata()
        a1['values'] = cdi
        a1.place(x=300, y=60)
        b = Button(t, text='Delete',font=('arial',15,'bold'), bg='blue', command=deletedata)
        b.place(x=170, y=100)


    b3 = Button(t, text='Delete', bg='blue', font=('arial', 20), command=showdelete)
    b3.place(x=510, y=310)


    def showupdate():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page4db')
        t.config(bg='lightblue')
        def dest():
            t.destroy()
        lt = []

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select engid from engineers"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        def updatedata():
            db = pymysql.connect(host='localhost', user='root', password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()
            xb = b1.get()
            xc = d1.get()
            xd = f1.get()
            xe = h1.get()
            xf = g1.get()
            xg = s1.get()

            sql = "update engineers set ename='%s',address='%s',phone='%s',email='%s',prodcatid='%s',status='%s' where engid='%s'" % (xb, xc, xd, xe, xf, xg, xa)

            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'update done')
            a1.delete(0, 100)

            b1.delete(0, data[0])
            d1.delete(0, data[1])
            f1.delete(0, data[2])
            h1.delete(0, data[3])
            g1.delete(0, data[4])
            s1.delete(0, data[5])

        l6 = Label(t, text='engineer details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=7)
        a = Label(t, text='Engineer id',font=('arial',15,'bold'),bg='lightblue')
        a.place(x=100, y=60)
        a1 = ttk.Combobox(t,font('arial',13))
        filldata()
        a1['values'] = lt
        a1.place(x=300, y=60)

        b = Label(t, text='Engineer Name',font=('arial',15,'bold'),bg='lightblue')
        b.place(x=100, y=100)
        b1 = Entry(t, width=30,font=('arial',15))
        b1.place(x=300, y=100)
        d = Label(t, text='Address',font=('arial',15,'bold'),bg='lightblue')
        d.place(x=100, y=140)
        d1 = Entry(t, width=30,font=('arial',15))
        d1.place(x=300, y=140)
        f = Label(t, text='Phone',font=('arial',15,'bold'),bg='lightblue')
        f.place(x=100, y=180)
        f1 = Entry(t, width=30,font=('arial',15))
        f1.place(x=300, y=180)
        h = Label(t, text='Email',font=('arial',15,'bold'),bg='lightblue')
        h.place(x=100, y=220)
        h1 = Entry(t, width=30,font=('arial',15))
        h1.place(x=300, y=220)
        g = Label(t, text='Prodcat id',font=('arial',15,'bold'),bg='lightblue')
        g.place(x=100, y=260)
        g1 = Entry(t, width=30,font=('arial',15))
        g1.place(x=300, y=260)
        s = Label(t, text='Status',font=('arial',15,'bold'),bg='lightblue')
        s.place(x=100, y=300)
        s1 = Entry(t, width=30,font=('arial',15))
        s1.place(x=300, y=300)
        b = Button(t, text='update',font=('arial',15,'bold'), bg='blue', command=updatedata)
        b.place(x=350, y=350)
        b1 = Button(t, text='close',font=('arial',15,'bold'), bg='blue', command=dest)
        b1.place(x=450, y=350)


    b4 = Button(t, text='Update', bg='blue', font=('arial', 20), command=showupdate)
    b4.place(x=630, y=310)


    def showdatashow():
        t = tkinter.Tk()
        t.geometry('800x800')
        t.title('page5db')
        t.config(bg='lightblue')

        def showdata():
            global recd
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select * from engineers"
            cur.execute(sql)
            l6 = Label(t, text='engineer details', font=('arial', 30,'bold'),bg='lightblue')
            l6.place(x=200, y=10)
            data = cur.fetchall()
            for res in data:
                recd = recd+'\t'+(res[0])
                recd = recd+'\t'+(res[1])
                recd = recd+'\t'+(res[2])
                recd = recd+'\t'+(res[3])
                recd = recd+'\t'+(res[4])
                recd = recd+'\t'+(res[5])
                recd = recd+'\t'+(res[6])

                recd = recd+'\n'
            db.close()

        e = Text(t, width=150, height=50,font=('arial',15))
        showdata()
        e.insert(tkinter.END, recd)
        e.place(x=10, y=70)


    b5 = Button(t, text='Show', bg='blue', font=('arial', 20), command=showdatashow)
    b5.place(x=750, y=310)


    def shownavigate():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page6db')
        t.config(bg='lightblue')
        def dest():
            t.destroy()
        xa = []
        xb = []
        xc = []
        xd = []
        xe = []
        xf = []
        xg = []
        i = 0

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select*from engineers"
            cur.execute(sql)
            l6 = Label(t, text='engineer details', font=('arial', 20,'bold'),bg='lightblue')
            l6.place(x=150, y=4)
            data = cur.fetchall()
            for res in data:
                xa.append(res[0])
                xb.append(res[1])
                xc.append(res[2])
                xd.append(res[3])
                xe.append(res[4])
                xf.append(res[5])
                xg.append(res[6])
            db.close()

        def first():
            global i
            i = 0
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            x7.delete(0, 100)
            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xf[i])
            e7.ijsert(0, xg[i])

        def next():
            global i
            i = i+1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e7.delete(0, 100)
            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xe[i])
            e7.insert(0, xe[i])

        def previous():
            global i
            i = i-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e7.delete(0, 100)
            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xf[i])
            e7.insert(0, xg[i])

        def last():
            global i
            i = len(xa)-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e7.delete(0, 100)
            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xf[i])
            e7.insert(0, xg[i])

        l1 = Label(t, text='Engineer id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=60)

        e1 = Entry(t, width=30,font=('arial',15))
        e1.place(x=300, y=60)
        l2 = Label(t, text='Engineer Name',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=100)

        e2 = Entry(t, width=30,font=('arial',15))
        e2.place(x=300, y=100)

        l3 = Label(t, text='Address',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=140)
        e3 = Entry(t, width=30,font=('arial',15))
        e3.place(x=300, y=140)

        l4 = Label(t, text='Phone',font=('arial',15,'bold'),bg='lightblue')
        l4.place(x=100, y=180)

        e4 = Entry(t, width=30,font=('arial',15))
        e4.place(x=300, y=180)

        l5 = Label(t, text='Email',font=('arial',15,'bold'),bg='lightblue')
        l5.place(x=100, y=220)

        e5 = Entry(t, width=30,font=('arial',15))
        e5.place(x=300, y=220)

        l6 = Label(t, text='Prodcat id',font=('arial',15,'bold'),bg='lightblue')
        l6.place(x=100, y=260)

        e6 = Entry(t, width=30,font=('arial',15))
        e6.place(x=300, y=260)

        l7 = Label(t, text='Status',font=('arial',15,'bold'),bg='lightblue')
        l7.place(x=100, y=300)

        e7 = Entry(t, width=30,font=('arial',15))
        e7.place(x=300, y=300)

        b1 = Button(t, text='First',font=('arial',15,'bold'), bg='blue', command=first)
        b1.place(x=100, y=350)

        b2 = Button(t, text='Next',font=('arial',15,'bold'), bg='blue', command=next)
        b2.place(x=200, y=350)
        b3 = Button(t, text='Previous',font=('arial',15,'bold'), bg='blue', command=previous)
        b3.place(x=300, y=350)
        b4 = Button(t, text='Last',font=('arial',15,'bold'), bg='blue', command=last)
        b4.place(x=450, y=350)
        b5 = Button(t, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b5.place(x=550, y=350)
        filldata()


    b6 = Button(t, text='Navigate', bg='blue', font=('arial', 20), command=shownavigate)
    b6.place(x=860, y=310)


    a = Label(t, text='Customers', font=('arial', 25,'bold'),bg='pink')
    a.place(x=10, y=410)


    def showinsert():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page1db')
        t.config(bg='yellow')
        cdi=[] 
        def dest():
            cdi.clear()
            t.destroy()
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select prodcatid from product_category"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
                cur=db.cursor()
                xa=e1.get()
                sql="select count(*)from customers where custid='%s'"%(xa)
                cur.execute(sql)
                dta=cur.fetchall()
                if data[0]==0:
                    messagebox.showinfo('hii','ok go')
                else:
                
                 cdi.append(res[0])
            db.close()
        def savedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            xa=e1.get()
            sql="select * from customers where custid='%s'"%(xa)
            cur.execute(sql)
            data=cur.fetchall()
            if data:
                messagebox.showerror("Error","Invalid details")
            elif (e1.get())==0 or  (e2.get())==0 or (e3.get())==0 or (e4.get())==0 or (e5.get())==0  or (e6.get())==0:
                messagebox.showerror('Invalid','Invalid details')
            else:
                db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
                cur=db.cursor()
                xa=e1.get()
                xb=e2.get()
                xc=e3.get()
                xd=e4.get()
                xe=e5.get()
                xf=e6.get()
                
        
                
                sql="insert into customers values('%s','%s','%s','%s','%s','%s')"%(xa,xb,xc,xd,xe,xf)
                cur.execute(sql)
                db.commit()
                messagebox.showinfo('hi','saved')
                db.close()
                e1.delete(0,100)
                e2.delete(0,100)
                e3.delete(0,100)
                e4.delete(0,100)
                e5.delete(0,100)
                e6.delete(0,100)
                
        
        
        

        l6 = Label(t, text='customer details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)
        l1 = Label(t, text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=60)

        e1 = Entry(t, width=30,font=('arial',15))
        e1.place(x=300, y=60)
        

        l2 = Label(t, text='Customer Name',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=100)

        e2 = Entry(t, width=30,font=('arial',15))
        e2.place(x=300, y=100)

        l3 = Label(t, text='Address',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=140)

        e3 = Entry(t, width=30,font=('arial',15))
        e3.place(x=300, y=140)

        l4 = Label(t, text='Email',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=180)

        e4 = Entry(t, width=30,font=('arial',15))
        e4.place(x=300, y=180)

        l5 = Label(t, text='Phone',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=220)

        e5 = Entry(t, width=30,font=('arial',15))
        e5.place(x=300, y=220)

        l6 = Label(t, text='Prodcat id',font=('arial',15,'bold'),bg='yellow')
        l6.place(x=100, y=260)

        #e6 = Entry(t, width=30,font=('arial',15))
        #e6.place(x=300, y=260)
        e6=ttk.Combobox(t,font=('arial',13),width=34)
        filldata()
        e6['values']=cdi
        e6.place(x=300,y=260)

        b1 = Button(t, text='Save',font=('arial',15,'bold'), bg='blue', command=savedata)
        b1.place(x=100, y=350)

        b2 = Button(t, text='Close',font=('arial',15,'bold'), bg='blue',command=dest)
        b2.place(x=200, y=350)
        
       # b3 = Button(t, text='Check',font=('arial',15,'bold'), bg='blue',command=checkdata)
       # b3.place(x=300, y=350)


    b1 = Button(t, text='Insert', bg='orange', font=('arial', 20), command=showinsert)
    b1.place(x=310, y=400)


    def showfind():
        t = tkinter.Tk()
        t.geometry('740x520')
        t.title('page2db')
        t.config(bg='yellow')
        lt = []
        def dest():
            t.destroy()

        # combobox function
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "Select custid from customers"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        
        def finddata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = e1.get()
            # delete previous data find before
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)

            sql = "Select cname,address,email,phone,prodcatid from customers where custid='%s'" % (xa)
            cur.execute(sql)
            # fetchone to get data using index positions
            data = cur.fetchone()
            e2.insert(0, data[0])
            e3.insert(0, data[1])
            e4.insert(0, data[2])
            e5.insert(0, data[3])
            e6.insert(0, data[4])

            db.close()
        l6 = Label(t, text='customer details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)

        l1 = Label(t, text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=80)
        b1 = Button(t, text='Find',font=('arial',15,'bold'), bg='blue', command=finddata)
        b1.place(x=220, y=100)

       

        e1 = ttk.Combobox(t,font=('arial',13),width=34)
        # call function filldata below
        filldata()
        e1['values'] = lt
        e1.place(x=300, y=80)
        

        l2 = Label(t, text='customer name',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=140)

        e2 = Entry(t, width=30,font=('arial',15))
        e2.place(x=300, y=140)

        l3 = Label(t, text='address',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=200)

        e3 = Entry(t, width=30,font=('arial',15))
        e3.place(x=300, y=200)

        l4 = Label(t, text='email',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=260)

        e4 = Entry(t, width=30,font=('arial',15))
        e4.place(x=300, y=260)

        l5 = Label(t, text='phone',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=320)

        e5 = Entry(t, width=30,font=('arial',15))
        e5.place(x=300, y=320)

        l6 = Label(t, text='prodcat id',font=('arial',15,'bold'),bg='yellow')
        l6.place(x=100, y=380)

        e6 = Entry(t, width=30,font=('arial',15))
        e6.place(x=300, y=380)
        
        b2 = Button(t, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b2.place(x=150, y=440)


    b2 = Button(t, text='Find', bg='orange', font=('arial', 20), command=showfind)
    b2.place(x=420, y=400)


    def showdelete():
        t = tkinter.Tk()
        t.geometry('640x480')
        t.title('page3db')
        t.config(bg='yellow')
        cdi=[]
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select custid from customers"
        
            
            cur.execute(sql)           
            data=cur.fetchall()
            for res in data:
                cdi.append(res[0])
       

        def deletedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()

            sql = "delete from customers where custid='%s'" % (xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'deleted')
            db.close()
            a1.delete(0, 100)
        l6 = Label(t, text='customer details', font=('arial', 20),bg='yellow')
        l6.place(x=200, y=10)
        a = Label(t, text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        a.place(x=150, y=60)
        #a1 = Entry(t, width=20,font=('arial',15))
       # a1.place(x=300, y=60)
        a1 = ttk.Combobox(t)
        filldata()
        a1['values'] = cdi
        a1.place(x=300, y=60)
        b = Button(t, text='Delete',font=('arial',15,'bold'), bg='blue', command=deletedata)
        b.place(x=170, y=100)


    b3 = Button(t, text='Delete', bg='orange', font=('arial', 20), command=showdelete)
    b3.place(x=510, y=400)


    def showupdate():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page4db')
        t.config(bg='yellow')
        lt = []
        def dest():
            t.destroy()

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select custid from customers"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        def updatedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()
            xb = b1.get()
            xc = d1.get()
            xd = f1.get()
            xe = h1.get()
            xf = g1.get()

            sql = "update customers set cname='%s',address='%s',email='%s',phone='%s',prodcatid where custid='%s'" % (xb, xc, xd, xe, xf, xa)

            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'update done')
            a1.delete(0, 100)

            b1.delete(0, data[0])
            d1.delete(0, data[1])
            f1.delete(0, data[2])
            h1.delete(0, data[3])
            g1.delete(0, data[4])
            s1.delete(0, data[5])

        l6 = Label(t, text='customer details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)
        a = Label(t, text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        a.place(x=100, y=60)
        a1 = ttk.Combobox(t,font=('arial',13),width=34)
        filldata()
        a1['values'] = lt
        a1.place(x=300, y=60)

        b = Label(t, text='Customer Name',font=('arial',15,'bold'),bg='yellow')
        b.place(x=100, y=100)
        b1 = Entry(t, width=30,font=('arial',15))
        b1.place(x=300, y=100)
        d = Label(t, text='Address',font=('arial',15,'bold'),bg='yellow')
        d.place(x=100, y=140)
        d1 = Entry(t, width=30,font=('arial',15))
        d1.place(x=300, y=140)
        f = Label(t, text='Email',font=('arial',15,'bold'),bg='yellow')
        f.place(x=100, y=180)
        f1 = Entry(t, width=30,font=('arial',15))
        f1.place(x=300, y=180)
        h = Label(t, text='Phone',font=('arial',15,'bold'),bg='yellow')
        h.place(x=100, y=220)
        h1 = Entry(t, width=30,font=('arial',15))
        h1.place(x=300, y=220)
        g = Label(t, text='Prodcat Id',font=('arial',15,'bold'),bg='yellow')
        g.place(x=100, y=260)
        g1 = Entry(t, width=30,font=('arial',15))
        g1.place(x=300, y=260)

        b = Button(t, text='update',font=('arial',15,'bold'), bg='blue', command=updatedata)
        b.place(x=200, y=300)
        b1 = Button(t, text='close',font=('arial',15,'bold'), bg='blue', command=dest)
        b1.place(x=300, y=300)


    b4 = Button(t, text='Update', bg='orange', font=('arial', 20), command=showupdate)
    b4.place(x=630, y=400)


    def showdatashow():
        t = tkinter.Tk()
        t.geometry('800x800')
        t.title('page5db')
        t.config(bg='yellow')

        def showdata():
            global recd
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select * from customers"
            cur.execute(sql)
            l6 = Label(t, text='customer details', font=('arial', 20,'bold'),bg='yellow')
            l6.place(x=200, y=10)
            data = cur.fetchall()
            for res in data:
                recd = recd+'\t'+(res[0])
                recd = recd+'\t'+(res[1])
                recd = recd+'\t'+(res[2])
                recd = recd+'\t'+(res[3])
                recd = recd+'\t'+(res[4])
                recd = recd+'\t'+(res[5])

                recd = recd+'\n'
            db.close()

        e = Text(t, width=150, height=50,bg='skyblue',font=('arial',15))
        showdata()
        e.insert(tkinter.END, recd)
        e.place(x=10, y=70)


    b5 = Button(t, text='Show', bg='orange', font=('arial', 20), command=showdatashow)
    b5.place(x=750, y=400)


    def shownavigate():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page6db')
        t.config(bg='yellow')
        def dest():
            t.destroy()
        xa = []
        xb = []
        xc = []
        xd = []
        xe = []
        xf = []
        i = 0

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select*from customers"
            cur.execute(sql)
            l6 = Label(t, text='customer details', font=('arial', 20,'bold'),bg='yellow')
            l6.place(x=200, y=4)
            data = cur.fetchall()
            for res in data:
                xa.append(res[0])
                xb.append(res[1])
                xc.append(res[2])
                xd.append(res[3])
                xe.append(res[4])
                xf.append(res[5])
            db.close()

        def first():
            global i
            i = 0
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xf[i])

        def next():
            global i
            i = i+1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xe[i])

        def previous():
            global i
            i = i-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xf[i])

        def last():
            global i
            i = len(xa)-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xf[i])

        l1 = Label(t, text='Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=60)

        e1 = Entry(t, width=30,font=('arial',15))
        e1.place(x=300, y=60)
        l2 = Label(t, text='C Name',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=100)

        e2 = Entry(t, width=30,font=('arial',15))
        e2.place(x=300, y=100)

        l3 = Label(t, text='Address',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=140)
        e3 = Entry(t, width=30,font=('arial',15))
        e3.place(x=300, y=140)

        l4 = Label(t, text='Email',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=180)

        e4 = Entry(t, width=30,font=('arial',15))
        e4.place(x=300, y=180)

        l5 = Label(t, text='Phone',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=220)

        e5 = Entry(t, width=30,font=('arial',15))
        e5.place(x=300, y=220)

        l6 = Label(t, text='regno',font=('arial',15,'bold'),bg='yellow')
        l6.place(x=100, y=260)

        e6 = Entry(t, width=30,font=('arial',15))
        e6.place(x=300, y=260)

        b1 = Button(t, text='First',font=('arial',15,'bold'), bg='blue', command=first)
        b1.place(x=100, y=350)

        b2 = Button(t, text='Next',font=('arial',15,'bold'), bg='blue', command=next)
        b2.place(x=200, y=350)
        b3 = Button(t, text='Previous',font=('arial',15,'bold'), bg='blue', command=previous)
        b3.place(x=300, y=350)
        b4 = Button(t, text='Last',font=('arial',15,'bold'), bg='blue', command=last)
        b4.place(x=450, y=350)
        b5 = Button(t, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b5.place(x=550, y=350)
        filldata()


    b6 = Button(t, text='Navigate', bg='orange', font=('arial', 20), command=shownavigate)
    b6.place(x=860, y=400)


    a = Label(t, text='Staff', font=('arial', 25,'bold'),bg='pink')
    a.place(x=10, y=480)


    def showinsert():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page1db')
        t.config(bg='yellow')
        def dest():
            t.destroy()
        def savedata():
            if len(e1.get())==0 or  len(e2.get())==0 or len(e3.get())==0 or len(e4.get())==0 or len(e5.get())==0:
                    
                    
                    messagebox.showerror('hii','Your data has been saved')
            else:
                    db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
                    cur=db.cursor()
                    xa=e1.get()
                    xb=e2.get()
                    xc=e3.get()
                    xd=e4.get()
                    xe=e5.get()
                    
                    
            
                    
                    sql="insert into staff values(%d,'%s','%s','%s','%s')"%(xa,xb,xc,xd,xe)
                    cur.execute(sql)
                    db.commit()
                    messagebox.showinfo('hi','saved')
                    db.close()
                    e1.delete(0,100)
                    e2.delete(0,100)
                    e3.delete(0,100)
                    e4.delete(0,100)
                    e5.delete(0,100)
                    
                    
            
        def checkdata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            xa=e1.get()
            sql="select count(*)from staff where staffid='%s'"%(xa)
            cur.execute(sql)
            data=cur.fetchone()
            if data[0]==0:
                messagebox.showinfo('hii','ok go')
            else:
                messagebox.showinfo('hii','already exit')
            db.close()      
            
        

        

        l6 = Label(t, text='staff details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)
        l1 = Label(t, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=60)
        

        e1 = Entry(t, width=30,font=('arial',15))
        e1.place(x=300, y=60)

        l2 = Label(t, text='Staff Name',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=100)

        e2 = Entry(t, width=30,font=('arial',15))
        e2.place(x=300, y=100)

        l3 = Label(t, text='Address',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=140)

        e3 = Entry(t, width=30,font=('arial',15))
        e3.place(x=300, y=140)

        l4 = Label(t, text='Email',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=180)

        e4 = Entry(t, width=30,font=('arial',15))
        e4.place(x=300, y=180)

        l5 = Label(t, text='Phone',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=220)

        e5 = Entry(t, width=30,font=('arial',15))
        e5.place(x=300, y=220)

        b1 = Button(t, text='Save',font=('arial',15,'bold'), bg='blue', command=savedata)
        b1.place(x=100, y=300)

        b2 = Button(t, text='Close',font=('arial',15,'bold'), bg='blue',command=dest)
        b2.place(x=200, y=300)
        b3 = Button(t, text='Check',font=('arial',15,'bold'), bg='blue',command=checkdata)
        b3.place(x=300, y=300)



    b1 = Button(t, text='Insert', bg='orange', font=('arial', 20), command=showinsert)
    b1.place(x=310, y=480)


    def showfind():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page2db')
        t.config(bg='yellow')
        def dest():
            t.destroy()
        lt = []
        

        # combobox function
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "Select staffid from staff"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        
        def finddata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = int(e1.get())
            # delete previous data find before
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            sql = "Select staffname,address,email,phone from staff where staffid=%d" % (xa)
            cur.execute(sql)
            # fetchone to get data using index positions
            data = cur.fetchone()
            e2.insert(0, data[0])
            e3.insert(0, data[1])
            e4.insert(0, data[2])
            e5.insert(0, data[3])

            db.close()
        l6 = Label(t, text='staff details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)

        l1 = Label(t, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=80)
        
       
        b1 = Button(t, text='Find',font=('arial',15,'bold'), bg='blue', command=finddata)
        b1.place(x=200, y=90)
        
        e1 = ttk.Combobox(t)
        # call function filldata below
        filldata()
        e1['values'] = lt
        e1.place(x=300, y=80)


        

        l2 = Label(t, text='Staff Name',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=140)

        e2 = Entry(t, width=30,font=('arial',15))
        e2.place(x=300, y=140)

        l3 = Label(t, text='Address',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=200)

        e3 = Entry(t, width=30,font=('arial',15))
        e3.place(x=300, y=200)

        l4 = Label(t, text='Email',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=260)

        e4 = Entry(t, width=30,font=('arial',15))
        e4.place(x=300, y=260)

        l5 = Label(t, text='Phone',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=320)

        e5 = Entry(t, width=30,font=('arial',15))
        e5.place(x=300, y=320)
        
        b2 = Button(t, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b2.place(x=200, y=380)


    b3 = Button(t, text='Find', bg='orange', font=('arial', 20), command=showfind)
    b3.place(x=420, y=480)


    def showdelete():
        t = tkinter.Tk()
        t.geometry('640x480')
        t.title('page3db')
        t.config(bg='yellow')
        cdi=[]
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select staffid from staff"
        
            
            cur.execute(sql)           
            data=cur.fetchall()
            for res in data:
                cdi.append(res[0])

        def deletedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()

            sql = "delete from staff where staffid='%s'" % (xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'deleted')
            db.close()
            a1.delete(0, 100)
        l6 = Label(t, text='staff details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=10)
        a = Label(t, text='staff id',font=('arial',15,'bold'),bg='yellow')
        a.place(x=150, y=60)
        #a1 = Entry(t, width=20,font=('arial',15))
        #a1.place(x=300, y=60)
        a1 = ttk.Combobox(t)
        filldata()
        a1['values'] = cdi
        a1.place(x=300, y=60)
        b = Button(t, text='Delete',font=('arial',15,'bold'), bg='blue', command=deletedata)
        b.place(x=170, y=100)


    b3 = Button(t, text='Delete', bg='orange', font=('arial', 20), command=showdelete)
    b3.place(x=510, y=480)


    def showupdate():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page4db')
        t.config(bg='yellow')
        def dest():
            t.destroy()
        lt = []

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select staffid from staff"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        def updatedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = int(a1.get())
            xb = b1.get()
            xc = d1.get()
            xd = f1.get()
            xe = h1.get()

            sql = "update staff set staffname='%s',address='%s',email='%s',phone='%s' where staffid=%d" % (xb, xc, xd, xe, xa)

            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'update done')
            a1.delete(0, 100)

            b1.delete(0, data[0])
            d1.delete(0, data[1])
            f1.delete(0, data[2])
            h1.delete(0, data[3])

        l6 = Label(t, text='staff details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)
        a = Label(t, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        a.place(x=100, y=60)
        a1 = ttk.Combobox(t)
        filldata()
        a1['values'] = lt
        a1.place(x=300, y=60)

        b = Label(t, text='Staff Name',font=('arial',15,'bold'),bg='yellow')
        b.place(x=100, y=100)
        b1 = Entry(t, width=30,font=('arial',15))
        b1.place(x=300, y=100)
        d = Label(t, text='Address',font=('arial',15,'bold'),bg='yellow')
        d.place(x=100, y=140)
        d1 = Entry(t, width=30,font=('arial',15))
        d1.place(x=300, y=140)
        f = Label(t, text='Email',font=('arial',15,'bold'),bg='yellow')
        f.place(x=100, y=180)
        f1 = Entry(t, width=30,font=('arial',15))
        f1.place(x=300, y=180)
        h = Label(t, text='Phone',font=('arial',15,'bold'),bg='yellow')
        h.place(x=100, y=220)
        h1 = Entry(t, width=30,font=('arial',15))
        h1.place(x=300, y=220)

        p = Button(t, text='update',font=('arial',15,'bold'), bg='blue', command=updatedata)
        p.place(x=150, y=300)
        p1 = Button(t, text='close',font=('arial',15,'bold'), bg='blue', command=dest)
        p1.place(x=250, y=300)


    b4 = Button(t, text='Update', bg='orange', font=('arial', 20), command=showupdate)
    b4.place(x=630, y=480)


    def showdatashow():
        t = tkinter.Tk()
        t.geometry('800x800')
        t.title('page5db')
        t.config(bg='yellow')

        def showdata():
            global recd
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select * from staff"
            cur.execute(sql)
            l6 = Label(t, text='staff details', font=('arial', 20,'bold'),bg='yellow')
            l6.place(x=200, y=10)
            data = cur.fetchall()
            for res in data:
                recd = recd+'\t'+str(res[0])
                recd = recd+'\t'+(res[1])
                recd = recd+'\t'+(res[2])
                recd = recd+'\t'+(res[3])
                recd = recd+'\t'+(res[4])

                recd = recd+'\n'
            db.close()

        e = Text(t, width=150, height=50,bg='skyblue',font=('arial',15))
        showdata()
        e.insert(tkinter.END, recd)
        e.place(x=10, y=70)


    b5 = Button(t, text='Show', bg='orange', font=('arial', 20), command=showdatashow)
    b5.place(x=750, y=480)


    def shownavigate():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page6db')
        t.config(bg='yellow')
        def dest():
            t.destroy()
        xa = []
        xb = []
        xc = []
        xd = []
        xe = []

        i = 0

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select*from staff"
            cur.execute(sql)
            l6 = Label(t, text='staff details', font=('arial', 20,'bold'),bg='yellow')
            l6.place(x=200, y=7)
            data = cur.fetchall()
            for res in data:
                xa.append(res[0])
                xb.append(res[1])
                xc.append(res[2])
                xd.append(res[3])
                xe.append(res[4])

            db.close()

        def first():
            global i
            i = 0
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            e1.insert(0, str(xa[i]))
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])

        def next():
            global i
            i = i+1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            e1.insert(0, str(xa[i]))
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])

        def previous():
            global i
            i = i-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            e1.insert(0, str(xa[i]))
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])

        def last():
            global i
            i = len(xa)-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            e1.insert(0, str(xa[i]))
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])

        l1 = Label(t, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=60)

        e1 = Entry(t, width=30,font=('arial',15))
        e1.place(x=300, y=60)
        l2 = Label(t, text='Staff Name',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=100)

        e2 = Entry(t, width=30,font=('arial',15))
        e2.place(x=300, y=100)

        l3 = Label(t, text='Address',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=140)
        e3 = Entry(t, width=30,font=('arial',15))
        e3.place(x=300, y=140)

        l4 = Label(t, text='Email',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=180)

        e4 = Entry(t, width=30,font=('arial',15))
        e4.place(x=300, y=180)

        l5 = Label(t, text='Phone',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=220)

        e5 = Entry(t, width=30,font=('arial',15))
        e5.place(x=300, y=220)

        b1 = Button(t, text='First',font=('arial',15,'bold'), bg='blue', command=first)
        b1.place(x=100, y=300)

        b2 = Button(t, text='Next',font=('arial',15,'bold'), bg='blue', command=next)
        b2.place(x=200, y=300)
        b3 = Button(t, text='Previous',font=('arial',15,'bold'), bg='blue', command=previous)
        b3.place(x=300, y=300)
        b4 = Button(t, text='Last',font=('arial',15,'bold'), bg='blue', command=last)
        b4.place(x=450, y=300)
        b5 = Button(t, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b5.place(x=550, y=300)
        filldata()


    b6 = Button(t, text='Navigate', bg='orange', font=('arial', 20), command=shownavigate)
    b6.place(x=860, y=480)


    a = Label(t, text='Call Assignment', font=('arial', 25,'bold'),bg='pink')
    a.place(x=10, y=560)


    def showinsert():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page1db')
        t.config(bg='yellow')
        cdi=[]
        def dest():
            cdi.clear()
            t.destroy()
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select staffid from staff"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                
                cdi.append(res[0])
            db.close()
        cdi1=[]
        def dest():
            cdi1.clear()
            t.destroy()
        def filldata1():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select custid from customers"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                
                cdi1.append(res[0])
            db.close()    
        cdi2=[]
        def dest():
            cdi2.clear()
            t.destroy()
        def filldata2():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select engid from engineers"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                 
                cdi2.append(res[0])
            db.close()       
       
            
        def savedata():
            if len(e1.get())==0 or  len(e2.get())==0 or len(e3.get())==0 or len(e4.get())==0 or len(e5.get())==0 or len(e6.get())==0:
                    
                    
                    messagebox.showerror('hii','Your data has been saved')
            else:
                    db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
                    cur=db.cursor()
                    xa=e1.get()
                    xb=int(e2.get())
                    xc=e3.get()
                    xd=e4.get()
                    xe=e5.get()
                    xf=int(e6.get())
                    
                    
            
                    
                    sql="insert into callassignment values('%s',%d,'%s','%s',%d)"%(xa,xb,xc,xd,xe,xf)
                    cur.execute(sql)
                    db.commit()
                    messagebox.showinfo('hi','saved')
                    db.close()
                    e1.delete(0,100)
                    e2.delete(0,100)
                    e3.delete(0,100)
                    e4.delete(0,100)
                    e5.delete(0,100)
                    e6.delete(0,100)
                    
                    
            
        def checkdata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            xa=e1.get()
            sql="select count(*)from callassignment where callid='%s'"%(xa)
            cur.execute(sql)
            data=cur.fetchone()
            if data[0]==0:
                messagebox.showinfo('hii','ok go')
            else:
                messagebox.showinfo('hii','already exit')
            db.close()      
            
        # code for db connectivity button

       

        l6 = Label(t, text='call assignment details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)
        l1 = Label(t, text='Call Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=60)

        e1 = Entry(t, width=30,font=('arial',15))
        e1.place(x=300, y=60)

        l2 = Label(t, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=100)

        #e2 = Entry(t, width=30,font=('arial',15))
       # e2.place(x=300, y=100)
        e2=ttk.Combobox(t,font=('arial',13),width=34)
        filldata()
        e2['values']=cdi
        e2.place(x=300,y=100)

        l3 = Label(t, text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=140)

        #e3 = Entry(t, width=30,font=('arial',15))
        #e3.place(x=300, y=140)
        e3=ttk.Combobox(t,font=('arial',13),width=34)
        filldata1()
        e3['values']=cdi1
        e3.place(x=300,y=140)

        l4 = Label(t, text='Engineer Id',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=180)

        #e4 = Entry(t, width=30,font=('arial',15))
        #e4.place(x=300, y=180)
        e3=ttk.Combobox(t,font=('arial',13),width=34)
        filldata2()
        e3['values']=cdi2
        e3.place(x=300,y=180)

        l5 = Label(t, text='Date of call',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=220)

        e5 = Entry(t, width=30,font=('arial',15))
        e5.place(x=300, y=220)

        l6 = Label(t, text='Charge',font=('arial',15,'bold'),bg='yellow')
        l6.place(x=100, y=260)

        e6 = Entry(t, width=30,font=('arial',15))
        e6.place(x=300, y=260)

        b1 = Button(t, text='Save',font=('arial',15,'bold'), bg='blue', command=savedata)
        b1.place(x=100, y=350)

        b2 = Button(t, text='Close',font=('arial',15,'bold'), bg='blue',command=dest)
        b2.place(x=200, y=350)
        b3 = Button(t, text='Check',font=('arial',15,'bold'), bg='blue',command=checkdata)
        b3.place(x=300, y=350)


    b1 = Button(t, text='Insert', bg='orange', font=('arial', 20), command=showinsert)
    b1.place(x=310, y=560)


    def showfind():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page2db')
        t.config(bg='yellow')
        def dest():
            t.destroy()
        lt = []
        

        # combobox function
        def filldata():
            db = pymysql.connect(host='localhost', user='root', password='root', database='scm')
            cur = db.cursor()
            sql = "Select callid from callassignment"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()


        def finddata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = e1.get()
            # delete previous data find before
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)

            sql = "Select staffid,custid,engid,dateofcall,charges from callassignment where callid='%s'" % (xa)
            cur.execute(sql)
            # fetchone to get data using index positions
            data = cur.fetchone()
            e2.insert(0, data[0])
            e3.insert(0, data[1])
            e4.insert(0, data[2])
            e5.insert(0, data[3])
            e6.insert(0, data[4])

            db.close()
        l6 = Label(t, text='call assignment details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)

        l1 = Label(t, text='call id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=80)

        b1 = Button(t, text='Find',font=('arial',15,'bold'), bg='blue', command=finddata)
        b1.place(x=200, y=90)

        e1 = ttk.Combobox(t,width=34)
        # call function filldata below
        filldata()
        e1['values'] = lt
        e1.place(x=300, y=80)

        l2 = Label(t, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=140)

        e2 = Entry(t, width=30,font=('arial',15))
        e2.place(x=300, y=140)

        l3 = Label(t, text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=200)

        e3 = Entry(t, width=30,font=('arial',15))
        e3.place(x=300, y=200)

        l4 = Label(t, text='Engineer Id',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=260)

        e4 = Entry(t, width=30,font=('arial',15))
        e4.place(x=300, y=260)

        l5 = Label(t, text='Date of call',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=320)

        e5 = Entry(t, width=30,font=('arial',15))
        e5.place(x=300, y=320)

        l6 = Label(t, text='Charge',font=('arial',15,'bold'),bg='yellow')
        l6.place(x=100, y=380)

        e6 = Entry(t, width=30,font=('arial',15))
        e6.place(x=300, y=380)
        b2 = Button(t, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b2.place(x=200, y=440)


    b2 = Button(t, text='Find', bg='orange', font=('arial', 20), command=showfind)
    b2.place(x=420, y=560)


    def showdelete():
        t = tkinter.Tk()
        t.geometry('640x480')
        t.title('page3db')
        t.config(bg='yellow')
        cdi=[]
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select callid from callassignment"
        
            
            cur.execute(sql)           
            data=cur.fetchall()
            for res in data:
                cdi.append(res[0])

        def deletedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()

            sql = "delete from callassignment where callid='%s'" % (xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'deleted')
            db.close()
            a1.delete(0, 100)
        l6 = Label(t, text='call assignment details', font=('arial', 20),bg='yellow')
        l6.place(x=200, y=10)
        a = Label(t, text='Call Id',font=('arial',15,'bold'),bg='yellow')
        a.place(x=150, y=60)
        #a1 = Entry(t, width=20,font=('arial',15))
        #a1.place(x=300, y=60)
        a1 = ttk.Combobox(t)
        filldata()
        a1['values'] = cdi
        a1.place(x=300, y=60)
        b = Button(t, text='Delete',font=('arial',15,'bold'), bg='blue', command=deletedata)
        b.place(x=170, y=100)


    b3 = Button(t, text='Delete', bg='orange', font=('arial', 20), command=showdelete)
    b3.place(x=510, y=560)


    def showupdate():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page4db')
        t.config(bg='yellow')
        def dest():
            t.destroy()
        lt = []

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select callid from callassignment"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        def updatedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()
            xb = b1.get()
            xc = d1.get()
            xd = f1.get()
            xe = h1.get()
            xf = g1.get()

            sql = "update callassignment set staffid=%d,custid='%s',engid='%s',dateofcall='%s',charges=%d where callid='%s'" % (xb, xc, xd, xe, xf, xa)

            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'update done')
            a1.delete(0, 100)

            b1.delete(0, data[0])
            d1.delete(0, data[1])
            f1.delete(0, data[2])
            h1.delete(0, data[3])
            g1.delete(0, data[4])
            s1.delete(0, data[5])

        l6 = Label(t, text='call assignment details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)
        a = Label(t, text='Call Id',font=('arial',15,'bold'),bg='yellow')
        a.place(x=100, y=80)
        a1 = ttk.Combobox(t,width=34)
        filldata()
        a1['values'] = lt
        a1.place(x=300, y=80)

        b = Label(t, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        b.place(x=100, y=120)
        b1 = Entry(t, width=30,font=('arial',15))
        b1.place(x=300, y=120)
        d = Label(t, text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        d.place(x=100, y=160)
        d1 = Entry(t, width=30,font=('arial',15))
        d1.place(x=300, y=160)
        f = Label(t, text='Engineer Id',font=('arial',15,'bold'),bg='yellow')
        f.place(x=100, y=200)
        f1 = Entry(t, width=30,font=('arial',15))
        f1.place(x=300, y=200)
        h = Label(t, text='Date of call',font=('arial',15,'bold'),bg='yellow')
        h.place(x=100, y=240)
        h1 = Entry(t, width=30,font=('arial',15))
        h1.place(x=300, y=240)
        g = Label(t, text='Charge',font=('arial',15,'bold'),bg='yellow')
        g.place(x=100, y=280)
        g1 = Entry(t, width=30,font=('arial',15))
        g1.place(x=300, y=280)

        b = Button(t, text='update',font=('arial',15,'bold'), bg='blue', command=updatedata)
        b.place(x=150, y=350)
        b1 = Button(t, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b1.place(x=250, y=350)


    b4 = Button(t, text='Update', bg='orange', font=('arial', 20), command=showupdate)
    b4.place(x=630, y=560)


    def showdatashow():
        t = tkinter.Tk()
        t.geometry('800x800')
        t.title('page5db')
        t.config(bg='yellow')

        def showdata():
            global recd
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select * from callassignment"
            cur.execute(sql)
            l6 = Label(t, text='call assignment details', font=('arial', 20,'bold'),bg='yellow')
            l6.place(x=200, y=10)
            data = cur.fetchall()
            for res in data:
                recd = recd+'\t'+(res[0])
                recd = recd+'\t'+str(res[1])
                recd = recd+'\t'+(res[2])
                recd = recd+'\t'+(res[3])
                recd = recd+'\t'+(res[4])
                recd = recd+'\t'+str(res[5])

                recd = recd+'\n'
            db.close()

        e = Text(t, width=150, height=50,bg='skyblue',font=('arial',15))
        showdata()
        e.insert(tkinter.END, recd)
        e.place(x=10, y=70)


    b5 = Button(t, text='Show', bg='orange', font=('arial', 20), command=showdatashow)
    b5.place(x=750, y=560)

    def shownavigate():
        t=tkinter.Tk()
        t.geometry('740x480')
        t.title('page6db')
        t.config(bg='yellow')
        def dest():
            t.destroy()
        xa=[]
        xb=[]
        xc=[]
        xd=[]
        xe=[]
        xf=[]
        i=0
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select*from callassignment"
            cur.execute(sql)
            l6=Label(t,text='call assignment Details',font=('arial',20,'bold'),bg='yellow')
            l6.place(x=150,y=4)
            data=cur.fetchall()
            for res in data:
                xa.append(res[0])
                xb.append(res[1])
                xc.append(res[2])
                xd.append(res[3])
                xe.append(res[4])
                xf.append(res[5])
            db.close()
            
        def first():
            global i
            i=0
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
            e6.delete(0,100)
            e1.insert(0,xa[i])
            e2.insert(0,str(xb[i]))
            e3.insert(0,xc[i])
            e4.insert(0,xd[i])
            e5.insert(0,xe[i])
            e6.insert(0,str(xf[i]))
            
        def next():
            global i
            i=i+1
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
            e6.delete(0,100)
            e1.insert(0,xa[i])
            e2.insert(0,str(xb[i]))
            e3.insert(0,xc[i])
            e4.insert(0,xd[i])
            e5.insert(0,xe[i])
            e6.insert(0,str(xe[i]))
            
        def previous():
            global i
            i=i-1
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
            e6.delete(0,100)
            e1.insert(0,xa[i])
            e2.insert(0,str(xb[i]))
            e3.insert(0,xc[i])
            e4.insert(0,xd[i])
            e5.insert(0,xe[i])
            e6.insert(0,str(xf[i]))
            
        def last():
            global i
            i=len(xa)-1
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
            e6.delete(0,100)
            e1.insert(0,xa[i])
            e2.insert(0,str(xb[i]))
            e3.insert(0,xc[i])
            e4.insert(0,xd[i])
            e5.insert(0,xe[i])
            e6.insert(0,str(xf[i]))
           
        l1=Label(t,text='Call Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100,y=60)

        e1=Entry(t,width=30,font=('arial',15))
        e1.place(x=300,y=60)
        l2=Label(t,text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100,y=100)

        e2=Entry(t,width=30,font=('arial',15))
        e2.place(x=300,y=100)

        l3=Label(t,text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100,y=140)
        e3=Entry(t,width=30,font=('arial',15))
        e3.place(x=300,y=140)

        l4=Label(t,text='Engineer Id',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100,y=180)

        e4=Entry(t,width=30,font=('arial',15))
        e4.place(x=300,y=180)

        l5=Label(t,text='Date Of Call',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100,y=220)

        e5=Entry(t,width=30,font=('arial',15))
        e5.place(x=300,y=220)
         
        l6=Label(t,text='Charge',font=('arial',15,'bold'),bg='yellow')
        l6.place(x=100,y=260)

        e6=Entry(t,width=30,font=('arial',15))
        e6.place(x=300,y=260)

        b1=Button(t,text='first',font=('arial',15,'bold'),bg='blue',command=first)
        b1.place(x=100,y=300)

        b2=Button(t,text='next',font=('arial',15,'bold'),bg='blue',command=next)
        b2.place(x=200,y=300)
        b3=Button(t,text='previous',font=('arial',15,'bold'),bg='blue',command=previous)
        b3.place(x=300,y=300)
        b4=Button(t,text='last',font=('arial',15,'bold'),bg='blue',command=last)
        b4.place(x=450,y=300)
        b5=Button(t,text='Close',font=('arial',15,'bold'),bg='blue',command=dest)
        b5.place(x=550,y=300)
        filldata()                  

          
    b6=Button(t,text='Navigate',bg='orange',font=('arial',20),command=shownavigate)
    b6.place(x=860,y=560)


    a = Label(t, text='Call Close', font=('arial', 25,'bold'),bg='pink')
    a.place(x=10, y=630)


    def showinsert():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page1db')
        t.config(bg='yellow')
        cdi=[]
        def dest():
            cdi.clear()
            t.destroy()
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select callid from callassignment"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                
                cdi.append(res[0])
            db.close()
        cdi1=[]
        def dest():
            cdi1.clear()
            t.destroy()
        def filldata1():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select staffid from staff"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                
                cdi1.append(res[0])
            db.close()    
        cdi2=[]
        def dest():
            cdi2.clear()
            t.destroy()
        def filldata2():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select custid from customers"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                 
                cdi2.append(res[0])
            db.close()       
        cdi3=[]
        def dest():
           cdi3.clear()
           t.destroy()
        def filldata3():
           db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
           cur=db.cursor()
           sql="select engid from engineers"
           cur.execute(sql)
           data=cur.fetchall()
           for res in data:
                
               cdi3.append(res[0])
           db.close()       
            
        def savedata():
            if len(e1.get())==0 or  len(e2.get())==0 or len(e3.get())==0 or len(e4.get())==0 or len(e5.get())==0:
                    
                    
                    messagebox.showerror('hii','Your data has been saved')
            else:
                    db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
                    cur=db.cursor()
                    xa=e1.get()
                    xb=e2.get()
                    xc=e3.get()
                    xd=e4.get()
                    xe=e5.get()
                    
                    
            
                    
                    sql="insert into staff values('%s','%s','%s','%s','%s')"%(xa,xb,xc,xd,xe)
                    cur.execute(sql)
                    db.commit()
                    messagebox.showinfo('hi','saved')
                    db.close()
                    e1.delete(0,100)
                    e2.delete(0,100)
                    e3.delete(0,100)
                    e4.delete(0,100)
                    e5.delete(0,100)
                    
                    
            
        def checkdata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            xa=e1.get()
            sql="select count(*)from callclose where callid='%s'"%(xa)
            cur.execute(sql)
            data=cur.fetchone()
            if data[0]==0:
                messagebox.showinfo('hii','ok go')
            else:
                messagebox.showinfo('hii','already exit')
            db.close()      
                 
       

        l6 = Label(t, text='call close details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)
        l1 = Label(t, text='Call Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=60)
        
        #e1 = Entry(t, width=30,font=('arial',15))
       # e1.place(x=300, y=60)
        ez = ttk.Combobox(t,width=34)
        # call function filldata below
        filldata()
        ez['values'] = cdi
        ez.place(x=300, y=60)
       

        l2 = Label(t, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=100)

        #e2 = Entry(t, width=30,font=('arial',15))
        #e2.place(x=300, y=100)
        e2 = ttk.Combobox(t,width=34)
        # call function filldata below
        filldata1()
        e2['values'] = cdi1
        e2.place(x=300, y=100)

        l3 = Label(t, text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=140)

        #e3 = Entry(t, width=30,font=('arial',15))
        #e3.place(x=300, y=140)
        e3 = ttk.Combobox(t,width=34)
        # call function filldata below
        filldata2()
        e3['values'] =cdi2
        e3.place(x=300, y=140)

        l4 = Label(t, text='Engineer Id',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=180)

        #e4 = Entry(t, width=30,font=('arial',15))
        #e4.place(x=300, y=180)
        e4 = ttk.Combobox(t,width=34)
        # call function filldata below
        filldata3()
        e4['values'] =cdi3
        e4.place(x=300, y=180)

        l5 = Label(t, text='Date of close',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=220)

        e5 = Entry(t, width=34,font=('arial',10))
        e5.place(x=300, y=220)

        b1 = Button(t, text='Save',font=('arial',15,'bold'), bg='blue', command=savedata)
        b1.place(x=100, y=300)

        b2 = Button(t, text='Close',font=('arial',15,'bold'), bg='blue',command=dest)
        b2.place(x=200, y=300)
        b3 = Button(t, text='Check',font=('arial',15,'bold'), bg='blue',command=checkdata)
        b3.place(x=300, y=300)


    b1 = Button(t, text='Insert', bg='orange', font=('arial', 20), command=showinsert)
    b1.place(x=310, y=630)


    def showfind():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page2db')
        t.config(bg='yellow')
        def dest():
            t.destroy()
        lt = []

        # combobox function
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "Select callid from callassignment"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        
        def finddata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = e1.get()
            # delete previous data find before
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            sql = "Select staffid,custid,engid,dateofclose from callclose where callid='%s'" % (xa)
            cur.execute(sql)
            # fetchone to get data using index positions
            data = cur.fetchone()
            e2.insert(0, data[0])
            e3.insert(0, data[1])
            e4.insert(0, data[2])
            e5.insert(0, data[3])

            db.close()
        l6 = Label(t, text='call close details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)

        l1 = Label(t, text='Call Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=60)

        b1 = Button(t, text='Find',font=('arial',15,'bold'), bg='blue', command=finddata)
        b1.place(x=200, y=90)

        e1 = ttk.Combobox(t)
        # call function filldata below
        filldata()
        e1['values'] = lt
        e1.place(x=300, y=60)

        l2 = Label(t, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=120)

        e2 = Entry(t, width=30,font=('arial',15))
        e2.place(x=300, y=120)

        l3 = Label(t, text='customer Id',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=180)

        e3 = Entry(t, width=30,font=('arial',15))
        e3.place(x=300, y=180)

        l4 = Label(t, text='Engineer Id',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=240)

        e4 = Entry(t, width=30,font=('arial',15))
        e4.place(x=300, y=240)

        l5 = Label(t, text='Date of close',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=300)

        e5 = Entry(t, width=30,font=('arial',15))
        e5.place(x=300, y=300)
        b2 = Button(t, text='Cloose',font=('arial',15,'bold'), bg='blue', command=dest)
        b2.place(x=200, y=360)


    b2 = Button(t, text='Find', bg='orange', font=('arial', 20), command=showfind)
    b2.place(x=420, y=630)


    def showdelete():
        t = tkinter.Tk()
        t.geometry('640x480')
        t.title('page3db')
        t.config(bg='yellow')
        cdi=[]
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select callid from callclose"
        
            
            cur.execute(sql)           
            data=cur.fetchall()
            for res in data:
                cdi.append(res[0])

        def deletedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()

            sql = "delete from callclose where callid='%s'" % (xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'deleted')
            db.close()
            a1.delete(0, 100)
        l6 = Label(t, text='call close details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=10)
        a = Label(t, text='Call Id',font=('arial',15,'bold'),bg='yellow')
        a.place(x=150, y=60)
        #a1 = Entry(t, width=20,font=('arial',15))
        #a1.place(x=250, y=60)
        a1 = ttk.Combobox(t)
        filldata()
        a1['values'] = cdi
        a1.place(x=300, y=60)
        b = Button(t, text='Delete',font=('arial',15,'bold'), bg='blue', command=deletedata)
        b.place(x=170, y=100)


    b3 = Button(t, text='Delete', bg='orange', font=('arial', 20), command=showdelete)
    b3.place(x=510, y=630)


    def showupdate():
        t = tkinter.Tk()
        t.geometry('740x480')
        t.title('page4db')
        t.config(bg='yellow')
        def dest():
            t.destroy()
        lt = []

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select callid from callclose"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        def updatedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()
            xb = int(b1.get())
            xc = d1.get()
            xd = f1.get()
            xe = h1.get()

            sql = "update callclose set staffid=%d,custid='%s',engid='%s',dateofclose='%s' where callid='%s'" % ( xb, xc, xd, xe, xa)

            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'update done')
            a1.delete(0, 100)

            b1.delete(0, data[0])
            d1.delete(0, data[1])
            f1.delete(0, data[2])
            h1.delete(0, data[3])

        l6 = Label(t, text='call close details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)
        a = Label(t, text='Call Id',font=('arial',15,'bold'),bg='yellow')
        a.place(x=100, y=80)
        a1 = ttk.Combobox(t)
        filldata()
        a1['values'] = lt
        a1.place(x=300, y=80)

        b = Label(t, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        b.place(x=100, y=120)
        b1 = Entry(t, width=30,font=('arial',15))
        b1.place(x=300, y=120)
        d = Label(t, text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        d.place(x=100, y=160)
        d1 = Entry(t, width=30,font=('arial',15))
        d1.place(x=300, y=160)
        f = Label(t, text='Engineer Id',font=('arial',15,'bold'),bg='yellow')
        f.place(x=100, y=200)
        f1 = Entry(t, width=30,font=('arial',15))
        f1.place(x=300, y=200)
        h = Label(t, text='Date of close',font=('arial',15,'bold'),bg='yellow')
        h.place(x=100, y=240)
        h1 = Entry(t, width=30,font=('arial',15))
        h1.place(x=300, y=240)

        p = Button(t, text='update',font=('arial',15,'bold'), bg='blue', command=updatedata)
        p.place(x=150, y=300)
        p1 = Button(t, text='close',font=('arial',15,'bold'), bg='blue', command=dest)
        p1.place(x=250, y=300)


    b4 = Button(t, text='Update', bg='orange', font=('arial', 20), command=showupdate)
    b4.place(x=630, y=630)


    def showdatashow():
        t = tkinter.Tk()
        t.geometry('800x800')
        t.title('page5db')
        t.config(bg='yellow')

        def showdata():
            global recd
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select * from callclose"
            cur.execute(sql)
            l6 = Label(t, text='call close details', font=('arial', 20,'bold'),bg='yellow')
            l6.place(x=200, y=10)
            data = cur.fetchall()
            for res in data:
                recd = recd+'\t'+(res[0])
                recd = recd+'\t'+str(res[1])
                recd = recd+'\t'+(res[2])
                recd = recd+'\t'+(res[3])
                recd = recd+'\t'+(res[4])

                recd = recd+'\n'
            db.close()

        e = Text(t, width=150, height=50,bg='skyblue',font=('arial',15))
        showdata()
        e.insert(tkinter.END, recd)
        e.place(x=10, y=70)


    b5 = Button(t, text='Show', bg='orange', font=('arial', 20), command=showdatashow)
    b5.place(x=750, y=630)

    def shownavigate():
        t=tkinter.Tk()
        t.geometry('740x480')
        t.title('page6db')
        t.config(bg='yellow')
        def dest():
            t.destroy()
        xa=[]
        xb=[]
        xc=[]
        xd=[]
        xe=[]
        
        i=0
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select*from callclose"
            cur.execute(sql)
            l6=Label(t,text='Call Close Details',font=('arial',20,'bold'),bg='yellow')
            l6.place(x=150,y=4)
            data=cur.fetchall()
            for res in data:
                xa.append(res[0])
                xb.append(res[1])
                xc.append(res[2])
                xd.append(res[3])
                xe.append(res[4])
                
            db.close()
            
        def first():
            global i
            i=0
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
            
            e1.insert(0,xa[i])
            e2.insert(0,str(xb[i]))
            e3.insert(0,xc[i])
            e4.insert(0,xd[i])
            e5.insert(0,xe[i])
            
            
        def next():
            global i
            i=i+1
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
            
            e1.insert(0,xa[i])
            e2.insert(0,str(xb[i]))
            e3.insert(0,xc[i])
            e4.insert(0,xd[i])
            e5.insert(0,xe[i])
            
            
        def previous():
            global i
            i=i-1
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
            
            e1.insert(0,xa[i])
            e2.insert(0,str(xb[i]))
            e3.insert(0,xc[i])
            e4.insert(0,xd[i])
            e5.insert(0,xe[i])
            
            
        def last():
            global i
            i=len(xa)-1
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
            
            e1.insert(0,xa[i])
            e2.insert(0,str(xb[i]))
            e3.insert(0,xc[i])
            e4.insert(0,xd[i])
            e5.insert(0,xe[i])
            
           
        l1=Label(t,text='Call Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100,y=60)

        e1=Entry(t,width=30,font=('arial',15))
        e1.place(x=300,y=60)
        l2=Label(t,text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100,y=100)

        e2=Entry(t,width=30,font=('arial',15))
        e2.place(x=300,y=100)

        l3=Label(t,text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100,y=140)
        e3=Entry(t,width=30,font=('arial',15))
        e3.place(x=300,y=140)

        l4=Label(t,text='Engineer Id',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100,y=180)

        e4=Entry(t,width=30,font=('arial',15))
        e4.place(x=300,y=180)

        l5=Label(t,text='Date Of Close',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100,y=220)

        e5=Entry(t,width=30,font=('arial',15))
        e5.place(x=300,y=220)
         
        

        b1=Button(t,text='First',font=('arial',15,'bold'),bg='blue',command=first)
        b1.place(x=100,y=300)

        b2=Button(t,text='Next',font=('arial',15,'bold'),bg='blue',command=next)
        b2.place(x=200,y=300)
        b3=Button(t,text='Previous',font=('arial',15,'bold'),bg='blue',command=previous)
        b3.place(x=300,y=300)
        b4=Button(t,text='Last',font=('arial',15,'bold'),bg='blue',command=last)
        b4.place(x=450,y=300)
        b5=Button(t,text='Close',font=('arial',15,'bold'),bg='blue',command=dest)
        bs.place(x=550,y=300)
        filldata()                  

          
    b6=Button(t,text='Navigate',bg='orange',font=('arial',20),command=shownavigate)
    b6.place(x=860,y=630)

    t.mainloop()


        
