import tkinter 
from tkinter import*
from tkinter import ttk
from  tkinter import messagebox
import pymysql
t=tkinter.Tk()
t.geometry('600x600')
t.title('my first screen')
def filldata():
    db=pymysql.connect(host='localhost',user='root',password='root',database='testdb')
    cur=db.cursor()
    sql="select billno from billing"
    cur.execute(sql)
    data=cur.fetchall()
    for res in data:
        lt.append(res[0])
    db.close()
def updatedata():
    db=pymysql.connect(host='localhost',user='root',password='root',database='testdb')
    cur=db.cursor()
    xa=int(a1.get())
    xb=b1.get()
    xc=d1.get()
    xd=f1.get()
    xe=int(h1.get())
    sql="update billing set cname='%s',city='%s',item='%s',amount=%d where billno=%d"%(xb,xc,xd,xe,xa)
     
    cur.execute(sql)
    db.commit()
    messagebox.showinfo('hi','update done')
    a1.delete(0,100)
     
    b1.delete(0,data[0])
    d1.delete(0,data[1])
    f1.delete(0,data[2])
    h1.delete(0,data[3])
a=Label(t,text='billno')
a.place(x=30,y=40)
a1=ttk.Combobox(t)
filldata()
a1['values']=lt



m=Button(t,text='Find')
m.place(x=30,y=70)
b=Label(t,text='C Name')
b.place(x=30,y=100)
b1=Entry(t,width=40)
b1.place(x=100,y=100)
d=Label(t,text='City')
d.place(x=30,y=130)
d1=Entry(t,width=40)
d1.place(x=100,y=130)
f=Label(t,text='Item')
f.place(x=30,y=160)
f1=Entry(t,width=40)
f1.place(x=100,y=160)
h=Label(t,text='Ammount')
h.place(x=30,y=190)
h1=Entry(t,width=40)
h1.place(x=100,y=190)
k=Button(t,text='Update',command=updatedata)
k.place(x=400,y=180)
t.mainloop()