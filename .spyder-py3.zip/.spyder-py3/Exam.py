import tkinter
import pymysql
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
recd=''
def showinsert():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('page1db')
    #code for db connectivity button
    def savedata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        xa=int(e1.get())
        xb=e2.get()
        xc=e3.get()
        
        xd=int(e4.get())
        sql="insert into exam values(%d,'%s','%s',%d)"%(xa,xb,xc,xd)
        cur.execute(sql)
        db.commit()
        messagebox.showinfo('Hi','Saved')
        db.close()
        e1.delete(0,100)
        e2.delete(0,100)
        e3.delete(0,100)
        e4.delete(0,100)
        
    l6=Label(t,text='Exam Details',font=('arial',15))
    l6.place(x=200,y=7)   


    l1=Label(t,text='rollno')
    l1.place(x=30,y=40)

    e1=Entry(t,width=18)
    e1.place(x=80,y=40)

    l2=Label(t,text='course')
    l2.place(x=30,y=80)

    e2=Entry(t,width=18)
    e2.place(x=80,y=80)

    l3=Label(t,text='duration')
    l3.place(x=30,y=120)

    e3=Entry(t,width=18)
    e3.place(x=80,y=120)

    l4=Label(t,text='fees')
    l4.place(x=30,y=160)

    e4=Entry(t,width=18)
    e4.place(x=80,y=160)


    b1=Button(t,text='Save',command=savedata)
    b1.place(x=30,y=240)

    b2=Button(t,text='Close')
    b2.place(x=80,y=240)
    t.mainloop()
def showfind():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('page2db')
    lt=[]

    #combobox function
    def filldata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        sql="Select rollno from exam"
        cur.execute(sql)
        data=cur.fetchall()
        for res in data:
            lt.append(res[0])
        db.close()

    #find data using billno as primary key
    def finddata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        xa=int(e1.get())
        #delete previous data find before
        e2.delete(0,100)
        e3.delete(0,100)
        e4.delete(0,100)
        
        
        sql="Select course,duration,fees from student where rollno=%d"%(xa)
        cur.execute(sql)
        #fetchone to get data using index positions
        data=cur.fetchone()
        e2.insert(0,data[0])
        e3.insert(0,data[1])
        e4.insert(0,data[2])
        
        db.close()
        
    l6=Label(t,text='Exam Details',font=('arial',15))
    l6.place(x=200,y=7)
    l1=Label(t,text='rollno')
    l1.place(x=30,y=40)

    b1=Button(t,text='Find',command=finddata)
    b1.place(x=30,y=80)

    e1=ttk.Combobox(t)
    #call function filldata below
    filldata()
    e1['values']=lt
    e1.place(x=80,y=40)

    l2=Label(t,text='course')
    l2.place(x=30,y=120)

    e2=Entry(t,width=18)
    e2.place(x=80,y=120)

    l3=Label(t,text='duration')
    l3.place(x=30,y=160)

    e3=Entry(t,width=18)
    e3.place(x=80,y=160)

    l4=Label(t,text='fees')
    l4.place(x=30,y=200)

    e4=Entry(t,width=18)
    e4.place(x=80,y=200)

    
def showdelete():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('page3db')
    def deletedata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        xa=int(a1.get())
        sql="delete from exam where rollno=%d"%(xa)
        cur.execute(sql)
        db.commit()
        messagebox.showinfo('hi','deleted')
        db.close()
        a1.delete(0,100)
    l6=Label(t,text='Student Details',font=('arial',15))
    l6.place(x=200,y=7)    
    a=Label(t,text='rollno')
    a.place(x=60,y=30)
    a1=Entry(t,width=20)
    a1.place(x=150,y=30)
    b=Button(t,text='Delete',command=deletedata)
    b.place(x=100,y=90)
def showupdate():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('page4db')
    lt=[]
    def filldata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        sql="select rollno from exam"
        cur.execute(sql)
        data=cur.fetchall()
        for res in data:
            lt.append(res[0])
        db.close()


    def updatedata():
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        xa=int(a1.get())
        xb=b1.get()
        xc=d1.get()
        xd=int(f1.get())
        
        sql="update exam set course='%s',duration='%s',fees=%d where rollno=%d"%(xb,xc,xd,xa)
         
        cur.execute(sql)
        db.commit()
        messagebox.showinfo('hi','update done')
        a1.delete(0,100)
         
        b1.delete(0,data[0])
        d1.delete(0,data[1])
        f1.delete(0,data[2])
        
        
    l6=Label(t,text='Exam Details',font=('arial',15))
    l6.place(x=200,y=7)          
    a=Label(t,text='rollno')
    a.place(x=30,y=40)
    a1=ttk.Combobox(t)
    filldata()
    a1['values']=lt
    a1.place(x=100,y=40)
    
    b=Label(t,text='course')
    b.place(x=30,y=100)
    b1=Entry(t,width=40)
    b1.place(x=100,y=100)
    d=Label(t,text='duration')
    d.place(x=30,y=130)
    d1=Entry(t,width=40)
    d1.place(x=100,y=130)
    f=Label(t,text='fees')
    f.place(x=30,y=160)
    f1=Entry(t,width=40)
    f1.place(x=100,y=160)

    p=Button(t,text='update',command=updatedata)
    p.place(x=150,y=250)
    t.mainloop()
def showdatashow():
    t=tkinter.Tk()
    t.geometry('640x480')
    t.title('page5db')

    def showdata():
        global recd
        db=pymysql.connect(host='localhost',user='root',password='root',database='collegeregistration')
        cur=db.cursor()
        sql="select*from exam"
        cur.execute(sql)
        l6=Label(t,text='exam Details',font=('arial',20))
        l6.place(x=200,y=10)
        data=cur.fetchall()
        for res in data:
            recd=recd+'\t'+str(res[0])
            recd=recd+'\t'+(res[1])
            recd=recd+'\t'+(res[2])
            
            recd=recd+'\t'+str(res[3])
            recd=recd+'\n'
        db.close()
    e=Text(t,width=150,height=50)
    showdata()
    e.insert(tkinter.END,recd)
    e.place(x=10,y=70)
    t.mainloop()
    
    



t=tkinter.Tk()
t.geometry('640x480')
t.title('database tkinter')
b1=Button(t,text='Insert',command=showinsert)
b1.place(x=50,y=50)
b2=Button(t,text='Find',command=showfind)
b2.place(x=100,y=50)
b3=Button(t,text='Delete',command=showdelete)
b3.place(x=150,y=50)
b4=Button(t,text='Update',command=showupdate)
b4.place(x=200,y=50)
b5=Button(t,text='Show',command=showdatashow)
b5.place(x=250,y=50)
t.mainloop()