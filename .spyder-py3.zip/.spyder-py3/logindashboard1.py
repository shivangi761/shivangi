import tkinter
import pymysql
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from dashboard1 import *
t=tkinter.Tk()
t.geometry('640x480')
t.title('login1db')
def logindata():
    if b.get()=='test' and e.get()=='123':
        showdeshboard()
    else:
        messagebox.showerror('Hi','Login Failed')
a=Label(t,text='Name')
a.place(x=50,y=50)

b=Entry(t,width=30)
b.place(x=300,y=50)


d=Label(t,text='Password')
d.place(x=50,y=100)

e=Entry(t,width=30,show='*')
e.place(x=300,y=100)

bt=Button(t,text='Login',command=logindata,bg='green',font=('arial',20,'bold'))
bt.place(x=100,y=200)

t.mainloop()