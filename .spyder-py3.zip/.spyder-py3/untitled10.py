
import tkinter
from tkinter import*
from tkinter import ttk
t=tkinter.Tk()
t.geometry('800x800')
t.title('my first screen')
def Add():
    xp=int(sp.get())
    xm=int(sp1.get())
    r=xp+xm
    d.delete(0,100)
    d.insert(0,str(r))
    
def Sub():
    xp=int(sp.get())
    xm=int(sp1.get())
    r=xp-xm
    f.delete(0,100)
    f.insert(0,str(r))
    
    
def Mul():
    xp=int(sp.get())
    xm=int(sp1.get())
    r=xp*xm
    g.delete(0,100)
    g.insert(0,str(r))

def Div():
    xp=int(sp.get())
    xm=int(sp1.get())
    r=xp/xm
    h.delete(0,100)
    h.insert(0,str(r))
    
    
a=Label(t,text='No.1')
a.place(x=30,y=10)

sp=Spinbox(t,from_=1,to=100)
sp.place(x=300,y=10)
j=Label(t,text='No.2')
j.place(x=30,y=50)
sp1=Spinbox(t,from_=1,to=100)
sp1.place(x=300,y=50)
b1=Button(t,text='+',command=Add)
b1.place(x=30,y=150)
d=Entry(t,width=40)
d.place(x=300,y=150)
b2=Button(t,text='-',command=Sub)
b2.place(x=30,y=200)
f=Entry(t,width=40)
f.place(x=300,y=200)
b3=Button(t,text='*',command=Mul)
b3.place(x=30,y=250)
g=Entry(t,width=40)
g.place(x=300,y=250)
b4=Button(t,text='/',command=Div)
b4.place(x=30,y=300)
h=Entry(t,width=40)
h.place(x=300,y=300)
t.mainloop()