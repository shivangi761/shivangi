
import tkinter
import pymysql
from tkinter import*
from tkinter import ttk
from  tkinter import messagebox
t=tkinter.Tk()
t.geometry('1200x900')
def showservicecentre():
    def showins():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)

        r5=Label(c3,text='service center details',bg='pink',fg='black',font=('arial',25))
        r5.place(x=200,y=5)
        cdi=[]
        def close():
            cdi.clear()
            t.destroy
        def filldatac():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select id from service_center"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                cdi.append(res[0])
            db.close()    
            
        def dest():
            t.destroy()
        def savedata():
            if len(e1.get())==0 or len(e2.get())==0 or len(e3.get())==0 or len(e4.get())==0 or len(e5.get())==0 or len(e6.get())==0:
                
                
                messagebox.showerror('hii','please check all')
            else:
                db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
                cur=db.cursor()
                xa=int(e1.get())
                xb=e2.get()
                xc=e3.get()
                xd=e4.get()
                xe=e5.get()
                xf=e6.get()
                
                sql="insert into service_center values(%d,'%s','%s','%s','%s','%s')"%(xa,xb,xc,xd,xe,xf)
                cur.execute(sql)
                db.commit()
                messagebox.showinfo('Hi','Saved')
                db.close()
                e1.delete(0,100)
                e2.delete(0,100)
                e3.delete(0,100)
                e4.delete(0,100)
                e5.delete(0,100)
                e6.delete(0,100)
                
        def checkdata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            xa=int(e1.get())
            sql="select count(*)from service_center where id=%d"%(xa)
            cur.execute(sql)
            data=cur.fetchone()
            if data[0]==0:
                messagebox.showinfo('hii','ok go')
            else:
                 messagebox.showinfo('hii','already exit')
            db.close()
        l1=Label(c3,text='id',bg='pink',font=('arial',20))
        l1.place(x=150,y=60)
        e1=ttk.Combobox(c3)
        filldatac()
        e1['values']=cdi
        e1.place(x=450,y=60)
        l2=Label(c3,text='cname',bg='pink',font=('arial',20))
        l2.place(x=150,y=100)
        e2=Entry(c3,width=20,)
        e2.place(x=450,y=100)
        l3=Label(c3,text='address',bg='pink',font=('arial',20))
        l3.place(x=150,y=140)
        e3=Entry(c3,width=20,)
        e3.place(x=450,y=140)
        l4=Label(c3,text='email',bg='pink',font=('arial',20))
        l4.place(x=150,y=180)
        e4=Entry(c3,width=20,)
        e4.place(x=450,y=180)
        l5=Label(c3,text='phone',bg='pink',font=('arial',20))
        l5.place(x=150,y=220)
        e5=Entry(c3,width=20,)
        e5.place(x=450,y=220)
        l6=Label(c3,text='regno',bg='pink',font=('arial',20))
        l6.place(x=150,y=260)
        e6=Entry(c3,width=20,)
        e6.place(x=450,y=260)
        btn11=Button(c3,text='save',command=savedata,fg='white',bg='black',font=('arial',15))
        btn11.place(x=100,y=300)
        btn12=Button(c3,text='check',command=checkdata,fg='white',bg='black',font=('arial',15))
        btn12.place(x=300,y=300)
        btn13=Button(c3,text='close',command=dest,fg='white',bg='black',font=('arial',15))
        btn13.place(x=450,y=300)
        t.mainloop()
        
        
    def showdel():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        cdi=[]
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select id from service_center"
            cur.execute(sql)           
            data=cur.fetchall()
            for res in data:
                cdi.append(res[0])
            
       

        def deletedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = int(a1.get())
            sql = "delete from service_center where id=%d" % (xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'deleted')
            db.close()
            a1.delete(0, 100)
        l6 = Label(c3, text='service center details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=10)
        a = Label(c3, text='Id',font=('arial',15,'bold'),bg='lightblue')
        a.place(x=150, y=100)
        
        #a1 = Entry(t, width=20,font=('arial',10))
       # a1.place(x=300, y=100)
        a1 = ttk.Combobox(c3)
        filldata()
        a1['values'] = cdi
        a1.place(x=300, y=100)
       
        b = Button(c3, text='Delete', bg='blue',font=('arial',15), command=deletedata)
        b.place(x=200, y=200)


    
    def showfind():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)

        lt = []
        def dest():
            t.destroy()

        # combobox function
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "Select id from service_center"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        # find data using billno as primary key
        def finddata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = int(e1.get())
            # delete previous data find before
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)

            sql = "Select cname,address,email,phone,regno from service_center where id=%d" % (xa)
            cur.execute(sql)
            # fetchone to get data using index positions
            data = cur.fetchone()
            e2.insert(0, data[0])
            e3.insert(0, data[1])
            e4.insert(0, data[2])
            e5.insert(0, data[3])
            e6.insert(0, data[4])
            db.close()
        l6 = Label(c3, text='service center details',bg='lightblue', font=('arial',30,'bold'))
        l6.place(x=200, y=7)

        l1 = Label(c3, text='Id',bg='lightblue',font=('arial',20,'bold'))
        l1.place(x=100, y=70)
        
        

        b1 = Button(c3, text='Find',font=('arial',15,'bold'), bg='blue', command=finddata)
        b1.place(x=200, y=110)

        e1 = ttk.Combobox(c3,font=('arial',13))
        # call function filldata below
        filldata()
        e1['values'] = lt
        e1.place(x=300, y=70)

        l2 = Label(c3, text='C Name',bg='lightblue',font=('arial',20,'bold'))
        l2.place(x=100, y=150)

        e2 = Entry(c3, width=30,font=('arial',15))
        e2.place(x=300, y=150)

        l3 = Label(c3, text='Address',bg='lightblue',font=('arial',20,'bold'))
        l3.place(x=100, y=200)

        e3 = Entry(c3, width=30,font=('arial',15))
        e3.place(x=300, y=210)

        l4 = Label(c3, text='Email',font=('arial',20,'bold'),bg='lightblue')
        l4.place(x=100, y=250)

        e4 = Entry(c3, width=30,font=('arial',15))
        e4.place(x=300, y=260)

        l5 = Label(c3, text='Phone',font=('arial',20,'bold'))
        l5.place(x=100, y=300)

        e5 = Entry(c3, width=30,font=('arial',15))
        e5.place(x=300, y=310)

        l6 = Label(c3, text='Reg No',font=('arial',20,'bold'))
        l6.place(x=100, y=350)

        e6 = Entry(c3, width=30,font=('arial',15))
        e6.place(x=300, y=360)
        b3=Button(c3,text='close',bg='blue',command=dest,font=('arial',15))
        b3.place(x=150,y=420)
    def showdatashow():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)

        recd=''
        
        
        def showdata():
            recd=''
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select * from service_center"
            cur.execute(sql)
            l6 = Label(c3, text='service center details', font=('arial', 20,'bold'),bg='lightblue')
            l6.place(x=200, y=10)
            data = cur.fetchall()
            for res in data:
                recd = recd+'\t'+str(res[0])
                recd = recd+'\t'+(res[1])
                recd = recd+'\t'+(res[2])
                recd = recd+'\t'+(res[3])
                recd = recd+'\t'+str(res[4])
                recd = recd+'\t'+str(res[5])
                recd = recd+'\n'
                return recd
            db.close()

        e = Text(c3, width=150, height=50,font=('arial',15))
        showdata()
        e.insert(tkinter.END, recd)
        e.place(x=10, y=70)
    def showupdate():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)

        lt = []
        def dest():
            t.destroy()

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select id from service_center"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        def updatedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = int(a1.get())
            xb = b1.get()
            xc = d1.get()
            xd = f1.get()
            xe = h1.get()
            xf = s1.get()
            sql = "update service_center set cname='%s',address='%s',email='%s',phone='%s',reg='%s' where id=%d" % (xb, xc, xd, xe, xf, xa)

            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'update done')
            a1.delete(0, 100)

            b1.delete(0, data[0])
            d1.delete(0, data[1])
            f1.delete(0, data[2])
            h1.delete(0, data[3])
            s1.delete(0, data[4])

        l6 = Label(c3, text='service center details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=7)
        a = Label(c3, text='Id',font=('arial',20,'bold'),bg='lightblue')
        a.place(x=100, y=60)
        a1 = ttk.Combobox(c3)
        filldata()
        a1['values'] = lt
        a1.place(x=300, y=60)

        b = Label(c3, text='C Name',font=('arial',20,'bold'),bg='lightblue')
        b.place(x=100, y=100)
        b1 = Entry(c3, width=30,font=('arial',15))
        b1.place(x=300, y=100)
        d = Label(c3, text='Address',font=('arial',20,'bold'),bg='lightblue')
        d.place(x=100, y=140)
        d1 = Entry(c3, width=30,font=('arial',15))
        d1.place(x=300, y=140)
        f = Label(c3, text='Email',font=('arial',20,'bold'),bg='lightblue')
        f.place(x=100, y=180)
        f1 = Entry(c3, width=30,font=('arial',15))
        f1.place(x=300, y=180)
        h = Label(c3, text='Phone',font=('arial',20,'bold'),bg='lightblue')
        h.place(x=100, y=220)
        h1 = Entry(c3, width=30,font=('arial',15))
        h1.place(x=300, y=220)
        s = Label(c3, text='Reg No',font=('arial',20,'bold'),bg='lightblue')
        s.place(x=100, y=260)
        s1 = Entry(c3, width=30,font=('arial',15))
        s1.place(x=300, y=260)
        p = Button(c3, text='update',font=('arial',15), bg='blue', command=updatedata)
        p.place(x=400, y=310)
        p = Button(c3, text='close',font=('arial',15), bg='blue', command=dest)
        p.place(x=500, y=310)
    def shownavigate():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)

        def dest():
            t.destroy()
        xa = []
        xb = []
        xc = []
        xd = []
        xe = []
        xf = []
        i = 0

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select*from service_center"
            cur.execute(sql)
            l6 = Label(c3, text='service center details', font=('arial', 20,'bold'),bg='lightblue')
            l6.place(x=150, y=3)
            data = cur.fetchall()
            for res in data:
                xa.append(res[0])
                xb.append(res[1])
                xc.append(res[2])
                xd.append(res[3])
                xe.append(res[4])
                xf.append(res[5])
            db.close()

        def first():
            global i
            i = 0
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e1.insert(0, str(xa[i]))
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xf[i])

        def next():
            global i
            i = i+1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e1.insert(0, str(xa[i]))
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xe[i])

        def previous():
            global i
            i = i-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e1.insert(0, str(xa[i]))
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xf[i])

        def last():
            global i
            i = len(xa)-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e1.insert(0, str(xa[i]))
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xf[i])

        l1 = Label(c3, text='Id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=60)

        e1 = Entry(c3, width=40,font=('arial',10))
        e1.place(x=300, y=60)
        l2 = Label(c3, text='C Name',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=100)

        e2 = Entry(c3, width=40,font=('arial',10))
        e2.place(x=300, y=100)

        l3 = Label(c3, text='Address',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=140)
        e3 = Entry(c3, width=40,font=('arial',10))
        e3.place(x=300, y=140)

        l4 = Label(c3, text='Email',font=('arial',15,'bold'),bg='lightblue')
        l4.place(x=100, y=180)

        e4 = Entry(c3, width=40,font=('arial',10))
        e4.place(x=300, y=180)

        l5 = Label(c3, text='Phone',font=('arial',15,'bold'),bg='lightblue')
        l5.place(x=100, y=220)

        e5 = Entry(c3, width=40,font=('arial',10))
        e5.place(x=300, y=220)

        l6 = Label(c3, text='Reg No',font=('arial',15,'bold'),bg='lightblue')
        l6.place(x=100, y=260)

        e6 = Entry(c3, width=40,font=('arial',10))
        e6.place(x=300, y=260)

        b1 = Button(c3, text='First',font=('arial',15), bg='blue', command=first)
        b1.place(x=100, y=350)

        b2 = Button(c3, text='Next',font=('arial',15), bg='blue', command=next)
        b2.place(x=200, y=350)
        b3 = Button(c3, text='Previous',font=('arial',15), bg='blue', command=previous)
        b3.place(x=300, y=350)
        b4 = Button(c3, text='Last',font=('arial',15), bg='blue', command=last)
        b4.place(x=400, y=350)
        b4 = Button(c3, text='Close',font=('arial',15), bg='blue', command=dest)
        b4.place(x=500, y=350)
        filldata()
    b1=Button(a1,text='Insert',command=showins,font=('Arial',12,'bold'),width=14,bg='lightyellow')
    b1.place(x=35,y=75)
    b1=Button(a1,text='Update',command=showupdate,font=('Arial',12,'bold'),width=14,bg='lightyellow')
    b1.place(x=35,y=150)
    b1=Button(a1,text='Delete',command=showdel,font=('Arial',12,'bold'),width=14,bg='lightyellow')
    b1.place(x=35,y=225)
    b1=Button(a1,text='Find',command=showfind,font=('Arial',12,'bold'),width=14,bg='lightyellow')
    b1.place(x=35,y=300)
    b1=Button(a1,text='Show',command=showdatashow,font=('Arial',12,'bold'),width=14,bg='lightyellow')
    b1.place(x=35,y=375)
    b1=Button(a1,text='Navigate',command=shownavigate,font=('Arial',12,'bold'),width=14,bg='lightyellow')
    b1.place(x=35,y=450)
def showproductcategory():
    def showins():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        def dest():
            t.destroy()
            
        def savedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            xa=e1.get()
            xb=e2.get()
            xc=e3.get()
            sql="select*from product_category where prodcatid='%s'"%(xa)
            cur.execute(sql)
            data=cur.fetchall()
            if data:
                messagebox.showerror("error","data already exist")
            elif  len(e1.get())==0 or  len(e2.get())==0 or len(e3.get())==0:
                messagebox.showerror('Invalid','invalid details')
            
           
                
            else:
                    db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
                    cur=db.cursor()
                    xa=e1.get()
                    xb=e2.get()
                    xc=e3.get()
                    
            
                    
                    sql="insert into product_category values('%s','%s','%s')"%(xa,xb,xc)
                    cur.execute(sql)
                    db.commit()
                    messagebox.showinfo('hi','saved')
                    db.close()
                    e1.delete(0,100)
                    e2.delete(0,100)
                    e3.delete(0,100)
            
        
            db.close()
        
       
            
           
        # code for db connectivity button

       

        l6 = Label(c3, text='product category details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=7)
        l1 = Label(c3, text='Prodcat Id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=60)

        e1 = Entry(c3, width=30,font=('arial',10)
                   )
        e1.place(x=300, y=60)
        
        l2 = Label(c3, text='Cat Name',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=100)

        e2 = Entry(c3, width=30,font=('arial',10))
        e2.place(x=300, y=100)

        l3 = Label(c3, text='Description',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=140)

        e3 = Entry(c3, width=30,font=('arial',10))
        e3.place(x=300, y=140)

        b1 = Button(c3, text='Save',font=('arial',15,'bold'), bg='blue', command=savedata)
        b1.place(x=100, y=200)

        b2 = Button(c3, text='Close',font=('arial',15,'bold'), bg='blue',command=dest)
        b2.place(x=200, y=200)
        
        b3 = Button(c3, text='check',font=('arial',15,'bold'), bg='blue',command=checkdata)
        b3.place(x=300, y=200)
    def showdel():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        cdi=[]
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select prodcatid from product_category"
        
            
            cur.execute(sql)           
            data=cur.fetchall()
            for res in data:
                cdi.append(res[0])
       

        def deletedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()
            sql = "delete from product_category where prodcatid='%s'" % (xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'deleted')
            db.close()
            a1.delete(0, 100)
        l6 = Label(c3, text='product category details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=15)
        a = Label(c3, text='Prodcat Id',font=('arial',15,'bold'),bg='lightblue')
        a.place(x=150, y=100)
        #a1 = Entry(c3, width=20,font=('arial',10))
        #a1.place(x=300, y=100)
        a1 = ttk.Combobox(c3)
        filldata()
        a1['values'] = cdi
        a1.place(x=300, y=100)
        b = Button(c3, text='Delete',font=('arial',15), bg='blue', command=deletedata)
        b.place(x=170, y=170)
    def showfind():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        def dest():
            t.destroy()
        lt = []

        # combobox function
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "Select prodcatid from product_category"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        
        def finddata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = e1.get()
            # delete previous data find before
            e2.delete(0, 100)
            e3.delete(0, 100)

            sql = "Select catname,description from product_category where prodcatid='%s'" % (xa)
            cur.execute(sql)
            # fetchone to get data using index positions
            data = cur.fetchone()
            e2.insert(0, data[0])
            e3.insert(0, data[1])

            db.close()
        l6 = Label(c3, text='product category details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=7)

        l1 = Label(c3, text='Prodcat Id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=60)

        b1 = Button(c3, text='Find',font=('arial',15,), bg='blue', command=finddata)
        b1.place(x=200, y=90)

        e1 = ttk.Combobox(c3,font=('arial',10),width=28)
        # call function filldata below
        filldata()
        e1['values'] = lt
        e1.place(x=300, y=60)

        l2 = Label(c3, text='Cat Name',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=140)

        e2 = Entry(c3, width=30,font=('arial',10))
        e2.place(x=300, y=140)

        l3 = Label(c3, text='Description',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=190)

        e3 = Entry(c3, width=30,font=('arial',10))
        e3.place(x=300, y=190)
        
        b6 = Button(c3, text='close',font=('arial',15,), bg='blue', command=dest)
        b6.place(x=200, y=230)
    def showdatashow():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        recd=''

        def showdata():
            recd=''
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select * from product_category"
            cur.execute(sql)
            l6 = Label(c3, text='product category details', font=('arial', 20,'bold'),bg='lightblue')
            l6.place(x=200, y=10)
            data = cur.fetchall()
            for res in data:
                recd = recd+'\t'+(res[0])
                recd = recd+'\t'+(res[1])
                recd = recd+'\t'+(res[2])

                recd = recd+'\n'
            db.close()

        e = Text(c3, width=150, height=50,font=('arial',15))
        showdata()
        e.insert(tkinter.END, recd)
        e.place(x=10, y=70)

        
    def showupdate():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        def dest():
            t.destroy()
        lt = []

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select prodcatid from product_category"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        def updatedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()
            xb = b1.get()
            xc = d1.get()

            sql = "update product_category set catname='%s',description='%s' where prodcatid='%s'" % (xb, xc, xa)

            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'update done')
            a1.delete(0, 100)

            b1.delete(0, data[0])
            d1.delete(0, data[1])

        l6 = Label(c3, text='product category details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=7)
        a = Label(c3, text='Prodcat Id',font=('arial',15,'bold'),bg='lightblue')
        a.place(x=100, y=60)
        a1 = ttk.Combobox(c3,font=('arial',13),width=34)
        filldata()
        a1['values'] = lt
        a1.place(x=300, y=60)

        b = Label(c3, text='Cat Name',font=('arial',15,'bold'),bg='lightblue')
        b.place(x=100, y=100)
        b1 = Entry(c3, width=30,font=('arial',10))
        b1.place(x=300, y=100)
        d = Label(c3, text='Description',font=('arial',15,'bold'),bg='lightblue')
        d.place(x=100, y=140)
        d1 = Entry(c3, width=30,font=('arial',10))
        d1.place(x=300, y=140)

        p = Button(c3, text='update',font=('arial',15), bg='blue', command=updatedata)
        p.place(x=150, y=200)
        
        p1 = Button(c3, text='close',font=('arial',15), bg='blue', command=dest)
        p1.place(x=250, y=200)
    def shownavigate():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        def dest():
            t.destroy()
        xa = []
        xb = []
        xc = []
        i = 0

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select*from product_category"
            cur.execute(sql)
            l6 = Label(c3, text='product category Details', font=('arial', 20,'bold'),bg='lightblue')
            l6.place(x=150, y=20)
            data = cur.fetchall()
            for res in data:
                xa.append(res[0])
                xb.append(res[1])
                xc.append(res[2])

            db.close()

        def first():
            global i
            i = 0
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)

            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])

        def next():
            global i
            i = i+1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)

            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])

        def previous():
            global i
            i = i-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)

            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])

        def last():
            global i
            i = len(xa)-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)

            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])

        l1 = Label(c3, text='Prodcat Id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=100)

        e1 = Entry(c3, width=30,font=('arial',10))
        e1.place(x=300, y=100)

        l2 = Label(c3, text='Cat Name',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=150)

        e2 = Entry(c3, width=30,font=('arial',10))
        e2.place(x=300, y=150)

        l3 = Label(c3, text='Description',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=200)

        e3 = Entry(c3, width=30,font=('arial',10))
        e3.place(x=300, y=200)

        b1 = Button(c3, text='First',font=('arial',15), bg='blue', command=first)
        b1.place(x=100, y=300)

        b2 = Button(c3, text='Next',font=('arial',15), bg='blue', command=next)
        b2.place(x=200, y=300)
        b3 = Button(c3, text='Previous',font=('arial',15), bg='blue', command=previous)
        b3.place(x=300, y=300)
        b4 = Button(c3, text='Last',font=('arial',15), bg='blue', command=last)
        b4.place(x=450, y=300)
        b5 = Button(c3, text='Close',font=('arial',15), bg='blue', command=dest)
        b5.place(x=550, y=300)
        filldata()
    b1=Button(a1,text='Insert',command=showins,font=('Arial',12,'bold'),width=14,bg='pink')
    b1.place(x=35,y=75)
    b1=Button(a1,text='Update',command=showupdate,font=('Arial',12,'bold'),width=14,bg='pink')
    b1.place(x=35,y=150)
    b1=Button(a1,text='Delete',command=showdel,font=('Arial',12,'bold'),width=14,bg='pink')
    b1.place(x=35,y=225)
    b1=Button(a1,text='Find',command=showfind,font=('Arial',12,'bold'),width=14,bg='pink')
    b1.place(x=35,y=300)
    b1=Button(a1,text='Show',command=showdatashow,font=('Arial',12,'bold'),width=14,bg='pink')
    b1.place(x=35,y=375)
    b1=Button(a1,text='Navigate',command=shownavigate,font=('Arial',12,'bold'),width=14,bg='pink')
    b1.place(x=35,y=450)
def showservicetype():
    def showins():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        def dest():
            t.destroy()
        
        cdi=[]
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select * from product_category"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                cdi.append(res[0])
            #messagebox.showinfo('hi','inserted')
            
        def savedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            xa=e1.get()
            xb=e2.get()
            xc=e3.get()
            xd=int(e4.get())
            xe=e5.get()
            sql="select * from servicetypes where prodcatid='%s'"%(xb)
            cur.execute(sql)
            data=cur.fetchone()
            if data:
                messagebox.showerror('Invalid','Data Already Exist   ')
            
            else:
                if xa=='' or xb== ''or xc=='' or xe=='':
                    messagebox.showerror('Invalid','Invalid detail')
                
                else:
                    if xd<100:
                        messagebox.showerror("Invalid Entry","Charge can't less 100")
                    else:    
                        sql="insert into servicetype values('%s','%s','%s','%d','%s')" %(xa,xb,xc,xd,xe)
                        cur.execute(sql)
                        db.commit()
                        db.close()
                        messagebox.showinfo('save','Data successfully save')
                        e1.delete(0,100)
                        e2.delete(0,100)
                        e3.delete(0,100)
                        e4.delete(0,100)
                        e5.delete(0,100)
        l6 = Label(c3, text='service type details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=7)
        l1 = Label(c3, text='Service Id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=60)

        e1 = Entry(c3, width=30,font=('arial',15))
        e1.place(x=300, y=60)
        

        l2 = Label(c3, text='Prodcat Id',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=100)
       

        #e2 = Entry(c3, width=30,bg='lightgreen',font=('arial',15))
        #e2.place(x=300, y=100)
        e2=ttk.Combobox(c3,font=('arial',13),width=34)
        filldata()
        e2['values']=cdi
        e2.place(x=300,y=100)

        l3 = Label(c3, text='Service Name',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=140)

        e3 = Entry(c3, width=30,font=('arial',15))
        e3.place(x=300, y=140)

        l4 = Label(c3, text='Charges',font=('arial',15,'bold'),bg='lightblue')
        l4.place(x=100, y=180)

        e4 = Entry(c3, width=30,font=('arial',15))
        e4.place(x=300, y=180)

        l5 = Label(c3, text='Time to solve',font=('arial',15,'bold'),bg='lightblue')
        l5.place(x=100, y=220)

        e5 = Entry(c3, width=30,font=('arial',15))
        e5.place(x=300, y=220)

        b1 = Button(c3, text='Save',font=('arial',15,'bold'), bg='blue', command=savedata)
        b1.place(x=100, y=300)

        b2 = Button(c3, text='Close',font=('arial',15,'bold'), bg='blue',command=dest)
        b2.place(x=300, y=300)
        
       # b4 = Button(c3, text='check',font=('arial',15,'bold'), bg='blue',command=checkdata)
       # b4.place(x=400, y=300)
    def showdel():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        cdi=[]
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select serviceid from servicetypes"
        
            
            cur.execute(sql)           
            data=cur.fetchall()
            for res in data:
                cdi.append(res[0])
       

        def deletedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()

            sql = "delete from servicetypes where serviceid='%s'" % (xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'deleted')
            db.close()
            a1.delete(0, 100)
        l6 = Label(c3, text='service type details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=10)
        a = Label(c3, text='Service Id',font=('arial',15,'bold'),bg='lightblue')
        a.place(x=150, y=60)
        #a1 = Entry(t, width=20,font=('arial',15))
        #a1.place(x=300, y=60)
        a1 = ttk.Combobox(c3)
        filldata()
        a1['values'] = cdi
        a1.place(x=300, y=60)
        b = Button(c3, text='Delete',font=('arial',15,'bold'), bg='blue', command=deletedata)
        b.place(x=250, y=100)

    
    def showfind():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        def dest():
            t.destroy()
        lt = []

        # combobox function
        def filldata():
            db = pymysql.connect(host='localhost', user='root', password='root', database='scm')
            cur = db.cursor()
            sql = "Select serviceid from servicetypes"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        
        def finddata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = e1.get()
            # delete previous data find before
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            sql = "Select prodcatid,sname,charges,timetosolve from servicetypes where serviceid='%s'" % (xa)
            cur.execute(sql)
            # fetchone to get data using index positions
            data = cur.fetchone()
            e2.insert(0, data[0])
            e3.insert(0, data[1])
            e4.insert(0, data[2])
            e5.insert(0, data[3])

            db.close()
        l6 = Label(c3, text='service type details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=250, y=7)

        l1 = Label(c3, text='Service Id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=60)

        b1 = Button(c3, text='Find',font=('arial',15,'bold'), bg='blue', command=finddata)
        b1.place(x=230, y=90)

        e1 = ttk.Combobox(c3,font=('arial',13),width=34)
        # call function filldata below
        filldata()
        e1['values'] = lt
        e1.place(x=300, y=60)

        l2 = Label(c3, text='Prodcat Id',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=120)

        e2 = Entry(c3, width=30,font=('arial',15))
        e2.place(x=300, y=120)

        l3 = Label(c3, text='Service Name',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=180)

        e3 = Entry(c3, width=30,font=('arial',15))
        e3.place(x=300, y=180)

        l4 = Label(c3, text='Charges',font=('arial',15,'bold'),bg='lightblue')
        l4.place(x=100, y=240)

        e4 = Entry(c3, width=30,font=('arial',15))
        e4.place(x=300, y=240)

        l5 = Label(c3, text='Time to solve',font=('arial',15,'bold'),bg='lightblue')
        l5.place(x=100, y=300)

        e5 = Entry(c3, width=30,font=('arial',15))
        e5.place(x=300, y=300)
        
        b2 = Button(c3, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b2.place(x=230, y=360)
    def showdatashow():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        recd=''

        def showdata():
            recd=''
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select * from servicetypes"
            cur.execute(sql)
            l6 = Label(c3, text='service type details', font=('arial', 20,'bold'),bg='lightblue')
            l6.place(x=200, y=10)
            data = cur.fetchall()
            for res in data:
                recd = recd+'\t'+(res[0])
                recd = recd+'\t'+(res[1])
                recd = recd+'\t'+(res[2])
                recd = recd+'\t'+str(res[3])
                recd = recd+'\t'+(res[4])

                recd = recd+'\n'
            db.close()

        e = Text(c3, width=150, height=50,font=('arial',15))
        showdata()
        e.insert(tkinter.END, recd)
        e.place(x=10, y=70)
    def showupdate():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        def dest():
            t.destroy()
        lt = []

        def filldata():
            db = pymysql.connect(host='localhost', user='root', password='root', database='scm')
            cur = db.cursor()
            sql = "select serviceid from servicetypes"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        def updatedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = (a1.get())
            xb = b1.get()
            xc = d1.get()
            xd = int(f1.get())
            xe = h1.get()

            sql = "update servicetypes set prodcatid='%s',sname='%s',charges=%d,timetosolve='%s' where serviceid='%s'" % (xb, xc, xd, xe, xa)

            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'update done')
            a1.delete(0, 100)

            b1.delete(0, data[0])
            d1.delete(0, data[1])
            f1.delete(0, data[2])
            h1.delete(0, data[3])

        l6 = Label(c3, text='service type details', font=('arial', 20),bg='lightblue')
        l6.place(x=200, y=7)
        a = Label(c3, text='Service Id',font=('arial',15,'bold'),bg='lightblue')
        a.place(x=100, y=60)
        a1 = ttk.Combobox(c3,font=('arial',13),width=34)
        filldata()
        a1['values'] = lt
        a1.place(x=300, y=60)

        b = Label(c3, text='Prodcat Id',font=('arial',15,'bold'),bg='lightblue')
        b.place(x=100, y=100)
        b1 = Entry(c3, width=30,font=('arial',15))
        b1.place(x=300, y=100)
        d = Label(c3, text='Service Name',font=('arial',15,'bold'),bg='lightblue')
        d.place(x=100, y=140)
        d1 = Entry(c3, width=30,font=('arial',15))
        d1.place(x=300, y=140)
        f = Label(c3, text='Charges',font=('arial',15,'bold'),bg='lightblue')
        f.place(x=100, y=180)
        f1 = Entry(c3, width=30,font=('arial',15))
        f1.place(x=300, y=180)
        h = Label(c3, text='Time to solve',font=('arial',15,'bold'),bg='lightblue')
        h.place(x=100, y=220)
        h1 = Entry(c3, width=30,font=('arial',15))
        h1.place(x=300, y=220)

        p = Button(c3, text='update',font=('arial',15,'bold'), bg='blue', command=updatedata)
        p.place(x=150, y=300)
        
        p1 = Button(c3, text='close',font=('arial',15,'bold'), bg='blue', command=dest)
        p1.place(x=250, y=300)
    def shownavigate():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        def dest():
            t.destroy()
        xa = []
        xb = []
        xc = []
        xd = []
        xe = []

        i = 0

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select*from servicetypes"
            cur.execute(sql)
            l6 = Label(c3, text='service type details', font=('arial', 20,'bold'),bg='lightblue')
            l6.place(x=150, y=4)
            data = cur.fetchall()
            for res in data:
                xa.append(res[0])
                xb.append(res[1])
                xc.append(res[2])
                xd.append(res[3])
                xe.append(res[4])

            db.close()

        def first():
            global i
            i = 0
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, str(xd[i]))
            e5.insert(0, xe[i])

        def next():
            global i
            i = i+1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, str(xd[i]))
            e5.insert(0, xe[i])

        def previous():
            global i
            i = i-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, str(xd[i]))
            e5.insert(0, xe[i])

        def last():
            global i
            i = len(xa)-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, str(xd[i]))
            e5.insert(0, xe[i])

        l1 = Label(c3, text='Service Id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=60)

        e1 = Entry(c3, width=30,font=('arial',15))
        e1.place(x=300, y=60)
        l2 = Label(c3, text='Prodcat Id',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=100)

        e2 = Entry(c3, width=30,font=('arial',15))
        e2.place(x=300, y=100)

        l3 = Label(c3, text='Service Name',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=140)
        e3 = Entry(c3, width=30,font=('arial',15))
        e3.place(x=300, y=140)

        l4 = Label(c3, text='Charges',font=('arial',15,'bold'),bg='lightblue')
        l4.place(x=100, y=180)

        e4 = Entry(c3, width=30,font=('arial',15))
        e4.place(x=300, y=180)

        l5 = Label(c3, text='Time to solve',font=('arial',15,'bold'),bg='lightblue')
        l5.place(x=100, y=220)

        e5 = Entry(c3, width=30,font=('arial',15))
        e5.place(x=300, y=220)

        b1 = Button(c3, text='First',font=('arial',15,'bold'), bg='blue', command=first)
        b1.place(x=100, y=300)

        b2 = Button(c3, text='Next',font=('arial',15,'bold'), bg='blue', command=next)
        b2.place(x=200, y=300)
        b3 = Button(c3, text='Previous',font=('arial',15,'bold'), bg='blue', command=previous)
        b3.place(x=300, y=300)
        b4 = Button(c3, text='Last',font=('arial',15,'bold'), bg='blue', command=last)
        b4.place(x=450, y=300)
        b5 = Button(c3, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b5.place(x=550, y=300)
        filldata()
    b1=Button(a1,text='Insert',command=showins,font=('Arial',12,'bold'),width=14,bg='cyan')
    b1.place(x=35,y=75)
    b1=Button(a1,text='Update',command=showupdate,font=('Arial',12,'bold'),width=14,bg='cyan')
    b1.place(x=35,y=150)
    b1=Button(a1,text='Delete',command=showdel,font=('Arial',12,'bold'),width=14,bg='cyan')
    b1.place(x=35,y=225)
    b1=Button(a1,text='Find',command=showfind,font=('Arial',12,'bold'),width=14,bg='cyan')
    b1.place(x=35,y=300)
    b1=Button(a1,text='Show',command=showdatashow,font=('Arial',12,'bold'),width=14,bg='cyan')
    b1.place(x=35,y=375)
    b1=Button(a1,text='Navigate',command=shownavigate,font=('Arial',12,'bold'),width=14,bg='cyan')
    b1.place(x=35,y=450)
def showengineers():
    def showins():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
       
        cdi=[] 
        def dest():
            cdi.clear()
            t.destroy()
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select prodcatid from product_category"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
                cur=db.cursor()
                xa=e1.get()
                sql="select count(*)from engineers where engid='%s'"%(xa)
                cur.execute(sql)
                dta=cur.fetchall()
                if data[0]==0:
                    messagebox.showinfo('hii','ok go')
                else:
                
                 cdi.append(res[0])
            db.close()
        def savedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            xa=e1.get()
            sql="select count(*) from engineers where engid='%s'"%(xa)
            cur.execute(sql)
            data=cur.fetchall()
            if (e1.get())==0 or  (e2.get())==0 or (e3.get())==0 or (e4.get())==0 or (e5.get())==0  or (e7.get())==0:
                messagebox.showerror('Error','Invalid')
            elif data:
                    messagebox.showerror('Invalid','Invalid  details')
            else:
                db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
                cur=db.cursor()
                xa=e1.get()
                xb=e2.get()
                xc=e3.get()
                xd=e4.get()
                xe=e5.get()
                xf=e6.get()
                xg=e7.get()
        
                
                sql="insert into engineers values('%s','%s','%s','%s','%s','%s','%s')"%(xa,xb,xc,xd,xe,xf,xg)
                cur.execute(sql)
                db.commit()
                messagebox.showinfo('hi','saved')
                db.close()
                e1.delete(0,100)
                e2.delete(0,100)
                e3.delete(0,100)
                e4.delete(0,100)
                e5.delete(0,100)
                e6.delete(0,100)
                e7.delete(0,100)
        
        
       
        

        l6 = Label(c3, text='engineer Details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=7)
        l1 = Label(c3, text='Engineer id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=60)

        e1 = Entry(c3, width=30,font=('arial',15))
        e1.place(x=300, y=60)
        

        l2 = Label(c3, text='Engineer Name',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=100)

        e2 = Entry(c3, width=30,font=('arial',15))
        e2.place(x=300, y=100)

        l3 = Label(c3, text='Address',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=140)

        e3 = Entry(c3, width=30,font=('arial',15))
        e3.place(x=300, y=140)

        l4 = Label(c3, text='Phone',font=('arial',15,'bold'),bg='lightblue')
        l4.place(x=100, y=180)

        e4 = Entry(c3, width=30,font=('arial',15))
        e4.place(x=300, y=180)

        l5 = Label(c3, text='Email',font=('arial',15,'bold'),bg='lightblue')
        l5.place(x=100, y=220)

        e5 = Entry(c3, width=30,font=('arial',15))
        e5.place(x=300, y=220)

        l6 = Label(c3, text='Prodcat id',font=('arial',15,'bold'),bg='lightblue')
        l6.place(x=100, y=260)

        #e6 = Entry(t, width=30,bg='lightgreen',font=('arial',15))
        #e6.place(x=300, y=260)
        e6=ttk.Combobox(c3,font=('arial',13),width=34)
        filldata()
        e6['values']=cdi
        e6.place(x=300,y=260)

        l7 = Label(c3, text='Status',font=('arial',15,'bold'),bg='lightblue')
        l7.place(x=100, y=300)

        e7 = Entry(c3, width=30,font=('arial',15))
        e7.place(x=300, y=300)

        b1 = Button(c3, text='Save',font=('arial',15,'bold'), bg='blue', command=savedata)
        b1.place(x=100, y=350)

        b2 = Button(c3, text='Close',font=('arial',15,'bold'), bg='blue',command=dest)
        b2.place(x=200, y=350)
        
        #b3 = Button(t,text='Check',font=('arial',15,'bold'), bg='blue',command=checkdata)
        #b3.place(x=300, y=350)
    def showdel():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        cdi=[]
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select engid from engineers"
        
            
            cur.execute(sql)           
            data=cur.fetchall()
            for res in data:
                cdi.append(res[0])
       

        def deletedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()

            sql = "delete from engineers where engid='%s'" % (xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'deleted')
            db.close()
            a1.delete(0, 100)
        l6 = Label(c3, text='engineer details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=10)
        a = Label(c3, text='Engineer id',font=('arial',15,'bold'),bg='lightblue')
        a.place(x=150, y=60)
        #a1 = Entry(t, width=20,font=('arial',15))
        #a1.place(x=300, y=60)
        a1 = ttk.Combobox(c3)
        filldata()
        a1['values'] = cdi
        a1.place(x=300, y=60)
        b = Button(c3, text='Delete',font=('arial',15,'bold'), bg='blue', command=deletedata)
        b.place(x=170, y=100)
    def showfind():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        def dest():
            t.destroy()
        
        lt = []

        # combobox function
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "Select engid from engineers"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()
        def finddata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = e1.get()
            # delete previous data find before
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e7.delete(0, 100)

            sql = "Select ename,address,phone,email,prodcatid,status from engineers where engid='%s'" % (xa)
            cur.execute(sql)
            # fetchone to get data using index positions
            data = cur.fetchone()
            e2.insert(0, data[0])
            e3.insert(0, data[1])
            e4.insert(0, data[2])
            e5.insert(0, data[3])
            e6.insert(0, data[4])
            e7.insert(0, data[5])

            db.close()
        l6 = Label(c3, text='engineer details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=7)

        l1 = Label(c3, text='Engineer id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=60)

        b1 = Button(c3, text='Find',font=('arial',15,'bold'), bg='blue', command=finddata)
        b1.place(x=200, y=90)

        e1 = ttk.Combobox(c3,font=('arial',13),width=34)
        # call function filldata below
        filldata()
        e1['values'] = lt
        e1.place(x=300, y=60)

        l2 = Label(c3, text='Engineer Name',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=140)

        e2 = Entry(c3, width=30,font=('arial',15))
        e2.place(x=300, y=140)

        l3 = Label(c3, text='Address',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=180)

        e3 = Entry(c3, width=30,font=('arial',15))
        e3.place(x=300, y=180)

        l4 = Label(c3, text='Phone',font=('arial',15,'bold'),bg='lightblue')
        l4.place(x=100, y=220)

        e4 = Entry(c3, width=30,font=('arial',15))
        e4.place(x=300, y=220)

        l5 = Label(c3, text='Email',font=('arial',15,'bold'),bg='lightblue')
        l5.place(x=100, y=260)

        e5 = Entry(c3, width=30,font=('arial',15))
        e5.place(x=300, y=260)

        l6 = Label(c3, text='Prodcat id',font=('arial',15,'bold'),bg='lightblue')
        l6.place(x=100, y=300)

        e6 = Entry(c3, width=30,font=('arial',15))
        e6.place(x=300, y=300)

        l7 = Label(c3, text='Status',font=('arial',15,'bold'),bg='lightblue')
        l7.place(x=100, y=340)

        e7 = Entry(c3, width=30,font=('arial',15))
        e7.place(x=300, y=340)
        
        b3 = Button(c3, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b3.place(x=200, y=380)
    def showdatashow():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        recd=''
        def showdata():
            recd=''
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select * from engineers"
            cur.execute(sql)
            l6 = Label(c3, text='engineer details', font=('arial', 30,'bold'),bg='lightblue')
            l6.place(x=200, y=10)
            data = cur.fetchall()
            for res in data:
                recd = recd+'\t'+(res[0])
                recd = recd+'\t'+(res[1])
                recd = recd+'\t'+(res[2])
                recd = recd+'\t'+(res[3])
                recd = recd+'\t'+(res[4])
                recd = recd+'\t'+(res[5])
                recd = recd+'\t'+(res[6])

                recd = recd+'\n'
            db.close()

        e = Text(c3, width=150, height=50,font=('arial',15))
        showdata()
        e.insert(tkinter.END, recd)
        e.place(x=10, y=70)
    def showupdate():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        def dest():
            t.destroy()
        lt = []

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select engid from engineers"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        def updatedata():
            db = pymysql.connect(host='localhost', user='root', password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()
            xb = b1.get()
            xc = d1.get()
            xd = f1.get()
            xe = h1.get()
            xf = g1.get()
            xg = s1.get()

            sql = "update engineers set ename='%s',address='%s',phone='%s',email='%s',prodcatid='%s',status='%s' where engid='%s'" % (xb, xc, xd, xe, xf, xg, xa)

            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'update done')
            a1.delete(0, 100)

            b1.delete(0, data[0])
            d1.delete(0, data[1])
            f1.delete(0, data[2])
            h1.delete(0, data[3])
            g1.delete(0, data[4])
            s1.delete(0, data[5])

        l6 = Label(c3, text='engineer details', font=('arial', 20,'bold'),bg='lightblue')
        l6.place(x=200, y=7)
        a = Label(c3, text='Engineer id',font=('arial',15,'bold'),bg='lightblue')
        a.place(x=100, y=60)
        a1 = ttk.Combobox(c3,font=('arial',13))
        filldata()
        a1['values'] = lt
        a1.place(x=300, y=60)

        b = Label(c3, text='Engineer Name',font=('arial',15,'bold'),bg='lightblue')
        b.place(x=100, y=100)
        b1 = Entry(c3, width=30,font=('arial',15))
        b1.place(x=300, y=100)
        d = Label(c3, text='Address',font=('arial',15,'bold'),bg='lightblue')
        d.place(x=100, y=140)
        d1 = Entry(c3, width=30,font=('arial',15))
        d1.place(x=300, y=140)
        f = Label(c3, text='Phone',font=('arial',15,'bold'),bg='lightblue')
        f.place(x=100, y=180)
        f1 = Entry(c3, width=30,font=('arial',15))
        f1.place(x=300, y=180)
        h = Label(c3, text='Email',font=('arial',15,'bold'),bg='lightblue')
        h.place(x=100, y=220)
        h1 = Entry(c3, width=30,font=('arial',15))
        h1.place(x=300, y=220)
        g = Label(c3, text='Prodcat id',font=('arial',15,'bold'),bg='lightblue')
        g.place(x=100, y=260)
        g1 = Entry(c3, width=30,font=('arial',15))
        g1.place(x=300, y=260)
        s = Label(c3, text='Status',font=('arial',15,'bold'),bg='lightblue')
        s.place(x=100, y=300)
        s1 = Entry(c3, width=30,font=('arial',15))
        s1.place(x=300, y=300)
        b = Button(c3, text='update',font=('arial',15,'bold'), bg='blue', command=updatedata)
        b.place(x=350, y=350)
        b1 = Button(c3, text='close',font=('arial',15,'bold'), bg='blue', command=dest)
        b1.place(x=450, y=350)
    def shownavigate():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        def dest():
            t.destroy()
        xa = []
        xb = []
        xc = []
        xd = []
        xe = []
        xf = []
        xg = []
        i = 0

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select*from engineers"
            cur.execute(sql)
            l6 = Label(c3, text='engineer details', font=('arial', 20,'bold'),bg='lightblue')
            l6.place(x=150, y=4)
            data = cur.fetchall()
            for res in data:
                xa.append(res[0])
                xb.append(res[1])
                xc.append(res[2])
                xd.append(res[3])
                xe.append(res[4])
                xf.append(res[5])
                xg.append(res[6])
            db.close()

        def first():
            global i
            i = 0
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            x7.delete(0, 100)
            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xf[i])
            e7.ijsert(0, xg[i])

        def next():
            global i
            i = i+1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e7.delete(0, 100)
            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xe[i])
            e7.insert(0, xe[i])

        def previous():
            global i
            i = i-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e7.delete(0, 100)
            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xf[i])
            e7.insert(0, xg[i])

        def last():
            global i
            i = len(xa)-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e7.delete(0, 100)
            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xf[i])
            e7.insert(0, xg[i])

        l1 = Label(c3, text='Engineer id',font=('arial',15,'bold'),bg='lightblue')
        l1.place(x=100, y=60)

        e1 = Entry(c3, width=30,font=('arial',15))
        e1.place(x=300, y=60)
        l2 = Label(c3, text='Engineer Name',font=('arial',15,'bold'),bg='lightblue')
        l2.place(x=100, y=100)

        e2 = Entry(c3, width=30,font=('arial',15))
        e2.place(x=300, y=100)

        l3 = Label(c3, text='Address',font=('arial',15,'bold'),bg='lightblue')
        l3.place(x=100, y=140)
        e3 = Entry(c3, width=30,font=('arial',15))
        e3.place(x=300, y=140)

        l4 = Label(c3, text='Phone',font=('arial',15,'bold'),bg='lightblue')
        l4.place(x=100, y=180)

        e4 = Entry(c3, width=30,font=('arial',15))
        e4.place(x=300, y=180)

        l5 = Label(c3, text='Email',font=('arial',15,'bold'),bg='lightblue')
        l5.place(x=100, y=220)

        e5 = Entry(c3, width=30,font=('arial',15))
        e5.place(x=300, y=220)

        l6 = Label(c3, text='Prodcat id',font=('arial',15,'bold'),bg='lightblue')
        l6.place(x=100, y=260)

        e6 = Entry(c3, width=30,font=('arial',15))
        e6.place(x=300, y=260)

        l7 = Label(c3, text='Status',font=('arial',15,'bold'),bg='lightblue')
        l7.place(x=100, y=300)

        e7 = Entry(c3, width=30,font=('arial',15))
        e7.place(x=300, y=300)

        b1 = Button(c3, text='First',font=('arial',15,'bold'), bg='blue', command=first)
        b1.place(x=100, y=350)

        b2 = Button(c3, text='Next',font=('arial',15,'bold'), bg='blue', command=next)
        b2.place(x=200, y=350)
        b3 = Button(c3, text='Previous',font=('arial',15,'bold'), bg='blue', command=previous)
        b3.place(x=300, y=350)
        b4 = Button(c3, text='Last',font=('arial',15,'bold'), bg='blue', command=last)
        b4.place(x=450, y=350)
        b5 = Button(c3, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b5.place(x=550, y=350)
        filldata()
    b1=Button(a1,text='Insert',command=showins,font=('Arial',12,'bold'),width=14,bg='grey')
    b1.place(x=35,y=75)
    b1=Button(a1,text='Update',command=showupdate,font=('Arial',12,'bold'),width=14,bg='grey')
    b1.place(x=35,y=150)
    b1=Button(a1,text='Delete',command=showdel,font=('Arial',12,'bold'),width=14,bg='grey')
    b1.place(x=35,y=225)
    b1=Button(a1,text='Find',command=showfind,font=('Arial',12,'bold'),width=14,bg='grey')
    b1.place(x=35,y=300)
    b1=Button(a1,text='Show',command=showdatashow,font=('Arial',12,'bold'),width=14,bg='grey')
    b1.place(x=35,y=375)
    b1=Button(a1,text='Navigate',command=shownavigate,font=('Arial',12,'bold'),width=14,bg='grey')
    b1.place(x=35,y=450)
def showcustomer():
    def showins():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        cdi=[] 
        def dest():
            cdi.clear()
            t.destroy()
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select prodcatid from product_category"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
                cur=db.cursor()
                xa=e1.get()
                sql="select count(*)from customers where custid='%s'"%(xa)
                cur.execute(sql)
                dta=cur.fetchall()
                if data[0]==0:
                    messagebox.showinfo('hii','ok go')
                else:
                
                 cdi.append(res[0])
            db.close()
        def savedata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            xa=e1.get()
            sql="select * from customers where custid='%s'"%(xa)
            cur.execute(sql)
            data=cur.fetchall()
            if data:
                messagebox.showerror("Error","Invalid details")
            elif (e1.get())==0 or  (e2.get())==0 or (e3.get())==0 or (e4.get())==0 or (e5.get())==0  or (e6.get())==0:
                messagebox.showerror('Invalid','Invalid details')
            else:
                db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
                cur=db.cursor()
                xa=e1.get()
                xb=e2.get()
                xc=e3.get()
                xd=e4.get()
                xe=e5.get()
                xf=e6.get()
                
        
                
                sql="insert into customers values('%s','%s','%s','%s','%s','%s')"%(xa,xb,xc,xd,xe,xf)
                cur.execute(sql)
                db.commit()
                messagebox.showinfo('hi','saved')
                db.close()
                e1.delete(0,100)
                e2.delete(0,100)
                e3.delete(0,100)
                e4.delete(0,100)
                e5.delete(0,100)
                e6.delete(0,100)
                
        
        
        

        l6 = Label(c3, text='customer details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)
        l1 = Label(c3, text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=60)

        e1 = Entry(c3, width=30,font=('arial',15))
        e1.place(x=300, y=60)
        

        l2 = Label(c3, text='Customer Name',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=100)

        e2 = Entry(c3, width=30,font=('arial',15))
        e2.place(x=300, y=100)

        l3 = Label(c3, text='Address',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=140)

        e3 = Entry(c3, width=30,font=('arial',15))
        e3.place(x=300, y=140)

        l4 = Label(c3, text='Email',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=180)

        e4 = Entry(c3, width=30,font=('arial',15))
        e4.place(x=300, y=180)

        l5 = Label(c3, text='Phone',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=220)

        e5 = Entry(c3, width=30,font=('arial',15))
        e5.place(x=300, y=220)

        l6 = Label(c3, text='Prodcat id',font=('arial',15,'bold'),bg='yellow')
        l6.place(x=100, y=260)

        #e6 = Entry(c3, width=30,font=('arial',15))
        #e6.place(x=300, y=260)
        e6=ttk.Combobox(c3,font=('arial',13),width=34)
        filldata()
        e6['values']=cdi
        e6.place(x=300,y=260)

        b1 = Button(c3, text='Save',font=('arial',15,'bold'), bg='blue', command=savedata)
        b1.place(x=100, y=350)

        b2 = Button(c3, text='Close',font=('arial',15,'bold'), bg='blue',command=dest)
        b2.place(x=200, y=350)
        
       # b3 = Button(c3, text='Check',font=('arial',15,'bold'), bg='blue',command=checkdata)
       # b3.place(x=300, y=350)
    def showdel():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        cdi=[]
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select custid from customers"
        
            
            cur.execute(sql)           
            data=cur.fetchall()
            for res in data:
                cdi.append(res[0])
       

        def deletedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()

            sql = "delete from customers where custid='%s'" % (xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'deleted')
            db.close()
            a1.delete(0, 100)
        l6 = Label(c3, text='customer details', font=('arial', 20),bg='yellow')
        l6.place(x=200, y=10)
        a = Label(c3, text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        a.place(x=150, y=60)
        #a1 = Entry(t, width=20,font=('arial',15))
       # a1.place(x=300, y=60)
        a1 = ttk.Combobox(c3)
        filldata()
        a1['values'] = cdi
        a1.place(x=300, y=60)
        b = Button(c3, text='Delete',font=('arial',15,'bold'), bg='blue', command=deletedata)
        b.place(x=170, y=100)

    def showfind():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        lt = []
        def dest():
            t.destroy()

        # combobox function
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "Select custid from customers"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        
        def finddata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = e1.get()
            # delete previous data find before
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)

            sql = "Select cname,address,email,phone,prodcatid from customers where custid='%s'" % (xa)
            cur.execute(sql)
            # fetchone to get data using index positions
            data = cur.fetchone()
            e2.insert(0, data[0])
            e3.insert(0, data[1])
            e4.insert(0, data[2])
            e5.insert(0, data[3])
            e6.insert(0, data[4])

            db.close()
        l6 = Label(c3, text='customer details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)

        l1 = Label(c3, text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=80)
        b1 = Button(c3, text='Find',font=('arial',15,'bold'), bg='blue', command=finddata)
        b1.place(x=220, y=100)

       

        e1 = ttk.Combobox(c3,font=('arial',13),width=34)
        # call function filldata below
        filldata()
        e1['values'] = lt
        e1.place(x=300, y=80)
        

        l2 = Label(c3, text='customer name',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=140)

        e2 = Entry(c3, width=30,font=('arial',15))
        e2.place(x=300, y=140)

        l3 = Label(c3, text='address',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=200)

        e3 = Entry(c3, width=30,font=('arial',15))
        e3.place(x=300, y=200)

        l4 = Label(c3, text='email',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=260)

        e4 = Entry(c3, width=30,font=('arial',15))
        e4.place(x=300, y=260)

        l5 = Label(c3, text='phone',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=320)

        e5 = Entry(c3, width=30,font=('arial',15))
        e5.place(x=300, y=320)

        l6 = Label(c3, text='prodcat id',font=('arial',15,'bold'),bg='yellow')
        l6.place(x=100, y=380)

        e6 = Entry(c3, width=30,font=('arial',15))
        e6.place(x=300, y=380)
        
        b2 = Button(c3, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b2.place(x=150, y=440)
    def showdatashow():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        recd=''
        def showdata():
            recd=''
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select * from customers"
            cur.execute(sql)
            l6 = Label(c3, text='customer details', font=('arial', 20,'bold'),bg='yellow')
            l6.place(x=200, y=10)
            data = cur.fetchall()
            for res in data:
                recd = recd+'\t'+(res[0])
                recd = recd+'\t'+(res[1])
                recd = recd+'\t'+(res[2])
                recd = recd+'\t'+(res[3])
                recd = recd+'\t'+(res[4])
                recd = recd+'\t'+(res[5])

                recd = recd+'\n'
            db.close()

        e = Text(c3, width=150, height=50,bg='skyblue',font=('arial',15))
        showdata()
        e.insert(tkinter.END, recd)
        e.place(x=10, y=70)



    
    def showupdate():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        
        lt = []
        def dest():
            t.destroy()

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select custid from customers"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        def updatedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()
            xb = b1.get()
            xc = d1.get()
            xd = f1.get()
            xe = h1.get()
            xf = g1.get()

            sql = "update customers set cname='%s',address='%s',email='%s',phone='%s',prodcatid where custid='%s'" % (xb, xc, xd, xe, xf, xa)

            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'update done')
            a1.delete(0, 100)

            b1.delete(0, data[0])
            d1.delete(0, data[1])
            f1.delete(0, data[2])
            h1.delete(0, data[3])
            g1.delete(0, data[4])
            s1.delete(0, data[5])

        l6 = Label(c3, text='customer details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)
        a = Label(c3, text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        a.place(x=100, y=60)
        a1 = ttk.Combobox(c3,font=('arial',13),width=34)
        filldata()
        a1['values'] = lt
        a1.place(x=300, y=60)

        b = Label(c3, text='Customer Name',font=('arial',15,'bold'),bg='yellow')
        b.place(x=100, y=100)
        b1 = Entry(c3, width=30,font=('arial',15))
        b1.place(x=300, y=100)
        d = Label(c3, text='Address',font=('arial',15,'bold'),bg='yellow')
        d.place(x=100, y=140)
        d1 = Entry(c3, width=30,font=('arial',15))
        d1.place(x=300, y=140)
        f = Label(c3, text='Email',font=('arial',15,'bold'),bg='yellow')
        f.place(x=100, y=180)
        f1 = Entry(c3, width=30,font=('arial',15))
        f1.place(x=300, y=180)
        h = Label(c3, text='Phone',font=('arial',15,'bold'),bg='yellow')
        h.place(x=100, y=220)
        h1 = Entry(c3, width=30,font=('arial',15))
        h1.place(x=300, y=220)
        g = Label(c3, text='Prodcat Id',font=('arial',15,'bold'),bg='yellow')
        g.place(x=100, y=260)
        g1 = Entry(c3, width=30,font=('arial',15))
        g1.place(x=300, y=260)

        b = Button(c3, text='update',font=('arial',15,'bold'), bg='blue', command=updatedata)
        b.place(x=200, y=300)
        b1 = Button(c3, text='close',font=('arial',15,'bold'), bg='blue', command=dest)
        b1.place(x=300, y=300)
    def shownavigate():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        def dest():
            t.destroy()
        xa = []
        xb = []
        xc = []
        xd = []
        xe = []
        xf = []
        i = 0

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select*from customers"
            cur.execute(sql)
            l6 = Label(c3, text='customer details', font=('arial', 20,'bold'),bg='yellow')
            l6.place(x=200, y=4)
            data = cur.fetchall()
            for res in data:
                xa.append(res[0])
                xb.append(res[1])
                xc.append(res[2])
                xd.append(res[3])
                xe.append(res[4])
                xf.append(res[5])
            db.close()

        def first():
            global i
            i = 0
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xf[i])

        def next():
            global i
            i = i+1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xe[i])

        def previous():
            global i
            i = i-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xf[i])

        def last():
            global i
            i = len(xa)-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)
            e1.insert(0, xa[i])
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])
            e6.insert(0, xf[i])

        l1 = Label(c3, text='Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=60)

        e1 = Entry(c3, width=30,font=('arial',15))
        e1.place(x=300, y=60)
        l2 = Label(c3, text='C Name',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=100)

        e2 = Entry(c3, width=30,font=('arial',15))
        e2.place(x=300, y=100)

        l3 = Label(c3, text='Address',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=140)
        e3 = Entry(c3, width=30,font=('arial',15))
        e3.place(x=300, y=140)

        l4 = Label(c3, text='Email',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=180)

        e4 = Entry(c3, width=30,font=('arial',15))
        e4.place(x=300, y=180)

        l5 = Label(c3, text='Phone',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=220)

        e5 = Entry(c3, width=30,font=('arial',15))
        e5.place(x=300, y=220)

        l6 = Label(c3, text='regno',font=('arial',15,'bold'),bg='yellow')
        l6.place(x=100, y=260)

        e6 = Entry(c3, width=30,font=('arial',15))
        e6.place(x=300, y=260)

        b1 = Button(c3, text='First',font=('arial',15,'bold'), bg='blue', command=first)
        b1.place(x=100, y=350)

        b2 = Button(c3, text='Next',font=('arial',15,'bold'), bg='blue', command=next)
        b2.place(x=200, y=350)
        b3 = Button(c3, text='Previous',font=('arial',15,'bold'), bg='blue', command=previous)
        b3.place(x=300, y=350)
        b4 = Button(c3, text='Last',font=('arial',15,'bold'), bg='blue', command=last)
        b4.place(x=450, y=350)
        b5 = Button(c3, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b5.place(x=550, y=350)
        filldata()
    b1=Button(a1,text='Insert',command=showins,font=('Arial',12,'bold'),width=14,bg='deeppink')
    b1.place(x=35,y=75)
    b1=Button(a1,text='Update',command=showupdate,font=('Arial',12,'bold'),width=14,bg='deeppink')
    b1.place(x=35,y=150)
    b1=Button(a1,text='Delete',command=showdel,font=('Arial',12,'bold'),width=14,bg='deeppink')
    b1.place(x=35,y=225)
    b1=Button(a1,text='Find',command=showfind,font=('Arial',12,'bold'),width=14,bg='deeppink')
    b1.place(x=35,y=300)
    b1=Button(a1,text='Show',command=showdatashow,font=('Arial',12,'bold'),width=14,bg='deeppink')
    b1.place(x=35,y=375)
    b1=Button(a1,text='Navigate',command=shownavigate,font=('Arial',12,'bold'),width=14,bg='deeppink')
    b1.place(x=35,y=450)
def showstaff():
    def showins():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        def dest():
            t.destroy()
        def savedata():
            if len(e1.get())==0 or  len(e2.get())==0 or len(e3.get())==0 or len(e4.get())==0 or len(e5.get())==0:
                    
                    
                    messagebox.showerror('hii','Your data has been saved')
            else:
                    db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
                    cur=db.cursor()
                    xa=e1.get()
                    xb=e2.get()
                    xc=e3.get()
                    xd=e4.get()
                    xe=e5.get()
                    
                    
            
                    
                    sql="insert into staff values(%d,'%s','%s','%s','%s')"%(xa,xb,xc,xd,xe)
                    cur.execute(sql)
                    db.commit()
                    messagebox.showinfo('hi','saved')
                    db.close()
                    e1.delete(0,100)
                    e2.delete(0,100)
                    e3.delete(0,100)
                    e4.delete(0,100)
                    e5.delete(0,100)
                    
                    
            
        def checkdata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            xa=e1.get()
            sql="select count(*)from staff where staffid='%s'"%(xa)
            cur.execute(sql)
            data=cur.fetchone()
            if data[0]==0:
                messagebox.showinfo('hii','ok go')
            else:
                messagebox.showinfo('hii','already exit')
            db.close()      
            
        

        

        l6 = Label(c3, text='staff details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)
        l1 = Label(c3, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=60)
        

        e1 = Entry(c3, width=30,font=('arial',15))
        e1.place(x=300, y=60)

        l2 = Label(c3, text='Staff Name',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=100)

        e2 = Entry(c3, width=30,font=('arial',15))
        e2.place(x=300, y=100)

        l3 = Label(c3, text='Address',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=140)

        e3 = Entry(c3, width=30,font=('arial',15))
        e3.place(x=300, y=140)

        l4 = Label(c3, text='Email',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=180)

        e4 = Entry(c3, width=30,font=('arial',15))
        e4.place(x=300, y=180)

        l5 = Label(c3, text='Phone',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=220)

        e5 = Entry(c3, width=30,font=('arial',15))
        e5.place(x=300, y=220)

        b1 = Button(c3, text='Save',font=('arial',15,'bold'), bg='blue', command=savedata)
        b1.place(x=100, y=300)

        b2 = Button(c3, text='Close',font=('arial',15,'bold'), bg='blue',command=dest)
        b2.place(x=200, y=300)
        b3 = Button(c3, text='Check',font=('arial',15,'bold'), bg='blue',command=checkdata)
        b3.place(x=300, y=300)
    
    def showdel():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        cdi=[]
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select staffid from staff"
        
            
            cur.execute(sql)           
            data=cur.fetchall()
            for res in data:
                cdi.append(res[0])

        def deletedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()

            sql = "delete from staff where staffid='%s'" % (xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'deleted')
            db.close()
            a1.delete(0, 100)
        l6 = Label(c3, text='staff details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=10)
        a = Label(c3, text='staff id',font=('arial',15,'bold'),bg='yellow')
        a.place(x=150, y=60)
        #a1 = Entry(t, width=20,font=('arial',15))
        #a1.place(x=300, y=60)
        a1 = ttk.Combobox(c3)
        filldata()
        a1['values'] = cdi
        a1.place(x=300, y=60)
        b = Button(c3, text='Delete',font=('arial',15,'bold'), bg='blue', command=deletedata)
        b.place(x=170, y=100)
    def showfind():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        def dest():
            t.destroy()
        lt = []
        

        # combobox function
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "Select staffid from staff"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        
        def finddata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = int(e1.get())
            # delete previous data find before
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            sql = "Select staffname,address,email,phone from staff where staffid=%d" % (xa)
            cur.execute(sql)
            # fetchone to get data using index positions
            data = cur.fetchone()
            e2.insert(0, data[0])
            e3.insert(0, data[1])
            e4.insert(0, data[2])
            e5.insert(0, data[3])

            db.close()
        l6 = Label(c3, text='staff details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)

        l1 = Label(c3, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=80)
        
       
        b1 = Button(c3, text='Find',font=('arial',15,'bold'), bg='blue', command=finddata)
        b1.place(x=200, y=90)
        
        e1 = ttk.Combobox(c3)
        # call function filldata below
        filldata()
        e1['values'] = lt
        e1.place(x=300, y=80)


        

        l2 = Label(c3, text='Staff Name',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=140)

        e2 = Entry(c3, width=30,font=('arial',15))
        e2.place(x=300, y=140)

        l3 = Label(c3, text='Address',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=200)

        e3 = Entry(c3, width=30,font=('arial',15))
        e3.place(x=300, y=200)

        l4 = Label(c3, text='Email',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=260)

        e4 = Entry(c3, width=30,font=('arial',15))
        e4.place(x=300, y=260)

        l5 = Label(c3, text='Phone',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=320)

        e5 = Entry(c3, width=30,font=('arial',15))
        e5.place(x=300, y=320)
        
        b2 = Button(c3, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b2.place(x=200, y=380)
    def showupdate():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        
        def dest():
            t.destroy()
        lt = []

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select staffid from staff"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        def updatedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = int(a1.get())
            xb = b1.get()
            xc = d1.get()
            xd = f1.get()
            xe = h1.get()

            sql = "update staff set staffname='%s',address='%s',email='%s',phone='%s' where staffid=%d" % (xb, xc, xd, xe, xa)

            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'update done')
            a1.delete(0, 100)

            b1.delete(0, data[0])
            d1.delete(0, data[1])
            f1.delete(0, data[2])
            h1.delete(0, data[3])

        l6 = Label(c3, text='staff details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)
        a = Label(c3, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        a.place(x=100, y=60)
        a1 = ttk.Combobox(c3)
        filldata()
        a1['values'] = lt
        a1.place(x=300, y=60)

        b = Label(c3, text='Staff Name',font=('arial',15,'bold'),bg='yellow')
        b.place(x=100, y=100)
        b1 = Entry(c3, width=30,font=('arial',15))
        b1.place(x=300, y=100)
        d = Label(c3, text='Address',font=('arial',15,'bold'),bg='yellow')
        d.place(x=100, y=140)
        d1 = Entry(c3, width=30,font=('arial',15))
        d1.place(x=300, y=140)
        f = Label(c3, text='Email',font=('arial',15,'bold'),bg='yellow')
        f.place(x=100, y=180)
        f1 = Entry(c3, width=30,font=('arial',15))
        f1.place(x=300, y=180)
        h = Label(c3, text='Phone',font=('arial',15,'bold'),bg='yellow')
        h.place(x=100, y=220)
        h1 = Entry(c3, width=30,font=('arial',15))
        h1.place(x=300, y=220)

        p = Button(c3, text='update',font=('arial',15,'bold'), bg='blue', command=updatedata)
        p.place(x=150, y=300)
        p1 = Button(c3, text='close',font=('arial',15,'bold'), bg='blue', command=dest)
        p1.place(x=250, y=300)


    def showdatashow():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        recd=''
        def showdata():
            recd=''
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select * from staff"
            cur.execute(sql)
            l6 = Label(c3, text='staff details', font=('arial', 20,'bold'),bg='yellow')
            l6.place(x=200, y=10)
            data = cur.fetchall()
            for res in data:
                recd = recd+'\t'+str(res[0])
                recd = recd+'\t'+(res[1])
                recd = recd+'\t'+(res[2])
                recd = recd+'\t'+(res[3])
                recd = recd+'\t'+(res[4])

                recd = recd+'\n'
            db.close()

        e = Text(c3, width=150, height=50,bg='skyblue',font=('arial',15))
        showdata()
        e.insert(tkinter.END, recd)
        e.place(x=10, y=70)
    def shownavigate():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        def dest():
            t.destroy()
        xa = []
        xb = []
        xc = []
        xd = []
        xe = []

        i = 0

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select*from staff"
            cur.execute(sql)
            l6 = Label(c3, text='staff details', font=('arial', 20,'bold'),bg='yellow')
            l6.place(x=200, y=7)
            data = cur.fetchall()
            for res in data:
                xa.append(res[0])
                xb.append(res[1])
                xc.append(res[2])
                xd.append(res[3])
                xe.append(res[4])

            db.close()

        def first():
            global i
            i = 0
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            e1.insert(0, str(xa[i]))
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])

        def next():
            global i
            i = i+1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            e1.insert(0, str(xa[i]))
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])

        def previous():
            global i
            i = i-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            e1.insert(0, str(xa[i]))
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])

        def last():
            global i
            i = len(xa)-1
            e1.delete(0, 100)
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            e1.insert(0, str(xa[i]))
            e2.insert(0, xb[i])
            e3.insert(0, xc[i])
            e4.insert(0, xd[i])
            e5.insert(0, xe[i])

        l1 = Label(c3, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=60)

        e1 = Entry(c3, width=30,font=('arial',15))
        e1.place(x=300, y=60)
        l2 = Label(c3, text='Staff Name',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=100)

        e2 = Entry(c3, width=30,font=('arial',15))
        e2.place(x=300, y=100)

        l3 = Label(c3, text='Address',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=140)
        e3 = Entry(c3, width=30,font=('arial',15))
        e3.place(x=300, y=140)

        l4 = Label(c3, text='Email',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=180)

        e4 = Entry(c3, width=30,font=('arial',15))
        e4.place(x=300, y=180)

        l5 = Label(c3, text='Phone',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=220)

        e5 = Entry(c3, width=30,font=('arial',15))
        e5.place(x=300, y=220)

        b1 = Button(c3, text='First',font=('arial',15,'bold'), bg='blue', command=first)
        b1.place(x=100, y=300)

        b2 = Button(c3, text='Next',font=('arial',15,'bold'), bg='blue', command=next)
        b2.place(x=200, y=300)
        b3 = Button(c3, text='Previous',font=('arial',15,'bold'), bg='blue', command=previous)
        b3.place(x=300, y=300)
        b4 = Button(c3, text='Last',font=('arial',15,'bold'), bg='blue', command=last)
        b4.place(x=450, y=300)
        b5 = Button(c3, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b5.place(x=550, y=300)
        filldata()
    b1=Button(a1,text='Insert',command=showins,font=('Arial',12,'bold'),width=14,bg='thistle')
    b1.place(x=35,y=75)
    b1=Button(a1,text='Update',command=showupdate,font=('Arial',12,'bold'),width=14,bg='thistle')
    b1.place(x=35,y=150)
    b1=Button(a1,text='Delete',command=showdel,font=('Arial',12,'bold'),width=14,bg='thistle')
    b1.place(x=35,y=225)
    b1=Button(a1,text='Find',command=showfind,font=('Arial',12,'bold'),width=14,bg='thistle')
    b1.place(x=35,y=300)
    b1=Button(a1,text='Show',command=showdatashow,font=('Arial',12,'bold'),width=14,bg='thistle')
    b1.place(x=35,y=375)
    b1=Button(a1,text='Navigate',command=shownavigate,font=('Arial',12,'bold'),width=14,bg='thistle')
    b1.place(x=35,y=450)
def showcallassignment():
    def showins():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        cdi=[]
        def dest():
            cdi.clear()
            t.destroy()
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select staffid from staff"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                
                cdi.append(res[0])
            db.close()
        cdi1=[]
        def dest():
            cdi1.clear()
            t.destroy()
        def filldata1():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select custid from customers"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                
                cdi1.append(res[0])
            db.close()    
        cdi2=[]
        def dest():
            cdi2.clear()
            t.destroy()
        def filldata2():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select engid from engineers"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                 
                cdi2.append(res[0])
            db.close()       
       
            
        def savedata():
            if len(e1.get())==0 or  len(e2.get())==0 or len(e3.get())==0 or len(e4.get())==0 or len(e5.get())==0 or len(e6.get())==0:
                    
                    
                    messagebox.showerror('hii','Your data has been saved')
            else:
                    db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
                    cur=db.cursor()
                    xa=e1.get()
                    xb=int(e2.get())
                    xc=e3.get()
                    xd=e4.get()
                    xe=e5.get()
                    xf=int(e6.get())
                    
                    
            
                    
                    sql="insert into callassignment values('%s',%d,'%s','%s',%d)"%(xa,xb,xc,xd,xe,xf)
                    cur.execute(sql)
                    db.commit()
                    messagebox.showinfo('hi','saved')
                    db.close()
                    e1.delete(0,100)
                    e2.delete(0,100)
                    e3.delete(0,100)
                    e4.delete(0,100)
                    e5.delete(0,100)
                    e6.delete(0,100)
                    
                    
            
        def checkdata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            xa=e1.get()
            sql="select count(*)from callassignment where callid='%s'"%(xa)
            cur.execute(sql)
            data=cur.fetchone()
            if data[0]==0:
                messagebox.showinfo('hii','ok go')
            else:
                messagebox.showinfo('hii','already exit')
            db.close()      
            
        # code for db connectivity button

       

        l6 = Label(c3, text='call assignment details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)
        l1 = Label(c3, text='Call Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=60)

        e1 = Entry(c3, width=30,font=('arial',15))
        e1.place(x=300, y=60)

        l2 = Label(c3, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=100)

        #e2 = Entry(t, width=30,font=('arial',15))
       # e2.place(x=300, y=100)
        e2=ttk.Combobox(c3,font=('arial',13),width=34)
        filldata()
        e2['values']=cdi
        e2.place(x=300,y=100)

        l3 = Label(c3, text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=140)

        #e3 = Entry(t, width=30,font=('arial',15))
        #e3.place(x=300, y=140)
        e3=ttk.Combobox(c3,font=('arial',13),width=34)
        filldata1()
        e3['values']=cdi1
        e3.place(x=300,y=140)

        l4 = Label(c3, text='Engineer Id',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=180)

        #e4 = Entry(t, width=30,font=('arial',15))
        #e4.place(x=300, y=180)
        e3=ttk.Combobox(c3,font=('arial',13),width=34)
        filldata2()
        e3['values']=cdi2
        e3.place(x=300,y=180)

        l5 = Label(c3, text='Date of call',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=220)

        e5 = Entry(c3, width=30,font=('arial',15))
        e5.place(x=300, y=220)

        l6 = Label(c3, text='Charge',font=('arial',15,'bold'),bg='yellow')
        l6.place(x=100, y=260)

        e6 = Entry(c3, width=30,font=('arial',15))
        e6.place(x=300, y=260)

        b1 = Button(c3, text='Save',font=('arial',15,'bold'), bg='blue', command=savedata)
        b1.place(x=100, y=350)

        b2 = Button(c3, text='Close',font=('arial',15,'bold'), bg='blue',command=dest)
        b2.place(x=200, y=350)
        b3 = Button(c3, text='Check',font=('arial',15,'bold'), bg='blue',command=checkdata)
        b3.place(x=300, y=350)

    
    def showdel():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        cdi=[]
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select callid from callassignment"
        
            
            cur.execute(sql)           
            data=cur.fetchall()
            for res in data:
                cdi.append(res[0])

        def deletedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()

            sql = "delete from callassignment where callid='%s'" % (xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'deleted')
            db.close()
            a1.delete(0, 100)
        l6 = Label(c3, text='call assignment details', font=('arial', 20),bg='yellow')
        l6.place(x=200, y=10)
        a = Label(c3, text='Call Id',font=('arial',15,'bold'),bg='yellow')
        a.place(x=150, y=60)
        #a1 = Entry(t, width=20,font=('arial',15))
        #a1.place(x=300, y=60)
        a1 = ttk.Combobox(c3)
        filldata()
        a1['values'] = cdi
        a1.place(x=300, y=60)
        b = Button(c3, text='Delete',font=('arial',15,'bold'), bg='blue', command=deletedata)
        b.place(x=170, y=100)
    def showfind():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        def dest():
            t.destroy()
        lt = []
        

        # combobox function
        def filldata():
            db = pymysql.connect(host='localhost', user='root', password='root', database='scm')
            cur = db.cursor()
            sql = "Select callid from callassignment"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()


        def finddata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = e1.get()
            # delete previous data find before
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)
            e6.delete(0, 100)

            sql = "Select staffid,custid,engid,dateofcall,charges from callassignment where callid='%s'" % (xa)
            cur.execute(sql)
            # fetchone to get data using index positions
            data = cur.fetchone()
            e2.insert(0, data[0])
            e3.insert(0, data[1])
            e4.insert(0, data[2])
            e5.insert(0, data[3])
            e6.insert(0, data[4])

            db.close()
        l6 = Label(c3, text='call assignment details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)

        l1 = Label(c3, text='call id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=80)

        b1 = Button(c3, text='Find',font=('arial',15,'bold'), bg='blue', command=finddata)
        b1.place(x=200, y=90)

        e1 = ttk.Combobox(c3,width=34)
        # call function filldata below
        filldata()
        e1['values'] = lt
        e1.place(x=300, y=80)

        l2 = Label(c3, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=140)

        e2 = Entry(c3, width=30,font=('arial',15))
        e2.place(x=300, y=140)

        l3 = Label(c3, text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=200)

        e3 = Entry(c3, width=30,font=('arial',15))
        e3.place(x=300, y=200)

        l4 = Label(c3, text='Engineer Id',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=260)

        e4 = Entry(c3, width=30,font=('arial',15))
        e4.place(x=300, y=260)

        l5 = Label(c3, text='Date of call',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=320)

        e5 = Entry(c3, width=30,font=('arial',15))
        e5.place(x=300, y=320)

        l6 = Label(c3, text='Charge',font=('arial',15,'bold'),bg='yellow')
        l6.place(x=100, y=380)

        e6 = Entry(c3, width=30,font=('arial',15))
        e6.place(x=300, y=380)
        b2 = Button(c3, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b2.place(x=200, y=440)
    def showdatashow():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        recd=''
        def showdata():
            recd= ''
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select * from callassignment"
            cur.execute(sql)
            l6 = Label(c3, text='call assignment details', font=('arial', 20,'bold'),bg='yellow')
            l6.place(x=200, y=10)
            data = cur.fetchall()
            for res in data:
                recd = recd+'\t'+(res[0])
                recd = recd+'\t'+str(res[1])
                recd = recd+'\t'+(res[2])
                recd = recd+'\t'+(res[3])
                recd = recd+'\t'+(res[4])
                recd = recd+'\t'+str(res[5])

                recd = recd+'\n'
            db.close()

        e = Text(c3, width=150, height=50,bg='skyblue',font=('arial',15))
        showdata()
        e.insert(tkinter.END, recd)
        e.place(x=10, y=70)
    def showupdate():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        def dest():
            t.destroy()
        lt = []

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select callid from callassignment"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        def updatedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()
            xb = b1.get()
            xc = d1.get()
            xd = f1.get()
            xe = h1.get()
            xf = g1.get()

            sql = "update callassignment set staffid=%d,custid='%s',engid='%s',dateofcall='%s',charges=%d where callid='%s'" % (xb, xc, xd, xe, xf, xa)

            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'update done')
            a1.delete(0, 100)

            b1.delete(0, data[0])
            d1.delete(0, data[1])
            f1.delete(0, data[2])
            h1.delete(0, data[3])
            g1.delete(0, data[4])
            s1.delete(0, data[5])

        l6 = Label(c3, text='call assignment details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)
        a = Label(c3, text='Call Id',font=('arial',15,'bold'),bg='yellow')
        a.place(x=100, y=80)
        a1 = ttk.Combobox(c3,width=34)
        filldata()
        a1['values'] = lt
        a1.place(x=300, y=80)

        b = Label(c3, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        b.place(x=100, y=120)
        b1 = Entry(c3, width=30,font=('arial',15))
        b1.place(x=300, y=120)
        d = Label(c3, text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        d.place(x=100, y=160)
        d1 = Entry(c3, width=30,font=('arial',15))
        d1.place(x=300, y=160)
        f = Label(c3, text='Engineer Id',font=('arial',15,'bold'),bg='yellow')
        f.place(x=100, y=200)
        f1 = Entry(c3, width=30,font=('arial',15))
        f1.place(x=300, y=200)
        h = Label(c3, text='Date of call',font=('arial',15,'bold'),bg='yellow')
        h.place(x=100, y=240)
        h1 = Entry(c3, width=30,font=('arial',15))
        h1.place(x=300, y=240)
        g = Label(c3, text='Charge',font=('arial',15,'bold'),bg='yellow')
        g.place(x=100, y=280)
        g1 = Entry(c3, width=30,font=('arial',15))
        g1.place(x=300, y=280)

        b = Button(c3, text='update',font=('arial',15,'bold'), bg='blue', command=updatedata)
        b.place(x=150, y=350)
        b1 = Button(c3, text='Close',font=('arial',15,'bold'), bg='blue', command=dest)
        b1.place(x=250, y=350)

    
    def shownavigate():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        
        def dest():
            t.destroy()
        xa=[]
        xb=[]
        xc=[]
        xd=[]
        xe=[]
        xf=[]
        i=0
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select*from callassignment"
            cur.execute(sql)
            l6=Label(c3,text='call assignment Details',font=('arial',20,'bold'),bg='yellow')
            l6.place(x=150,y=4)
            data=cur.fetchall()
            for res in data:
                xa.append(res[0])
                xb.append(res[1])
                xc.append(res[2])
                xd.append(res[3])
                xe.append(res[4])
                xf.append(res[5])
            db.close()
            
        def first():
            global i
            i=0
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
            e6.delete(0,100)
            e1.insert(0,xa[i])
            e2.insert(0,str(xb[i]))
            e3.insert(0,xc[i])
            e4.insert(0,xd[i])
            e5.insert(0,xe[i])
            e6.insert(0,str(xf[i]))
            
        def next():
            global i
            i=i+1
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
            e6.delete(0,100)
            e1.insert(0,xa[i])
            e2.insert(0,str(xb[i]))
            e3.insert(0,xc[i])
            e4.insert(0,xd[i])
            e5.insert(0,xe[i])
            e6.insert(0,str(xe[i]))
            
        def previous():
            global i
            i=i-1
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
            e6.delete(0,100)
            e1.insert(0,xa[i])
            e2.insert(0,str(xb[i]))
            e3.insert(0,xc[i])
            e4.insert(0,xd[i])
            e5.insert(0,xe[i])
            e6.insert(0,str(xf[i]))
            
        def last():
            global i
            i=len(xa)-1
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
            e6.delete(0,100)
            e1.insert(0,xa[i])
            e2.insert(0,str(xb[i]))
            e3.insert(0,xc[i])
            e4.insert(0,xd[i])
            e5.insert(0,xe[i])
            e6.insert(0,str(xf[i]))
           
        l1=Label(c3,text='Call Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100,y=60)

        e1=Entry(c3,width=30,font=('arial',15))
        e1.place(x=300,y=60)
        l2=Label(c3,text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100,y=100)

        e2=Entry(c3,width=30,font=('arial',15))
        e2.place(x=300,y=100)

        l3=Label(c3,text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100,y=140)
        e3=Entry(c3,width=30,font=('arial',15))
        e3.place(x=300,y=140)

        l4=Label(c3,text='Engineer Id',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100,y=180)

        e4=Entry(c3,width=30,font=('arial',15))
        e4.place(x=300,y=180)

        l5=Label(c3,text='Date Of Call',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100,y=220)

        e5=Entry(c3,width=30,font=('arial',15))
        e5.place(x=300,y=220)
         
        l6=Label(c3,text='Charge',font=('arial',15,'bold'),bg='yellow')
        l6.place(x=100,y=260)

        e6=Entry(c3,width=30,font=('arial',15))
        e6.place(x=300,y=260)

        b1=Button(c3,text='first',font=('arial',15,'bold'),bg='blue',command=first)
        b1.place(x=100,y=300)

        b2=Button(c3,text='next',font=('arial',15,'bold'),bg='blue',command=next)
        b2.place(x=200,y=300)
        b3=Button(c3,text='previous',font=('arial',15,'bold'),bg='blue',command=previous)
        b3.place(x=300,y=300)
        b4=Button(c3,text='last',font=('arial',15,'bold'),bg='blue',command=last)
        b4.place(x=450,y=300)
        b5=Button(c3,text='Close',font=('arial',15,'bold'),bg='blue',command=dest)
        b5.place(x=550,y=300)
        filldata()
    b1=Button(a1,text='Insert',command=showins,font=('Arial',12,'bold'),width=14,bg='lightyellow')
    b1.place(x=35,y=75)
    b1=Button(a1,text='Update',command=showupdate,font=('Arial',12,'bold'),width=14,bg='lightyellow')
    b1.place(x=35,y=150)
    b1=Button(a1,text='Delete',command=showdel,font=('Arial',12,'bold'),width=14,bg='lightyellow')
    b1.place(x=35,y=225)
    b1=Button(a1,text='Find',command=showfind,font=('Arial',12,'bold'),width=14,bg='lightyellow')
    b1.place(x=35,y=300)
    b1=Button(a1,text='Show',command=showdatashow,font=('Arial',12,'bold'),width=14,bg='lightyellow')
    b1.place(x=35,y=375)
    b1=Button(a1,text='Navigate',command=shownavigate,font=('Arial',12,'bold'),width=14,bg='lightyellow')
    b1.place(x=35,y=450)
def showcallclose():
    def showins():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        cdi=[]
        def dest():
            cdi.clear()
            t.destroy()
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select callid from callassignment"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                
                cdi.append(res[0])
            db.close()
        cdi1=[]
        def dest():
            cdi1.clear()
            t.destroy()
        def filldata1():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select staffid from staff"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                
                cdi1.append(res[0])
            db.close()    
        cdi2=[]
        def dest():
            cdi2.clear()
            t.destroy()
        def filldata2():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select custid from customers"
            cur.execute(sql)
            data=cur.fetchall()
            for res in data:
                 
                cdi2.append(res[0])
            db.close()       
        cdi3=[]
        def dest():
           cdi3.clear()
           t.destroy()
        def filldata3():
           db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
           cur=db.cursor()
           sql="select engid from engineers"
           cur.execute(sql)
           data=cur.fetchall()
           for res in data:
                
               cdi3.append(res[0])
           db.close()       
            
        def savedata():
            if len(e1.get())==0 or  len(e2.get())==0 or len(e3.get())==0 or len(e4.get())==0 or len(e5.get())==0:
                    
                    
                    messagebox.showerror('hii','Your data has been saved')
            else:
                    db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
                    cur=db.cursor()
                    xa=e1.get()
                    xb=e2.get()
                    xc=e3.get()
                    xd=e4.get()
                    xe=e5.get()
                    
                    
            
                    
                    sql="insert into staff values('%s','%s','%s','%s','%s')"%(xa,xb,xc,xd,xe)
                    cur.execute(sql)
                    db.commit()
                    messagebox.showinfo('hi','saved')
                    db.close()
                    e1.delete(0,100)
                    e2.delete(0,100)
                    e3.delete(0,100)
                    e4.delete(0,100)
                    e5.delete(0,100)
                    
                    
            
        def checkdata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            xa=e1.get()
            sql="select count(*)from callclose where callid='%s'"%(xa)
            cur.execute(sql)
            data=cur.fetchone()
            if data[0]==0:
                messagebox.showinfo('hii','ok go')
            else:
                messagebox.showinfo('hii','already exit')
            db.close()      
                 
       

        l6 = Label(c3, text='call close details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)
        l1 = Label(c3, text='Call Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=60)
        
        #e1 = Entry(t, width=30,font=('arial',15))
       # e1.place(x=300, y=60)
        ez = ttk.Combobox(c3,width=34)
        # call function filldata below
        filldata()
        ez['values'] = cdi
        ez.place(x=300, y=60)
       

        l2 = Label(c3, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=100)

        #e2 = Entry(t, width=30,font=('arial',15))
        #e2.place(x=300, y=100)
        e2 = ttk.Combobox(c3,width=34)
        # call function filldata below
        filldata1()
        e2['values'] = cdi1
        e2.place(x=300, y=100)

        l3 = Label(c3, text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=140)

        #e3 = Entry(t, width=30,font=('arial',15))
        #e3.place(x=300, y=140)
        e3 = ttk.Combobox(c3,width=34)
        # call function filldata below
        filldata2()
        e3['values'] =cdi2
        e3.place(x=300, y=140)

        l4 = Label(c3, text='Engineer Id',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=180)

        #e4 = Entry(t, width=30,font=('arial',15))
        #e4.place(x=300, y=180)
        e4 = ttk.Combobox(c3,width=34)
        # call function filldata below
        filldata3()
        e4['values'] =cdi3
        e4.place(x=300, y=180)

        l5 = Label(c3, text='Date of close',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=220)

        e5 = Entry(c3, width=34,font=('arial',10))
        e5.place(x=300, y=220)

        b1 = Button(c3, text='Save',font=('arial',15,'bold'), bg='blue', command=savedata)
        b1.place(x=100, y=300)
        b2 = Button(c3, text='Close',font=('arial',15,'bold'), bg='blue',command=dest)
        b2.place(x=200, y=300)
        b3 = Button(c3, text='Check',font=('arial',15,'bold'), bg='blue',command=checkdata)
        b3.place(x=300, y=300)

    def showdel():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        cdi=[]
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select callid from callclose"
        
            
            cur.execute(sql)           
            data=cur.fetchall()
            for res in data:
                cdi.append(res[0])

        def deletedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()

            sql = "delete from callclose where callid='%s'" % (xa)
            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'deleted')
            db.close()
            a1.delete(0, 100)
        l6 = Label(c3, text='call close details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=10)
        a = Label(c3, text='Call Id',font=('arial',15,'bold'),bg='yellow')
        a.place(x=150, y=60)
        #a1 = Entry(t, width=20,font=('arial',15))
        #a1.place(x=250, y=60)
        a1 = ttk.Combobox(c3)
        filldata()
        a1['values'] = cdi
        a1.place(x=300, y=60)
        b = Button(c3, text='Delete',font=('arial',15,'bold'), bg='blue', command=deletedata)
        b.place(x=170, y=100)
    def showfind():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        
        def dest():
            t.destroy()
        lt = []

        # combobox function
        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "Select callid from callassignment"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        
        def finddata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = e1.get()
            # delete previous data find before
            e2.delete(0, 100)
            e3.delete(0, 100)
            e4.delete(0, 100)
            e5.delete(0, 100)

            sql = "Select staffid,custid,engid,dateofclose from callclose where callid='%s'" % (xa)
            cur.execute(sql)
            # fetchone to get data using index positions
            data = cur.fetchone()
            e2.insert(0, data[0])
            e3.insert(0, data[1])
            e4.insert(0, data[2])
            e5.insert(0, data[3])

            db.close()
        l6 = Label(c3, text='call close details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)

        l1 = Label(c3, text='Call Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100, y=60)

        b1 = Button(c3, text='Find',font=('arial',15,'bold'), bg='blue', command=finddata)
        b1.place(x=200, y=90)

        e1 = ttk.Combobox(c3)
        # call function filldata below
        filldata()
        e1['values'] = lt
        e1.place(x=300, y=60)

        l2 = Label(c3, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100, y=120)

        e2 = Entry(c3, width=30,font=('arial',15))
        e2.place(x=300, y=120)

        l3 = Label(c3, text='customer Id',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100, y=180)

        e3 = Entry(c3, width=30,font=('arial',15))
        e3.place(x=300, y=180)

        l4 = Label(c3, text='Engineer Id',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100, y=240)

        e4 = Entry(c3, width=30,font=('arial',15))
        e4.place(x=300, y=240)

        l5 = Label(c3, text='Date of close',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100, y=300)

        e5 = Entry(c3, width=30,font=('arial',15))
        e5.place(x=300, y=300)
        b2 = Button(c3, text='Cloose',font=('arial',15,'bold'), bg='blue', command=dest)
        b2.place(x=200, y=360)
    def showdatashow():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        recd=''
        def showdata():
            recd=''
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select * from callclose"
            cur.execute(sql)
            l6 = Label(c3, text='call close details', font=('arial', 20,'bold'),bg='yellow')
            l6.place(x=200, y=10)
            data = cur.fetchall()
            for res in data:
                recd = recd+'\t'+(res[0])
                recd = recd+'\t'+str(res[1])
                recd = recd+'\t'+(res[2])
                recd = recd+'\t'+(res[3])
                recd = recd+'\t'+(res[4])

                recd = recd+'\n'
            db.close()

        e = Text(c3, width=150, height=50,bg='skyblue',font=('arial',15))
        showdata()
        e.insert(tkinter.END, recd)
        e.place(x=10, y=70)


    
    def showupdate():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        def dest():
            t.destroy()
        lt = []

        def filldata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            sql = "select callid from callclose"
            cur.execute(sql)
            data = cur.fetchall()
            for res in data:
                lt.append(res[0])
            db.close()

        def updatedata():
            db = pymysql.connect(host='localhost', user='root',password='root', database='scm')
            cur = db.cursor()
            xa = a1.get()
            xb = int(b1.get())
            xc = d1.get()
            xd = f1.get()
            xe = h1.get()

            sql = "update callclose set staffid=%d,custid='%s',engid='%s',dateofclose='%s' where callid='%s'" % ( xb, xc, xd, xe, xa)

            cur.execute(sql)
            db.commit()
            messagebox.showinfo('hi', 'update done')
            a1.delete(0, 100)

            b1.delete(0, data[0])
            d1.delete(0, data[1])
            f1.delete(0, data[2])
            h1.delete(0, data[3])

        l6 = Label(c3, text='call close details', font=('arial', 20,'bold'),bg='yellow')
        l6.place(x=200, y=7)
        a = Label(c3, text='Call Id',font=('arial',15,'bold'),bg='yellow')
        a.place(x=100, y=80)
        a1 = ttk.Combobox(c3)
        filldata()
        a1['values'] = lt
        a1.place(x=300, y=80)

        b = Label(c3, text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        b.place(x=100, y=120)
        b1 = Entry(c3, width=30,font=('arial',15))
        b1.place(x=300, y=120)
        d = Label(c3, text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        d.place(x=100, y=160)
        d1 = Entry(c3, width=30,font=('arial',15))
        d1.place(x=300, y=160)
        f = Label(c3, text='Engineer Id',font=('arial',15,'bold'),bg='yellow')
        f.place(x=100, y=200)
        f1 = Entry(c3, width=30,font=('arial',15))
        f1.place(x=300, y=200)
        h = Label(c3, text='Date of close',font=('arial',15,'bold'),bg='yellow')
        h.place(x=100, y=240)
        h1 = Entry(c3, width=30,font=('arial',15))
        h1.place(x=300, y=240)

        p = Button(c3, text='update',font=('arial',15,'bold'), bg='blue', command=updatedata)
        p.place(x=150, y=300)
        p1 = Button(c3, text='close',font=('arial',15,'bold'), bg='blue', command=dest)
        p1.place(x=250, y=300)
    def shownavigate():
        c3=Canvas(t,height=900,width=900,bg='navajo white')
        c3.place(x=500,y=0)
        def dest():
            t.destroy()
        xa=[]
        xb=[]
        xc=[]
        xd=[]
        xe=[]
        
        i=0
        def filldata():
            db=pymysql.connect(host='localhost',user='root',password='root',database='scm')
            cur=db.cursor()
            sql="select*from callclose"
            cur.execute(sql)
            l6=Label(c3,text='Call Close Details',font=('arial',20,'bold'),bg='yellow')
            l6.place(x=150,y=4)
            data=cur.fetchall()
            for res in data:
                xa.append(res[0])
                xb.append(res[1])
                xc.append(res[2])
                xd.append(res[3])
                xe.append(res[4])
                
            db.close()
            
        def first():
            global i
            i=0
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
            
            e1.insert(0,xa[i])
            e2.insert(0,str(xb[i]))
            e3.insert(0,xc[i])
            e4.insert(0,xd[i])
            e5.insert(0,xe[i])
            
            
        def next():
            global i
            i=i+1
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
            
            e1.insert(0,xa[i])
            e2.insert(0,str(xb[i]))
            e3.insert(0,xc[i])
            e4.insert(0,xd[i])
            e5.insert(0,xe[i])
            
            
        def previous():
            global i
            i=i-1
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
            
            e1.insert(0,xa[i])
            e2.insert(0,str(xb[i]))
            e3.insert(0,xc[i])
            e4.insert(0,xd[i])
            e5.insert(0,xe[i])
            
            
        def last():
            global i
            i=len(xa)-1
            e1.delete(0,100)
            e2.delete(0,100)
            e3.delete(0,100)
            e4.delete(0,100)
            e5.delete(0,100)
            
            e1.insert(0,xa[i])
            e2.insert(0,str(xb[i]))
            e3.insert(0,xc[i])
            e4.insert(0,xd[i])
            e5.insert(0,xe[i])
            
           
        l1=Label(c3,text='Call Id',font=('arial',15,'bold'),bg='yellow')
        l1.place(x=100,y=60)

        e1=Entry(c3,width=30,font=('arial',15))
        e1.place(x=300,y=60)
        l2=Label(c3,text='Staff Id',font=('arial',15,'bold'),bg='yellow')
        l2.place(x=100,y=100)

        e2=Entry(c3,width=30,font=('arial',15))
        e2.place(x=300,y=100)

        l3=Label(c3,text='Customer Id',font=('arial',15,'bold'),bg='yellow')
        l3.place(x=100,y=140)
        e3=Entry(c3,width=30,font=('arial',15))
        e3.place(x=300,y=140)

        l4=Label(c3,text='Engineer Id',font=('arial',15,'bold'),bg='yellow')
        l4.place(x=100,y=180)

        e4=Entry(c3,width=30,font=('arial',15))
        e4.place(x=300,y=180)

        l5=Label(c3,text='Date Of Close',font=('arial',15,'bold'),bg='yellow')
        l5.place(x=100,y=220)

        e5=Entry(c3,width=30,font=('arial',15))
        e5.place(x=300,y=220)
         
        

        b1=Button(c3,text='First',font=('arial',15,'bold'),bg='blue',command=first)
        b1.place(x=100,y=300)

        b2=Button(c3,text='Next',font=('arial',15,'bold'),bg='blue',command=next)
        b2.place(x=200,y=300)
        b3=Button(c3,text='Previous',font=('arial',15,'bold'),bg='blue',command=previous)
        b3.place(x=300,y=300)
        b4=Button(c3,text='Last',font=('arial',15,'bold'),bg='blue',command=last)
        b4.place(x=450,y=300)
        b5=Button(c3,text='Close',font=('arial',15,'bold'),bg='blue',command=dest)
        b5.place(x=550,y=300)
        filldata()
    b1=Button(a1,text='Insert',command=showins,font=('Arial',12,'bold'),width=14,bg='steelblue4')
    b1.place(x=35,y=75)
    b1=Button(a1,text='Update',command=showupdate,font=('Arial',12,'bold'),width=14,bg='steelblue4')
    b1.place(x=35,y=150)
    b1=Button(a1,text='Delete',command=showdel,font=('Arial',12,'bold'),width=14,bg='steelblue4')
    b1.place(x=35,y=225)
    b1=Button(a1,text='Find',command=showfind,font=('Arial',12,'bold'),width=14,bg='steelblue4')
    b1.place(x=35,y=300)
    b1=Button(a1,text='Show',command=showdatashow,font=('Arial',12,'bold'),width=14,bg='steelblue4')
    b1.place(x=35,y=375)
    b1=Button(a1,text='Navigate',command=shownavigate,font=('Arial',12,'bold'),width=14,bg='steelblue4')
    b1.place(x=35,y=450)

    
    
        
a=Canvas(t,height=900,width=250,bg='bisque')
a.place(x=0,y=0)
a1=Canvas(t,height=900,width=250,bg='peach puff')
a1.place(x=250,y=0)
c3=Canvas(t,height=900,width=900,bg='navajo white')
c3.place(x=500,y=0)
b=Button(a,text='Service centre',width=14,font=('arial',12,'bold'),bg='sky blue',command=showservicecentre)
b.place(x=35,y=75)
c=Button(a,text='Product Category',width=14,font=('arial',12,'bold'),bg='sky blue',command=showproductcategory)
c.place(x=35,y=150)
d=Button(a,text='Service Type',width=14,font=('arial',12,'bold'),bg='sky blue',command=showservicetype)
d.place(x=35,y=225)
e=Button(a,text='Engineers',width=14,font=('arial',12,'bold'),bg='sky blue',command=showengineers)
e.place(x=35,y=300)
f=Button(a,text='Customers',width=14,font=('arial',12,'bold'),bg='sky blue',command=showcustomer)
f.place(x=35,y=375)
g=Button(a,text='Staff',width=14,font=('arial',12,'bold'),bg='sky blue',command=showstaff)
g.place(x=35,y=450)
h=Button(a,text='Call Assignment',width=14,font=('arial',12,'bold'),bg='sky blue',command=showcallassignment)
h.place(x=35,y=525)
j=Button(a,text='Call Close',width=14,font=('arial',12,'bold'),bg='sky blue',command=showcallclose)
j.place(x=35,y=600)
t.mainloop()